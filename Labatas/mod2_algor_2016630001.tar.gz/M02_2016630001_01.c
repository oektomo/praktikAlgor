#include<stdio.h>
#include<stdlib.h>


int quick(int bawah, int atas);
int x,Y[100];

int main()
{
int i, jml;
// untuk menentukan banyaknya data
    printf("masukkan jumlah data : ");
    scanf("%d",&jml);

//untuk mendapatkan data random
    for(i=0;i<jml;i++)
    {
        Y[i]=rand()%(100)+1;
        printf("\nbilangan ke-%d : %d",i+1,Y[i]);
    }
// untuk memanggil fungsi quick
quick(0,jml-1);
//untuk menampilkan hasil pengurutan
printf("\n\ndata yang telah diurut : ");
    for(i=0;i<jml;i++)
    {
        printf(" %d",Y[i]);
    }
}

//fungsi quick sort
int quick(int bawah ,int atas)
{
    int pivot, temp, i,x;
    if(bawah<atas)
    {
    i=bawah;
    x=atas;

    pivot=Y[x];

    do
    {
        while(i<x && Y[i]<= pivot)
        {
        i++;
            }
        while(x>i && Y[x]>= pivot)
        {
        x--;
            }
        if(i<x)
        {
            temp=Y[i];
            Y[i]=Y[x];
            Y[x]=temp;
        }
    }

    while(i<x);
    temp=Y[x];
    Y[x]=Y[atas];
    Y[atas]=temp;
    if(x-bawah<atas-1)
        {
            quick(bawah,x-1);
            quick(i+1,atas);
        }
    else
        {
            quick(i+1,atas);
            quick(bawah,x-1);
        }
    }
}


