#include <stdio.h>
#include <stdlib.h>

int bubble(int n);
int a, b=1;
int jml, data[27];

int main()
{
//input banyaknya data
    printf("masukkan jumlah data: ");
    scanf("%d",&jml);
    printf("\n");
// random data
    for(a=0;a<jml;a++)
    {
        data[a]=rand()%(27)+1;
        printf("bilangan ke %d : %d",a+1,data[a]);
        printf("\n");
    }
    printf("\n");
 // mengurutkan data
    bubble(jml);

//menampilkan data
    printf("bilangan yang sudah diurut : \n");
    for(a=0;a<jml;a++)
    {
        printf(" %d", data[a]);
    }
}
//fungsi bubble
int bubble(int n)
{
int temp;
for(a=1;a<=n-1;a++)
{
    for(b=a;b<n;b++)
    {
        if(data[a-1]>data[b])
        {
            temp=data[a-1];
            data[a-1]=data[b];
            data[b]=temp;
        }
    }

}

return 0;

}
