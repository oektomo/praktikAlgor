#include<stdio.h>

int total,data[10],salin[10];

int input()
{
    printf("banyaknya data : ");
    scanf("%d",&total);

    for(int a=0;a<total;a++)
    {
    printf("nilai ke %d : ",a+1);
    scanf("%d",&data[a]);
    }
}

void merge (int salin[],int lowptr,int highptr,int ub)
{
    int x=0;
    int lb=lowptr;
    int mid= highptr -1;
    int n =ub-lb+1;
    while(lowptr<=mid && highptr<=ub)
    {
        if(data[lowptr]<data [highptr])
        {
            salin[x++]=data [lowptr++];
        }
        else
        {
        salin[x++]=data[highptr++];
        }
        while(lowptr<=mid)
        {
            salin[x++]=data[lowptr++];
        }
        while(highptr<=ub)
        {
        salin[x++]=data[highptr++];
        }
        for(int a=0;a<n;a++)
        {
            data[lb+a]=salin[a];
        }
    }
}

void devide(int salin[], int kiri, int kanan)
{
if(kiri<kanan)
{
int mid=(kiri+kanan)/2;
devide(salin,kiri,mid);
devide(salin,mid+1,kanan);
merge(salin,kiri,mid+1,kanan);
}
}

void sort()
{
devide(salin,0,total-1);
}

void view()
{
for(int a=0;a<total;a++)
{
    printf(" %d",data[a]);
}
printf("\n");

}

int main()
{
input();
printf("sebelum di sorting\n");
view();
sort();
printf("sesudah di sorting\n");
view();
}
