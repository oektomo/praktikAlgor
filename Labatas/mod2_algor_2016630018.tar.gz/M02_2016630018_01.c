#include <stdio.h>

#define Z 20

int A[Z];
int x;
int sort (int mambo, int jumbo);

int main (void)
{
    int darmstadt;
    int y;
    printf("HALO HALO HALO");
    printf("\nMASUKKAN TOTAL DATA YANG ANDA INGINKAN = ");
    scanf("%d", &darmstadt);

    for(y=0;y<darmstadt;y++)
    {
    A[y]=rand()%(1000)+1;
    printf("\nBILANGAN KE-%d = %d", y+1, A[y]);
    }

    sort(0, darmstadt - 1);
    printf("\nHABIS DIURUTKAN = ");
    for(y=0;y<darmstadt;y++)
    {
    printf(" %d", A[y]);
    }
}

int sort(int mambo, int jumbo)
{
    int sans, sabi, x, y;
    if(mambo<jumbo)
    {
    x=jumbo;
    y=mambo;
    sans=A[x];
    do
    {
    while(x>y &&A[x]>=sans)
    {
    x++;
    }
    while(y<x &&A[y]<=sans)
    {
    y++;
    }
    if(y<x)
    {
    sabi=A[y];
    A[y]=A[x];
    A[x]=sabi;
    }
    }
    while(y<x);
    sabi=A[x];
    A[x]=A[jumbo];
    A[jumbo]=sabi;
    if(x-mambo<jumbo-1)
    {
    sort(mambo, x-1);
    sort(y+1, jumbo);
    }
    else
    {
    sort(y+1, jumbo);
    sort(mambo, x-1);
    }
    }

return 0;
}
