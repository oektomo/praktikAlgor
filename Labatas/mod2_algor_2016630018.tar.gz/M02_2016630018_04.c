#include<stdio.h>

#define Z 27

int glbg
    (int z);
int bet, x, whor[27], y=1;

int main()
{
    printf("Masukan jumlah angka dengan range 1-27 = ");
    scanf("%d", &bet);

    for(x=0;x<bet;x++)
    {
    whor[x]=rand()%(27)+1;
    printf("Angka ke-%d = %d", x+1, whor[x]);
    printf("\n");
    }

    glbg(bet);

    printf("\AFTER = ");
    for(x=0;x<bet;x++)
    {
    printf("%d", whor[x]);
    }
    }

    int glbg(int n)
    {
    int kong;
    for(x=1;x<n-1;x++)
    {
    for(y=x;y<n;y++)
    {
    if (whor[x-1]>whor[y])
    {
    kong = whor[x-1];
    whor[x-1] = whor[y];
    whor[y]=kong;
    }
    }
    }
}
