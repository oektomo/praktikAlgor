#include<stdio.h>
#include<stdlib.h>
//prototype
int *bubblesort
int data[100];
int main()
{
    int i,jumlah;
    printf("Masukkan jumlah data:");
    scanf("%d",&jumlah);
    printf("%d Element :\n",jumlah);
    for(i=0;i<jumlah;i++)
    {
        printf("%d\n",rand()%(27)+1);
        scanf(&data[i]);
    }
}



