#include<stdio.h>
#include<stdlib.h>

//prototype
void quick_sort(int acak[], int kiri, int kanan);

int main()
{
    int ulang,jumlah,pilih,cekR;
    printf("Masukkan banyak angka random yang ingin dimasukkan:");
    scanf("%d",&jumlah);
    int angka[jumlah];
    printf("Angka Random :\n");
    for(ulang=0;ulang<jumlah;ulang++)
    {
        printf("%d\n",rand()%(50)+1);
    }

    quick_sort(angka,0,jumlah-1);
    printf("Setelah sorting :\n");
    for(ulang=0;ulang<jumlah;ulang++)
    {
        printf("%d ",angka[ulang]);
    }
    return 0;

}
//functon
void quick_sort(int acak[], int kiri, int kanan)
{
    int a=kiri;
    int b=kanan;
    int temp;
    int pivot=acak[(kiri+kanan)/2];

    while(a<=b)
    {
        while(acak[a]<pivot)
        a++;
        while(acak[b]>pivot)
        b--;
        if(a<=b)
        {
            temp=acak[a];
            acak[a]=acak[b];
            acak[b]=temp;
            a++;
            b--;
        }
    }
    if(kiri<b)
    quick_sort(acak,kiri,b);
    if(a<kanan)
    quick_sort(acak,a,kanan);
}



