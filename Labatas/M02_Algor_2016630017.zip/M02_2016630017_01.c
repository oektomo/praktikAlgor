#include <stdio.h>
#include <stdlib.h>

int quick(int bawah , int atas);
int i,j,A[100];

int main()
{

    int jumlah;

    printf("Banyak Data Yang Diinginkan : ");
    scanf("%d",&jumlah);

    printf("\n\nSilahkan Masukkan Data !");

    for( i=1 ; i<=jumlah ; i++)
        {
            printf("\nMasukkan Data Ke %d : ",i);
            scanf("%d",&A[i]);

        }
    quick (0 , jumlah-1);

    printf("\nData Urut : ");
    for( i=1 ; i<=jumlah ; i++)
        {
            printf("%d\t",A[i]);
        }

}

int quick(int bawah , int atas)
{
    int pivot , temp;

    if(bawah<atas)
    {
        i = bawah;
        j = atas;
        pivot = A[j];




    do
    {
        while(i<j && A[i]<=pivot)
        {
            i++;
        }

        while(j>i && A[j]>=pivot)
        {
            j--;
        }

        if(i<j)
        {
            temp = A[i];
            A[i]=A[j];
            A[j]=temp;
        }
    }
    while(i<j);;

    temp=A[j];
    A[j]=A[atas];
    A[atas]=temp;

    if(j-bawah<atas-i)
    {
        quick (bawah, j-1);
        quick (i+1,atas);
    }
    else
    {
        quick (j+1, atas);
        quick(bawah , i-1);
    }
}
}




