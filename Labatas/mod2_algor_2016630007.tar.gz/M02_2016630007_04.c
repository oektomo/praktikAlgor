#include<stdio.h>
#include<stdlib.h>

int bubble(int n);
int q, w=1;
int j, data[27];

int main()
{
    printf("Masukkan Banyak Data: ");
    scanf("%d", &j);
    printf("\n");

    for(q=0;q<j;q++)
    {
        data[q]=rand()%(27)+1;
        printf("Bilangan ke %d: %d", q+1,data[q]);
        printf("\n");

    }
    printf("\n");

    bubble(j);
    printf("Bilangan Yang Sudah Diurut: \n");
    for(q=0;q<j;q++)
    {
        printf(" %d", data[q]);
    }
}

int bubble(int n)
{
int temp;
for(q=1;q<=n-1;q++)
{
    for(w=q;w<n;w++)
    {
        if(data[q-1]>data[w])
        {
            temp=data[q-1];
            data[q-1]=data[w];
            data[w]=temp;
        }
    }
}
return 0;
}
