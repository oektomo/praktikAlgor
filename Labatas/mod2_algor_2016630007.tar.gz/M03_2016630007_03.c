#include<stdio.h>

 int tot,data[10],salin[10];

 int input()
 {
    printf("Banyaknya Data: ");
    scanf("%d",&tot);

    for(int q=0;q<tot;q++)
    {
        printf("Nilai ke %d: ", a+1);
        scanf("%d", &data[a]);
    }
 }

void merge (int salin[],int lowptr, int highptr, int ub)
{
    int x=0;
    int lb=lowptr;
    int mid=highptr -1;
    int n=ub-lb +1;
    while(lowptr<=mid && highptr<=ub)
    {
        if(data[lowptr]<data[highptr])
        {
            salin[x++]=data[lowptr++];
        }
        else
        {
            salin[x++]=data[highptr++];
        }
        while(lowptr<=mid)
        {
            salin[x++]=data[lowptr++];
        }
        while(highptr<=ub)
        {
            salin[x++]=data[highptr++];
        }
        for(int q=0;q<n;q++)
        {
            data[lb+q]=salin[q];
        }
    }
}

void device
