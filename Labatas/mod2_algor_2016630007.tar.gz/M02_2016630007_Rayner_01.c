#include<stdio.h>
#include<stdlib.h>
#define Nilai 10

int q(int a, int b);
int k, L[Nilai];

int main()

{
int w, J;
    printf("Masukkan Banyak Data: ");
    scanf("%d", &J);

    for(w=0;w<J;w++)
    {
        L[w]=rand()%(10)+1;
        printf("\nBilangan ke %d: %d", w+1,L[w]);
    }

    quick(0,J-1);
    printf("\nData Yang Telah DiUrut: ");
    for(w=0;w<J;w++)
    {
        printf(" %d", L[w]);
    }

}

int quick(int b, int a)
{
    int pivot, temp, w, z;
    if(b<a)
    {
        w=b;
        z=a;
        pivot=L[z];

        do
        {
            while(w<z &&L[w]<=pivot)
            {
                w++;
            }
            while(z>w &&L[z]>=pivot)
            {
                z--;
            }
            if(w<z)
            {
                temp=L[w];
                L[w]=L[z];
                L[z]=temp;
            }
        }
        while(w<z);
        temp=L[z];
        L[z]=L[a];
        L[a]=temp;
        if(z-b<a-1)
        {
            quick(b,z-1);
            quick(w+1,a);

        }
        else
        {
            quick(w+1,a);
            quick(b,z-1);
        }
    }
}
