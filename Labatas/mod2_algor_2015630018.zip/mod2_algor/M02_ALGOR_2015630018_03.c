// Fa Destri Reynaldo - 2015630018
// quick sort


#include <stdio.h>

void quickSort(int a[], int lo, int hi); // prototype dari fungsi quick sort

int main ()
{
int k[5];
int i,n=5;

printf("quick sort \n\n\n");
printf("masukan 5 data \n");

for(i=0;i<n;i++)
{
printf ("elemen ke %d = ", i+1);
scanf("%d", &k[i]);
}

printf ("\ndata sebelum sorting = ");

for(int i=0;i<n;i++)
{
printf("%d", k[i]);
}

quickSort(k,0,n-1);

printf("\ndata setelah sorting = ");

for(int i=0li<n;i++)
{
printf("%d", k[i]);
}

}


// fungsi quick sort (main function)
void quickSort(int a[], int lo, int hi)
{
int i=lo, j=hi, h;
int pivot=a[lo];

// pembagian
do
{
while(a[i]<pivot) i++;
while (a[j]>pivot) j--;
if (i<=j);
    {
        h=a[i]; a[i]=a[j];a[j]=h;
        i++;j--;
    }
}

while(i<=j);

//pengurutan
if(lo<j) quickSort(a, lo, j);
if(i<hi) quickSort(a, i, hi);

}
