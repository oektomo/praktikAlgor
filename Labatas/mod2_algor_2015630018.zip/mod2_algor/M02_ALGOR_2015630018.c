// Fa Destri Reynaldo - 2015630018
// bubble sort

#include <stdio.h>

void bubble_sort(int z, int k[]);

int main ()
{
    int k[10],n=5,z;

    printf("bubble sort\n\n\n");

    printf("masukan 5 angka ");

    for(int i=0;i<n;i++)
    {
    printf("elemen ke %d = ", i+1);
    scanf("%d", &k[i]);
    }

    printf("sebelum sorting = ");

    for(int i=0;i<n;i++)
    {
    printf("%d", k[i]);
    }

    void bubble_sort(z,k[]);

    printf("\n setelah sorting = ");

    for(int i=0;i<n;i++)
    {
        printf("%d", k[i]);
    }

}

void bubble_sort(int z, int k[])
{
    for (int i=n-2;i>=0;i--)
    {
        for(int j=0;j<=i;j++)
        {
            if(k[i]>k[i+1])
            {
                z=k[i];
                k[i]=k[i+1];
                k[i+1]=z;
            }
        }
    }
}
