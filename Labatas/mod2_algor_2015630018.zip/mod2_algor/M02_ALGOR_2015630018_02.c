
#include <stdio.h>
#define MAX 5

int data[MAX];
int temp[MAX];

void merge(int data[], int temp, int kiri, int tengah, int kanan);
void merge_sort(int data[], int temp[], int kiri; int kanan);
void mergeSort(int data[], int temp[], int array_size);

int main()
{


printf("merge sort\n\n\n");
printf("masukan 5 elemen ");

for(int i=0;i<MAX;i++)
{
printf("data ke %d = ", i+1);
scanf("%d", &data[i]);
}

printf("\ndata sebelum sorting = ");

for (int i=0;i<n;i++)
{
    printf(" %d ", data[i]);
}

mergeSort(data, temp, MAX);

printf("\ndata setelah sorting = ");

for(int i=0;i<MAX;i++)
{
    printf(" %d ", data[i]);
}

}

// merge sort procedur

void merge(int data[], int temp, int kiri, int tengah, int kanan)
{
int i, left_end, num_element, tmp_pos;
left_end=tengah-1;
tmp_pos=kiri;
num_element=kanan-kiri+1;

while ((kiri<=left_end) && (tengah<=kanan))
{
    if(data[kiri]<=data[tengah])
    {
    temp[tmp_pos]=data[kiri];
    tmp_pos=tmp_pos+1;
    kiri=kiri+1;
    }
    else
    {
    temp[tmp_pos]=data[tengah];
    tmp_pos=tmp_pos+1;
    tengah=tengah+1;
    }
}

while(kiri<=left_end)
{
temp[tmp_pos]=data[kiri];
kiri=kiri+1;
tmp_pos=tmp_pos+1;
}

while (tengah<=kanan)
{
temp[tmp_pos]=data[tengah];
tengah=tengah+1;
tmp_pos=tmp_pos+1;
}

for(int i=0;i<=num_element;i++)
{
data[kanan]=temp[kanan];
kanan=kanan-1;
}

// prosedur membuat kumpulan data

void merge_sort(int data[], int temp[], int kiri; int kanan)
{
int tengah;
int (kanan>kiri)
    {
tengah=(kanan+kiri)/2;
merge_sort(data, temp, kiri, tengah);
merge_sort(data, temp, tengah+1; kanan);
merge(data, temp, kiri, tengah+1, kanan);
    }
}

// sorted

void mergeSort(int data[], int temp[], int array_size)
{
merge_sort(data, temp,0,array_size-1);
}

}

