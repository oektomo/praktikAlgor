#include<stdio.h>
#include<stdlib.h>
#define N 27

int bubble(int n);
int a,b=1;
int jml,array[27];

int main(void)
{
    printf(" bubble sort\n\n");
    printf("masukan jumlah bilangan(maks 27): ");
    scanf("%d", &jml);
    printf("\n");

    // input data

    for(a=0;a<jml;a++)
    {
    array[a]=rand()%(27+1);
    printf("bilangan ke %d: %d",a+1,array[a]);
        printf("\n");
    }
    printf("\n");

int bubble(int n)
 {
    int temp;
    for(a=1;a<=n;a++)
    {
        for(b=a;b<n;b++)
        {
            if(array[a-1]>array[b])
            {
                temp=array[a-1];
                array[b]=temp;

            }
        }
    }
 }
return 0;
}
    // sorting data

    bubble(jml);

    //menampilkan data

    printf("bilangan yang sudah di sorting: \n");
    for(a=0;a<jml;a++)
    {
        printf(" %d", array[a]);
        }

 // fungsi bubble


