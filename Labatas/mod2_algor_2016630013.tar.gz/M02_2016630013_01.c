/**
*
*
*
*
*
*
*
*/

#include<stdio.h>
#include<stdlib.h>

int array[100];// deklarasi array

int quick(int top, int bot);// deklarasi fungsi

int main()
{
    int a,n;

    printf("Masukan jumlah input:");// input jumlah bilangan
    scanf("%d", &n);

    for(a=0;a<n;a++)// loop untuk mengeluarkan bilangan random
    {
        array[a]=rand()%(1000)+1;
        printf("input ke %d: %d\n",a+1,array[a]);
    }

    printf("Data yang tersortir:\n");// output
    quick(0,n-1);
    for(a=0;a<n;a++)
    {
        printf("%d\n", array[a]);
    }

}


int quick(int bot, int top) // fungsi quicksort
{
    int a,pivot,temp,x;

    if (bot<top)// loop untuk sorting
    {
    a=bot;
    x=top;

    pivot=array[a];

    do{
        while (a<x && array[a]<=pivot)
        {
            a++;
        }
        while (x>a && array>=pivot)
        {
            x--;
        }
        if (a<x)
        {
        temp = array[a];
        array[a]=array[x];
        array[x]=temp;
        }
    }while(a<x);
    temp=array[x];
    array[x]=array[top];
    array[top]=temp;

    if(x-bot<top-1){
        quick(bot,x-1);
        quick(a+1,top);
    }else
        {
        quick(a+1,top);
        quick(bot,x-1);
        }
    }
}
