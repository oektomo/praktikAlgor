#include<stdio.h>

int total,array[100],copy[100];

void input()
{
    printf("Masukan Jumlah nilai: ");
    scanf("%d", &total);

    for(int a=0;a<total;a++)
        {
        printf("Input nilai ke %d: ", a+1);
        scanf("%d", &array[a]);
        }
}

void merge(int copy[],int lowptr,int highptr,int upperbound)
{
    int x=0;
    int lowerbound=lowptr;
    int mid=highptr-1;
    int n=upperbound-lowerbound+1;
    while(lowptr<=mid && highptr<=upperbound)
    {
    if(array[lowptr]<array(highptr))
    {
        copy[x++]=array[lowptr++];
    }
    else

    {
    copy[x++]=array[highptr++];
    }
    while(lowptr<=mid)
        {
        copy[x++]=array[lowptr++];
        }
    while(highptr<=upperbound)
        {
        copy[x++]=array[highptr++];
        }
    for(int a=0;a<n;a++)
    {
    array[lowerbound+a]=copy[a];
    }
    }
}

void bagi(int copy[],int kiri,int kanan)
{
    if(kiri<kanan)
    {
    int mid=(kiri+kanan)/2;
    bagi(copy,kiri,mid);
    bagi(copy,mid+1,kanan);
    merge(copy,kiri,mid+1,kanan);
    }
}

void sort()
{
    bagi(copy,0,total-1);
}

void view()
{
    for(int a=0;a<total;a++)
    {
        printf("%d", array[a]);
    }
    printf("\n");
}

int main()
{
input();
printf("sebelum di sorting\n");
view();
sort();
printf("sesudah di sorting\n");
view();
}
