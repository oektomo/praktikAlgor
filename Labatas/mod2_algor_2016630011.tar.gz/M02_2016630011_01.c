#include <stdio.h>
#define N 20

int quick(int atas,int bawah);
int j,A[N];
int main()
{
int x,jumlah;

printf("masukkan data : ");
scanf("%d",jumlah);

    for(x=0;x<jumlah;x++)
    {
        A[x]=rand()%(1000)+1;
    printf("\n\nbilangan ke-%d : %d",x+1,A[x]);
    }

    quick(0,jumlah - 1);
    printf("\n\ndata yang telah diurut ; ");
    for(x=0;x<jumlah;x++)
    {
        printf("%d",A[x]);
    }
}

int quick(int bawah,int atas)
{
int pivot,temp,a,b;
if(bawah<atas)
{
    b=bawah;
    a=atas;

    pivot=A[a];

    do
    {
        while(b<a &&A[b]<=pivot)
        {
        b++;
        }
        while(a>b &&A[a]>=pivot)
        {
        a++;
        }
        if(b<a)
        {
            temp=A[b];
            A[b]=A[a];
            A[a]=temp;
        }
    }
while(b<a);
temp=A[a];
A[a]=A[atas];
A[atas]=temp;
if(atas-bawah<atas-1)
{
    quick(bawah,a-1);
    quick(b+1,atas);
    }
    else
    {
        quick(b+1,atas);
        quick(bawah,a-1);
    }
}}

