#include <stdio.h>

int total,data[10],salin[10];
void input()
{
printf("Input : ");
scanf("%d",&total);

for(int a=0;a<total;a++)
    {
    printf("masukkan nilai index ke-%d : ",a+1);
    scanf("%d",&data[a]);
    }
}

void merge(int salin,int low,int high,int upperbound)
{
int x;
int lowerbound=low;
int mid=high-1;
int n=upperbound-lowerbound+1;
while (low<=mid && high<=upperbound)
    {
    if (data[low]<data[high]){
    salin[x++]=data[low++];
    }
    else{
    salin[x++]=data[high++];
    }
    while(low<=mid){
    salin[x++]=data[low++];
    }
    while(high<=upperbound){
    salin[x++]=data[high++];
    }
    for(int a=0;a<n;a++){
    data[lowerbound+a]=salin[a];
    }
    }
}
void devide(int salin[],int kiri,int kanan){
if(kiri<kanan){
int mid=(kiri+kanan)/2;
devide(salin,kiri,mid);
devide(salin,mid+1,kanan);
merge(salin,kiri,mid+1,kanan);
}
}

void sort()
{
devide(salin,0,total-1);
}
void view()
{
for(int a=0;a<total;a++){
printf("%d",data[a]);
}
printf("\n");
}

int main(){
input();
printf("sebelum sorting\n");
view();
sort();
printf("sesudah sorting\n");
view();
}
