#include<stdio.h>

void bubblesort(int data[], int n)
{
    int i, j=0, temp, flag=1;

    while(flag)
    {
        flag=0;
        for(i=0;i<n;i++)
        {
            if(data[i]>data[i+1])
            {
                temp=data[i];
                data[i]=data[i+1];
                data[i+1]=temp;
                flag++;
            }
        }
    }
}

int main()
{
    int data[20];
    int n,i;

    printf("Masukan jumlah data (Maks 20): ");
    scanf("%d",&n);
    printf("\nMasukan data :\n");

    for(i=0;i<n;i++)
        scanf("%d",&data[i]);

    bubblesort(data,n);
    printf("\nOutput sesudah sorting :\n");

    for(i=1;i<n+1;i++)
        printf("%d ",data[i]);

    return 0;
}
