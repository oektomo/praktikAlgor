#include<stdio.h>

int ttl,data[100],sln[100];
void input()
{
printf("Masukkan nilai : ");
scanf("%d",&ttl);

    for(int a=0;a<ttl;a++)
    {
    printf("Masukkan nilai pada index ke %d : ",a+1);
    scanf("%d",&data[a]);
    }
}

void merge(int sln[],int lowpointer,int highpointer,int upperbound)
{
int y=0;
int lowerbound = lowpointer;
int mid = highpointer-1;
int d = upperbound-lowerbound+1;

while (lowpointer<=mid && highpointer<=upperbound)
{

if(data[lowpointer]<data[highpointer])
{
sln[y++] = data[lowpointer++];
}
else
{
sln[y++] = data[highpointer++];
}
while(lowpointer<=mid)
{
sln[y++] = data[lowpointer++];
}
while(highpointer<=upperbound)
{
sln[y++] = data[highpointer++];
}
for (int a=0;a<d;a++)
{
data[lowerbound+a]=sln[a];
}

}

}

void devide(int sln[],int kiri,int kanan)
{
if(kiri<kanan)
{
int mid=(kiri + kanan)/2;
devide(sln,kiri,mid);
devide(sln,mid+1,kanan);
merge(sln,kiri,mid+1,kanan);
}
}

void sort()
{
devide(sln,0,ttl-1);
}

void view()
{
for(int a=0;a<ttl;a++)
{
printf("%d",data[a]);
}
printf("\n");
}

int main()
{
input();
printf("\nSebelum di sorting\n");
view();
sort();
printf("\nSesudah di sorting\n");
view();
}
