#include<stdio.h>
#include<stdlib.h>
#define N 20

int quick(int bwh,int ats);
int x,A[N];
int main()
{

int a,jmlh;

printf("Masukkan jumlah data :");
scanf("%d",&jmlh);

    for(a=0;a<jmlh;a++)
    {
        A[a]=rand()%(1000)+1;
        printf("Bilangan ke %d : ",a+1);
        scanf("%d",&A[a]);
    }

    quick(0,jmlh - 1);
    printf("\nData yang telah diurut : ");

    for(a=0;a<jmlh;a++)
    {
        printf("%d",A[a]);
    }

}

int quick(int bwh,int ats)
{

    int pivot,temp,a,x;
    if(bwh<ats)
    {
    a=bwh;
    x=ats;
    pivot=A[x];

    do
    {
        while(a<x &&A[a]<=pivot)
            {
                a++;
            }
        while(x>a &&A[a]>=pivot)
            {
                x--;
            }

    if (a<x)
        {
        temp=A[a];
        A[a]=A[x];
        A[x]=temp;
        }

    }
        while(a<x);
        temp=A[x];
        A[x]=A[ats];
        A[ats]=temp;

        if(x-bwh<ats-1)
        {
        quick(bwh,x-1);
        quick(a+1,ats);
        }
            else
            {
            quick(a+1,ats);
            quick(bwh,x-1);
            }
    }


}
