#include<stdio.h>
#include<stdlib.h>
#define N 27

int bubble(int n);
int a,b=1;
int jumlah,data[27];

int main(void)
{
printf("Bubble Sort \n\n");
printf("Masukkan jumlah bilangan(MAKS 27) : ");
scanf("%d",&jumlah);
printf("\n");

for(a=0;a<jumlah;a++)
{
data[a]=rand()%(27)+1;
printf("Bilangan ke %d : ",a+1);
scanf("%d",&data[a]);
printf("\n");
}
printf("\n");

bubble(jumlah);

printf("Bilangan yang diurut : \n");
for(a=0;a<jumlah;a++)
{
printf("%d",data[a]);
}
}

int bubble(int n)
{
int temp;
        for(a=1;a<=n-1;a++)
        {
            for(b=a;b<n;b++)
            {
            if(data[a-1]>data[b])
            {
            temp = data[a-1];
            data[a-1] = data[b];
            data[b]=temp;
            }
        }
    }

    return 0;
}

