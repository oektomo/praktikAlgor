#include<stdio.h>

void bubble(int *ptr,int s)
{
int i,j;
int temp;
for(i=1;i<s;i++)
    {
    for(i=1;j<s-i;j++)
        {
        if((*ptr+j)>*(ptr+j+1))
            {
            temp=*(ptr+j);
            *(ptr+j)=*(ptr+j+1);
            *(ptr+j+1)=temp;
            }
        }
    }
}

void main()
{
int arr[100];
int i;
int size;

printf("\nMasukan array:")
scanf("%d",&size);
printf("\nMasukan Bilangan");
for(i=0;i<size;i++)
scanf("%d",&arr[i]);

bubble(arr,size);
for(i=0;i<size;i++)
printf("%d",arr[i]);

getch();
}
