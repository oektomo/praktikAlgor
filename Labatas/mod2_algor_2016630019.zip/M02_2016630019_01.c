#include<stdio.h>
#include<stdlib.h>

int quick(int bawah, int atas);
int i, j,A[100];
main()
{
int jumlah;
printf("masukan jumlah");
scanf("%d",&jumlah);
for(i=0;i<jumlah;i++)
    {
    printf("bilangan ke %d :",i+1);
    scanf("%d",&A[i]);
    }
quick(0,jumlah-1);
printf("data urut:\n");
for(i=0;i<jumlah;i++)
    {
    printf("%d\n",A[i]);
    }
}

int quick(int bawah, int atas)
    {
    int pivot, temp;
    if(bawah<atas)
        {
        i=bawah;
        j=atas;
        pivot=A[j];
        do
            {
            while(i<j&&A[i]<=pivot)
                {
                i++;
                }
            while(j>i&&A[j]>=pivot)
                {
                j--;
                }
            if(i<j)
                {
                temp=A[i];
                A[i]=A[j];
                A[j]=temp;
                }
            }
        while (i<j);
        temp=A[j];
        A[j]=A[atas];
        A[atas]=temp;
        if(j-bawah<atas-i)
            {
            quick(bawah,j-1);
            quick(i+1,atas);
            }
            else
            {
            quick(i+1,atas);
            quick(bawah,j-1);
            }
        }
    }
