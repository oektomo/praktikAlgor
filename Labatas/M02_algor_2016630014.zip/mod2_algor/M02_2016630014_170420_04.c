#include<stdio.h>
#define N 27

int bubble(int n);
int a,b=1;
int jml,data[27];

int main(void)
{

    printf("bubble sort \n\n");
    printf("masukan jumlah bilangan (maks 27): ");
    scanf("%d", &jml);
    printf("\n");

    for(a=0;a<jml;a++)
    {
        data[a]=rand()%(27)+1;
        printf("bilangan ke %d: %d",a+1, data[a]);
        printf("\n");
    }
    printf("\n");

    bubble(jml);

    printf("bilangan yang sudah diurut : \n");
    for(a=0;a<jml;a++)
    {
        printf("%d",data[a]);
        }
    }

int bubble(int n)
{
    int temp;
    for(a=1;a<=n-1;a++)
    {
        for(b=a;b<n;b++)
        {

    if(data[a-1]>data[b])
    {
        temp = data[a-1];
        data[a-1]=data[b];
        data[b]=temp;
        }
        }
        }

return 0;
}


