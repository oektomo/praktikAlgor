#include<stdio.h>
#define N 20

int quick(int bawah, int atas);
int j,A[N];
int main()
{

int i, jumlah;

printf("masukan jumlah data : ");
scanf("%d", &jumlah);

    for(i=0;i<jumlah;i++)
    {

    A[i]=rand()%(1000)+1;
    printf("\nbilangan ke-%d : %d",i+1);
    }

    quick(0,jumlah-1);
    printf("\n\ndata yang telah diurut : ");
    for(i=0;i<jumlah;i++)
    {

        printf("%d",A[i]);
        }
}

int quick(int bawah,int atas)
{
     int pivot,temp,i,j;
     if(bawah,atas)
     {

     i=bawah;
     j=atas;

     pivot=A[j];

     do
     {

            while(i<j &&A[i]<=pivot)
            {
                i++;
                }
            while(j>i &&A[j]>=pivot)
            {
                j--;
                }
            if(i<j)
            {
                temp=A[i];
                A[i]=A[j];
                A[j]=temp;
                }
            }
        while(i<j);
        temp=A[j];
        A[j]=A[atas];
        A[atas]=temp;
        if(j-bawah<atas-1)
        {
            quick(bawah,j-1);
            quick(i+1,atas);
            }
            else
            {
                quick(i+1,atas);
                quick(bawah,j-1);
                }
        }
        }

