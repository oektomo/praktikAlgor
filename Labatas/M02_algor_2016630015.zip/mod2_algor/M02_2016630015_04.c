#include<stdio.h>

#define N 99

int bubble(int n);
int a,b=1;
int jumlah, data[99];

int main(void)
{
    printf("Masukkan banyaknya bilangan (max 99) : ");
    scanf("%d", &jumlah);
    printf("\n");
    printf("==================================\n");
    for(a=0;a<jumlah;a++)
    {
        data[a]=rand()%(100)+1;
        printf("Bilangan ke %d : %d               |", a+1, data[a]);
        printf("\n");
    }
    printf("==================================\n");
    printf("\n");

    bubble(jumlah);

    printf("Bilangan yang sudah diurutkan : \n");
    for (a=0;a<jumlah;a++)
    {
        printf("%d\n", data[a]);
    }
}

int bubble(int n)
{
    int temp;
    for(a=1;a<=n;a++)
    {
        for(b=a;b<=n-1;b++)
        {
            if(data[a-1]>data[b])
            {
                temp=data[a-1];
                data[a-1]=data[b];
                data[b]=temp;
            }
        }
    }
return 0;
}
