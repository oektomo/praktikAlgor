#include<stdio.h>
#define n 99

int quick(int bawah, int atas);
int j, a[n];

int main()
{
    int i, jumlah;

        printf("Masukkan jumlah data (max 99) : ");
        scanf("%d", &jumlah);
        printf("========================\n");
            for(i=0;i<jumlah;i++)
            {
                a[i]=rand()%(100)+1;
                printf("Bilangan ke %d : %d\n", i+1);
            }
        printf("========================\n");
        quick(0, jumlah-1);
        printf("\nData yang telah diurut : ");
            for(i=0;i<jumlah;i++)
            {
                printf("\n%d", a[i]);
            }

}



int quick(int bawah, int atas)
{
    int pivot, temp, i ,j;
    if(bawah<atas)
    {
        i=bawah;
        j=atas;
        pivot=a[j];

        do
        {
            while(i<j&&a[i]<=pivot)
            {
                i++;
            }

            while(j>i&&a[j]>=pivot)
            {
                j--;
            }
            if(i<j)
            {
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
            }

        }
        while(i<j);
        temp=a[j];
        a[j]=a[atas];
        a[atas]=temp;
        if(j-bawah<atas-1)
        {
            quick(bawah, j-1);
            quick(i+1, atas);
        }

        else
        {
            quick(i+1, atas);
            quick(bawah, j-1);
        }
    }
}
