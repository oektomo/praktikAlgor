#include<stdio.h>

int total, data[10], salin[10];

int main()
{
    input();
    printf("\nSebelum diurutkan\n");
    view();
    sort();
    printf("Sesudah diurutkan\n");
    view();
}

void input()
{
    printf("Masukkan banyaknya urutan : ");
    scanf("%d", &total);
    printf("===============================\n");

    for(int a=0; a<total; a++)
    {
        printf("masukkan nilai pada urut ke %d : ", a+1);
        scanf("%d", &data[a]);
    }
    printf("================================\n");
}

void merge(int salin[], int bawah, int atas, int atas1)
{
    int x=0;
    int bawah1=bawah;
    int tengah=atas-1;
    int n=atas1-bawah1+1;

    while(bawah<=tengah&&atas<=atas1)
    {
        if(data[bawah]<data[atas])
        {
            salin[x++]=data[bawah++];
        }
        else
        {
            salin[x++]=data[bawah++];
        }
        while(atas<=tengah)
        {
            salin[x++]=data[bawah++];
        }
        while(atas<=atas1)
        {
            salin[x++]=data[atas++];
        }
        for(int a=0;a<n;a++)
        {
            data[bawah1+a]=salin[a];
        }
    }
}

void devide(int salin[], int kiri, int kanan)
{
    if(kiri<kanan)
    {
    int tengah=(kiri+kanan)/2;
    devide(salin,kiri,tengah);
    devide(salin,tengah+1,kanan);
    merge(salin,kiri,tengah+1,kanan);
    }
}

void sort()
{
    devide(salin,0,total-1);
}

void view()
{
    for(int a=0;a<total;a++)
    {
        printf("%d\n", data[a]);
    }
    printf("\n");
}

