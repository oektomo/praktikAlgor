#include <stdio.h>
#define n 20
int quick (int t,int d );
int k,X[n];
int main ()
{
int l,jumlah;

printf("masukkan jumlah data :");
scanf("%d",&jumlah);

    for(l=0;l<jumlah;l++)
    {
        X[l]=rand()%(1000)+1;
        printf("\nbilangan ke-%d : ",l+1);
        scanf("%d", &X[l]);
    }

    quick(0,jumlah-1);
    printf("\n\ndata yang telah diurut :");
    for(l=0;l<jumlah;l++)
    {
    printf("\n%d",X[l]);
    }
}
int quick (int d,int t)
{
int pivot,temp,l,k;
if(d<t)
{
l=d;
k=t;
pivot=X[k];
do
{
  while(l<k &&X[l]<=pivot)
  {
  l++;
  }
  while (k>l &&X[k]>=pivot)
  {
  k--;
}
if (l<k)
{
temp=X[l];
X[l]=X[k];
X[k]=temp;
}
}
while (l<k);
temp=X[k];
X[k]=X[t];
X[t]=temp;
if(k-d<t-1)
{
quick(d,k-1);
quick(l+1,t);
}
else
{
quick(l+1,t);
quick(d,k-1);
}
}
}
