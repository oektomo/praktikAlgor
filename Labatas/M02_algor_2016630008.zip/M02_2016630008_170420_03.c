#include<stdio.h>
int ttl,data[10],sln[10];
void input () {
    printf("masukan banyak input = ");scanf("%d",&ttl);

    for(int a=0;a<ttl;a++){
    printf("masukkan nilai  ke %d = ",a+1);scanf("%d",&data[a]);

    }
}
void merge(int salin [],int lwptr,int highptr,int ub){
int x=0;
int lowerbound=lwptr;
int mid=highptr-1;
int n=ub-lowerbound+1;
while(lwptr<=mid && highptr<=ub){
if(data[lwptr]<data[highptr]){
salin[x++]=data[lwptr++];

}
else{
salin[x++]=data[highptr++];
}
while(lwptr<=mid){
salin[x++]=data[lwptr++];
}
while(highptr<=ub){
salin[x++]=data[highptr++];
}
for(int a=0;a<n;a++){
data[lowerbound+a]=salin[a];
}
}
}
void devide(int salin[],int kiri,int kanan){
if(kiri<kanan){
int mid=(kiri+kanan)/2;
devide (salin,kiri,mid);
devide (salin,mid+1,kanan);
merge(salin,kiri,mid+1,kanan);
}
}
void sort (){
devide(sln,0,ttl-1);
}
void view(){
for(int a=0;a<ttl;a++){
printf("%d",data[a]);
}
printf("\n");
}
int main(){
input();
printf("sebelum  sorting\n");
view();
sort();
printf("sesudah  sorting\n");
view();
}

