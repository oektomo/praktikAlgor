#include <stdio.h>
#include <stdlib.h>

struct NODE
    {
    int number;
    struct NODE *next;
    };

    void append_node(struct NODE *llist, int num);
    int search_value(struct NODE *llist,int num);
    void display_list(struct NODE *llist);

    int main (void)
        {
        int num=0;
        int input = 5;
        int retval = 0;
        int banyak,i,baru,posisi;
        struct NODE *llist;

        llist = (struct NODE *)malloc(sizeof(struct NODE));
        llist->number = 0;
        llist ->next = NULL;
            printf("jumlah node : ");
            scanf("%d",&banyak);
            for(i=0;i<banyak;i++)
                {
                printf("masukkan nilai node %d : ",i+1);
                scanf("%d",&num);
                append_node(llist,num);
                }
                printf("\n");
                    display_list(llist);
                    printf("jumlah node : %d\n",banyak);
                    printf("masukkan nilai yang akan di cari ");
                    scanf("%d",&num);
                    if((retval = search_value(llist,num))==-1)
                    printf("nilai %d tidak ditemukan\n",num);
                    else
                    printf("nilai %d ada di node %d\n",num,retval);
                    free(llist);
                    return(0);
        }
        void append_node(struct NODE *llist,int num)
            {
            while (llist->next != NULL)
            llist = llist->next;
            llist->next=(struct NODE *)malloc(sizeof(struct NODE));
            llist->next->number=num;
            llist->next->next=NULL;

            }

        int search_value(struct NODE *llist,int num)
            {
            int retval = -1;
            int i =1;
            while (llist->next !=NULL)
                {
                if(llist->next->number==num)
                    return i;
                    else
                    i++;

                llist=llist->next;
                }
                return retval;
                }

        void display_list(struct NODE *llist)
            {
            int a=1;
            while (llist->next != NULL)
                {
                llist=llist->next;
                printf("node %d = %d\n",a,llist->number);
                a++;
                }


            }
