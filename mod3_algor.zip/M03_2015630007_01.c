/*
* Bagas Fadilla A - 201563007
* Linked list menu full
*/

#include <stdio.h>
#include <stdlib.h>

struct node
{
    int number;
    struct node *next;

};

int search_value(struct node *llist, int num);
void append_node(struct node *llist, int num);
void display_list(struct node *llist);
void delete_node(struct node *llist, int num);

int main()
{
int num = 0;
int input = 1;
int retval = 0;
struct node *llist;

llist = (struct node *)malloc(sizeof(struct node));
llist->number = 0;
llist->next = NULL;

while (input != 0)
{
    printf("\n ===Menu Selection==\n");
    printf("0). quit\n");
    printf("1). insert\n");
    printf("2). delete\n");
    printf("3). search\n");
    printf("4). display\n");
    scanf("%d", &input);

    switch(input)
    {
        case 0:
        default:
        printf("byee.\n");
        input = 0;
        break;

        case 1:
        printf("Yang dipilih: 'insertion'\n");
        printf("enter the value which should be inserted: ");
        scanf("%d", &num);
        append_node(llist, num);
        break;

        case 2:
        printf("YAng dipilih : 'deletion'\n");
        printf("enter the value which should be inserted: ");
        scanf("%d", &num);
        delete_node(llist, num);
        break;

        case 3:
        printf("Yang dipilihh : 'search'\n");
        printf("enter the value which should be inserted: ");
        scanf("%d", &num);
        if((retval = search_value(llist, num))== -1)
        printf("value '%d' not found\n", num);
        else
        printf("value '%d' located at position '%d' \n", num, retval);
        break;

        case 4:
        printf("Yang dipilihh: 'display'\n");
        display_list(llist);
        break;
    }
}
    free(llist);
    return(0);
}
    void display_list(struct node *llist){
    while (llist->next != NULL){
    printf("%d", llist->number);
    llist = llist->next;
    }
    printf("%d", llist->number);
    }

    void append_node(struct node *llist, int num)
    {
        while(llist->next !=NULL)
        llist = llist->next;

        llist->next = (struct node *)malloc(sizeof(struct node));
        llist->next->number = num;
        llist->next->next = NULL;
    }

    void delete_node(struct node *llist, int num)
    {
        struct node *temp;
        temp = (struct node *)malloc(sizeof(struct node));

        if(llist->number == num)
        {
            temp = llist->next;
            free(llist);
            llist = temp;
        }
    }

    int search_value(struct node *llist, int num)
    {
        int retval = -1;
        int i = 1;

        while(llist->next != NULL)
        {
            if(llist->next->number == num)
            return i;
            else
            i++;

            llist = llist->next;
        }
        return retval;
    }
