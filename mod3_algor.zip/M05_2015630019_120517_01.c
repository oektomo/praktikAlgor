/**
* M05_2015630019_120517_01.c
*
* created on : 12 05,2017
* Author     : Pascalis Apriyatna - 2015630019
*
* @file      : M05_2015630019_120517_01.c
* @author    : Pascalis Apriyatna - 2015630019
* @brief     :
*/

#include <stdio.h>

int main()
{
int a[150],b,c,d,umpan=0;
printf("Mencari Bilangan Dimensi 1 ===\n");
printf("Masukan berapa bilangan yang di input :");
scanf("%d", &b);
printf("\n");

for(c=0 ; c<b ; c++)
{
printf("Masukan Bilangan ke %d : ",c+1);
scanf("d", &a[c]);
}
printf("\n Masukan Bilangan Yang dicari :");
scanf("d", &d);

for(c=0 ; c<b ; c++)
{
    if(a[c]==d)
    {
    printf("\n Data nya berada di indeks array ke : %d atau berada di urutan ke : %d\n",c,c+1);
    break;
    }

else
{
umpan=umpan+1;
}
if(umpan==b)
{
    printf("\nDAta Tidak Ada \n");
}
}
return 0;
}
