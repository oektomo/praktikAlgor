#include <stdio.h>

struct struktur
{
    int data;
    int linked;
};

int main()
{
struct struktur linkedlist[10];
int i, node, value=0, x, search, y=0;

for(i=0; i<10; i++)
    linkedlist[i].data=-99;

printf("masukan jumlah node: ");
scanf("%d", &node);

for(i=0; i<node; i++)
{
    printf("masukan node ke %d: ", i+1);
    scanf("%d", &linkedlist[i].data);
    linkedlist[i].linked=i+1;
}

printf("jumlah node : %d\n\n", node);

printf("data yang ingin dicari: ");
scanf("%d", &search);

for(i=0; i<node; i++)
{
    if(linkedlist[i].data==search)
    {
        printf("data dengan nilai %d didapat poada node ke %d\n", search, i+1);
        y+=1;
    }

}
if(y==0)
    printf("data tidak ada\n");


return 0;
}
