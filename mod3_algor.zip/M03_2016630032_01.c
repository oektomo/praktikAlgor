#include <stdio.h>

struct link_list
{
 int link;
 int isi;
};
void keluaran(struct link_list* lix, int total)
{
    int x,y,z=0;
    for(x=1;x<=total;x++)
    {
        for(y=1;y<=total;y++)
            if(lix[y].link==x)
            {
            printf("Isi Node ke %d : %d\n", lix[x].link, lix[y].isi);
            }
    z++;
    }
    printf("Jumlah Node : %d", z);

}

int main()
{
    int banyak,i;
    struct link_list lix[50];
    printf("Masukkan Banyak Data: ");
    scanf("%d", &banyak);


    for(i=1; i<=banyak; i++)
    {
        lix[i].link=i;
        printf("Masukkan Data %d: ", i);
        scanf("%d", &lix[i].isi);
    }

    keluaran(lix,banyak);
}



