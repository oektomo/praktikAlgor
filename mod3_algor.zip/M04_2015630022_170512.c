/**
*   M04_2015630022_170512.c
*
*   Created on 05 12, 2017
*    Author:  Idham Hanif Ayega - 2015630022
*
*
*   @ M04_2015630022_170512_01.c
*   Idham Hanif Ayega - 2015630022
*/

#include <stdio.h>
#include <stdlib.h>

struct NODE
{
    int number;
    struct NODE*next;
};

int search_value(struct NODE *llist, int num);
void append_node(struct NODE *llist,int num);
void display_list(struct NODE *llist);
void delete_node(struct NODE *llist,int num);

int main (void)
{
    int num = 0;
    int input =1;
    int retval =0;
    struct NODE *llist;

    llist = (struct NODE *)malloc(sizeof (struct NODE));
    llist->number=0;
    llist->next = NULL;

    while (input!=0)
    {
        printf ("\n-- Menu Selection--\n");
        printf ("0) QUIT\n");
        printf ("1) INSERT\n");
        printf ("2) DELETE\n");
        printf ("3) SEARCH\n");
        printf ("4) DISPLAY\n");
        scanf ("%d", &input);

        switch (input)
        {
            case 0:
            default:
            printf ("selesai..\n");
            input=0;
            break;
            case 1:
            printf ("Anda memilih : INSERTION\n");
            printf ("masukkan nilai yang akan dimasukkan:");
            scanf("%d", &num);
            append_node(llist, num);
            break;

            case 2:
            printf ("Anda memilih : DELETION\n");
            printf ("masukkan nilai yang akan hapus:");
            scanf("%d", &num);
            delete_node(llist, num);
            break;

            case 3:
            printf ("Anda memilih : SEARCH\n");
            printf ("masukkan nilai yang akan dicari:");
            scanf("%d", &num);
            if ((retval = search_value(llist, num))== -1)
            printf ("nilai '%d' tidak ditemukan", num);
            else
            printf ("nilai '%d' ditemukan pada posisi '%d'\n",num, *llist);
            break;

            case 4:
            printf ("Anda memilih : DISPLAY\n");
            display_list(llist);
            break;

        }
    }
    free(llist);
    return 0;
}

void display_list(struct NODE *llist)
{
    while(llist->next!= NULL)
    {
        printf ("%d", llist->number);
        llist = llist->next;
    }
    printf ("%d", llist->number);
}

void append_node(struct NODE *llist, int num)
{
    while (llist->next!=NULL)
    llist = llist->next;

    llist->next = (struct NODE*)malloc(sizeof(struct NODE));
    llist->next->number=num;
    llist->next->next=NULL;
}

void delete_node(struct NODE *llist, int num)
{
    struct NODE *temp;
    temp = (struct NODE*)malloc(sizeof(struct NODE));

    if (llist->number == num)
    {
        temp = llist->next;
        free(llist);
        llist = temp;
    }
    else
    {
        while(llist->next->number!=num)
        llist = llist->next;
        temp = llist->next->next;
        free (llist->next);
        llist->next = temp;
    }
}

int search_value(struct NODE *llist, int num)
{
    int retval = -1;
    int i = 1;

    while (llist->next!= NULL)
    {
        if (llist->next->number == num)
        return 1;

        else
        i++;

        llist = llist->next;
    }

    return retval;
}

