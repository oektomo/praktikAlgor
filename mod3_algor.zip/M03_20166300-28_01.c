#include<stdio.h>
#include<stdlib.h>

   struct simpulseranai
   {
    int data;
    struct simpulseranai* berikutPtr
 };
typedef struct simpulseranai simpulseranai;
typedef simpulseranai*berikutpointernya;

void sisip(simpulseranai *SPtr, int angka);
void tampilseranai(simpulseranai sekarangpointer);

   int main()
   {
    struct simpulseranai* awal = NULL;
    int jumlah,i,isi;

    printf("jumlah node:");
    scanf("%d",&jumlah);

    for(i=1;i<=jumlah;i++)
    {
        printf("input node ke %d :",i);
        scanf("%d",&jumlah);
        sisip(simpulseranai,isi);
    }
   printf("data setiap node :\n");
   tampilseranai(simpulseranai sekarangpointer);
   return 0;
   }

    void sipsip(simpulseranai *SPtr,int angka);
    simpulseranaiPointer baruPtr;
    simpulseranaiPointer sebelumPtr;
    simpulseranaiPointer sekarangPtr;

    baruPtr=mall(sizeof(simpulseranai));
    if(baruPtr!=NULL)
    {
     baruPtr->data=angka;
     baruPtr->berikut=NULL;

     sebelumPtr=NULL;
     sebelumPtr=*SPtr;

     while(sekarangPtr!=NULL&&angka>sekarangPtr->data)
     {
     sebelumPtr=sekarangPtr;
     sekarangPtr=sekarangPtr->berukutPtr;
     }
     if(sebelumPtr==NULL)
        {

        baruPtr->berikutPtr=*SPtr;
        *SPtr=baruPtr;

        }
     else
     {
     sebelumPtr->berikutPtr=*SPtr;
     baruPtr->berikutPtr=sekarangPtr;
     }
     void tampilseranai(simpulseranipointer sekarangPtr)
     {
     int i;
     if (sekarangPtr==NULL)
     {
     printf("sekarang kosong\n\n");
     }
     else
     }
     {
     while(sekarangPtr!=NULL)
     {
        printf("%d -->",sekarangPtr->data);
        sekarangPtr=sekarangPtr->berikutPtr;
     }

     }

    }
