#include <stdio.h>

struct linglis{
    int a;
    int b;
};
int input (struct linglis* apa);
void temukan(struct linglis* apa, int jumlah,int cari);
void output (struct linglis* apa,int jumlah);

int main (){
    struct linglis apa[99];
    int node;

     node=input(apa);

     output(apa,node);

     return 0;


}

void temukan(struct linglis* apa, int jumlah,int cari){
    int i=-1,j=1;
    while (1){
        i++;

        if (j==0){
            if (apa[i].b==cari){
                printf ("dan ke-%d",apa[i].a);
            }
            if(i==jumlah)
                return;
        }
        if (apa[i].b==cari && j == 1){
            printf ("data dengan nilai %d ada di node ke-%d",cari,apa[i].a);
            j=0;
        }
        if (i==jumlah){
            break;
        }
    }
    printf ("tidak ada data dengan nilai %d  ",cari);

}

void output( struct linglis* apa, int jumlah){
    int cari ;
    printf ("data yang dicari adalah: "); scanf ("%d",&cari);

    temukan(apa,jumlah,cari);
}

int input(struct linglis* apa){
    int i,n;

    printf ("masukkan jumlah node: "); scanf ("%d",&n);

    for(i=0;i<n;i++){
        apa[i].a=i+1;
        printf("node ke %d : ",apa[i].a);
        scanf ("%d",&apa[i].b);
    }
    return n;
}
