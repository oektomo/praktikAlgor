// Michael Evans
// 2015630024
// Heap Sort

#include<stdio.h>


int main()
{

int c, awal, akhir, tengah, n, cari, array[100];

printf("Masukan nilai : \n");
scanf("%d", &n);

printf("Masukan %d integer\n", n);

for(c=0;c<n;c++)
scanf("%d", &array[c]);

printf("Masukan nilai untuk dicari\n");
scanf("%d", &cari);

awal=0;
akhir=n-1;
tengah=(awal+akhir/2);

while(awal<=akhir)
{
if(array[tengah]<cari)
awal=tengah+1;
else if(array[tengah]==cari){
printf("%d cari di lokasi %d.\n", cari, tengah+1);
break;

}
else
akhir=tengah-1;

tengah = (awal+akhir)/2;

}
if (awal>akhir)
printf("Tidak ditemukan! %d bukan nilai dalam list", cari);
return 0;
}
