#include <stdio.h>

struct jajak{
    int data;
    int link;
};

int main(){

    struct jajak linklist[10];
    int i, node, head=0, hapus, a;

    for(i=0;i<10;i++)
        linklist[i].data=-99;

        printf("Input Jumlah Node: ");
        scanf("%d", &node);

    for(i=0;i<node;i++){
        printf("Input Node %d\t: ", i+1);
        scanf("%d", &linklist[i].data);
        linklist[i].link=i+1;
        }

    printf("\nData setiap node adalah: \n");
    a=head;

    for(i=0;i<node;i++){
        printf("Data Node %d\t: %d\n",i+1, linklist[a].data);
        a=linklist[a].link;
    }

    printf("Jumlah node\t: %d\n\n", node);

    printf("Masukan node yang akan dihapus: ");
    scanf("%d", &hapus);
    if(hapus==1)
    head=1;
    else{
    for(i=0;i<node;i++){
            if(linklist[i].link==hapus-1)
                linklist[i].link=linklist[hapus-1].link;
        }
    }
linklist[hapus-1].data=-99;
node--;

printf("\nData setiap node adalah: \n");
a=head;
for(i=0;i<node;i++){
printf("data Node %d\t: %d\n", i+1, linklist[a].data);
a=linklist[a].link;
}
printf("jumlah node\t: %d\n\n", node);
return 0;
}
