#include<stdio.h>

struct hai
{
    int tautan;
    int isi;
};

int main(void)
{
    struct hai berantai[50];
    int node;

    node=input(berantai);

    output(berantai,node);

    return 0;
}
int input (struct hai* berantai)
{
    int x,jumlah;

    printf("input jumlah node :");
    scanf("%d",&jumlah);

    for(x=0;x<jumlah;x++)
    {
        berantai[x].tautan=x+1;
        printf("Input node ke %d : ",berantai[x].tautan);
        scanf("%d",&berantai[x].isi);
    }
    return jumlah;
}
void output(struct hai* berantai,int banyak)
{
    int dicari,x;

    printf("\nData yang dicari adalah : ");

    scanf("%d",&dicari);

    cari(berantai,banyak,dicari);
}
void cari(struct hai* berantai,int banyak,int dicari)
{
    int x=-1,hai=-1;
    while(1)
    {
        x++;

        if(hai==0)
        {
            if(berantai[x].isi==dicari)
            printf(" dan ke %d",berantai[x].tautan);
            if(x==banyak)
            return;
        }
        if (berantai[x].isi==dicari&&hai==1)
        {
            printf("data dengan nilai %d ada di node ke %d",dicari);
            hai=0;
        }
        if(x==banyak)
        break;
    }
    printf("\nData dengan nilai %d tidak ada",dicari);
}
