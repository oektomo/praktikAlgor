#include <stdio.h>

struct jeha{
int bilangan,link;
};
int main()
{
struct jeha linklist[5];
int j,n,node,head=0,hapus;

for (j=0;j<5;j++)
linklist[j].bilangan=1234567890;
printf("input jumlah node : ");
scanf("%d", &node);

for (j=0;j<node;j++)
{
printf("input node %d : ",j+1);
scanf("%d",&linklist[j].bilangan);
linklist[j].link=j+1;
}

printf("data setiap node : \n");
n=head;
for(j=0;j<node;j++)
{
printf("data node %d : %d\n",j+1,linklist[n].bilangan);
n=linklist[n].link;
}
printf("jumlah node : %d\n",node);
printf("masukan node yang akan dihapus : ");
scanf("%d",&hapus);
if (hapus==1)
head=1;
else{

for(j=0;j<node;j++)
{
if(linklist[j].link==hapus-1)
linklist[j].link=linklist[hapus-1].link;
}
}
linklist[hapus-1].bilangan=1234567890;
node--;

printf("data setiap node adalah : \n");
n=head;
for(j=0;j<node;j++)
{
printf("data node %d : %d\n",j+1,linklist[n].bilangan);
n=linklist[n].link;
}
printf("jumlah node : %d\n",node);
return 0;

}
