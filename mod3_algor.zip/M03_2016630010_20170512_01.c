/**
*M03_2016630010_20170512_01
*
*Created on : 05 12, 2017
*Author     : Yudantiyo Wirabagaskara -2016630010
*
*@file M03_2016630010_20170512_01
*@author Yudantiyo Wirabagaskara -2016630010
*@brief deskripsi program
*/

#include<stdio.h>
#include<stdlib.h>

struct NODE
{
int number;
struct NODE *next;
};

void append_node(struct NODE*llist,int num);
void display_list(struct NODE *llist);

int main(void)
{
int number= 0;
int input = 5;
int retval = 0;
int banyak,x,baru,posisi;
struct NODE *llist;

llist = (struct NODE *)malloc(sizeof(struct NODE));
llist->number =0;
llist->next = NULL;

printf("Jumlah node : ");
scanf("%d",&banyak);
for (x=0;x<banyak;x++)
{
printf("Masukkan nilai ke node %d : ",x+1);
scanf("%d",&number);
append_node(llist,number);
}
display_list(llist);

free(llist);
return (0);
}

void append_node(struct NODE *llist,int number)
{
while(llist->next != NULL)
llist = llist->next;

llist->next = (struct NODE *)malloc(sizeof(struct NODE));
llist->next->number = number;
llist->next->next =NULL;
}

void display_list(struct NODE *llist)
{
int y=1;
while(llist->next !=NULL)
{
llist = llist->next;
printf("Node %d = %d\n",y,llist->number);
y++;
}
}
