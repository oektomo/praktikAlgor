/**
* M03_2015630019_120517_01.c
*
* created on : 12 05,2017
* Author     : Pascalis Apriyatna - 2015630019
*
* @file      : M0_2015630019_120517_01.c
* @author    : Pascalis Apriyatna - 2015630019
* @brief     :
*/

#include <stdio.h>
#include <stdlib.h>

struct NODE
{
    int number;
    struct NODE *next;
};

int search_value(struct NODE *llist, int num);
void append_node(struct NODE *llist, int num);
void display_list(struct NODE *llist);
void delete_node(struct NODE *llist, int num);

int main(void)
{
int num = 0;
int input = 1;
int retval = 0;
struct NODE *llist;

llist=(struct NODE *)malloc(sizeof(struct NODE));
llist->number = 0;
llist->next = NULL;

while(input !=0)
{
printf("\n-- Menu Selection --\n");
printf("0)quit\n");
printf("1)insert\n");
printf("2)delete\n");
printf("3)search\n");
printf("4)display\n");
scanf("%d", &input);

switch(input)
{
case 0:
default :
 printf("Goodbye...\n");
 input=0;
 break;

 case 1:
 printf("Pilihan Kamu : 'Insert'\n");
 printf("Masukan Nilai Insert:");
 scanf("%d", &num);
 append_node(llist,num);
 break;

 case 2:
 printf("Pilihan Kamu : 'Deletion'\n");
 printf("Masukan Nilai Deletion:");
 scanf("%d", &num);
 delete_node(llist,num);
 break;

 case 3:
 printf("Pilihan Kamu : 'Search'\n");
 printf("Masukan Nilai Find:");
 scanf("%d", &num);
 if((retval= search_value(llist, num))== -1)
  printf("Nilai %d tidak ditemukan \n", num);
  else
  printf("Nilai %d posisi lokasi %d \n", num, retval);
 break;

 case 4:
 printf("Pilihan Kamu : 'Display'\n");
 display_list(llist);
 break;

}
}
free(llist);
return 0;
}

void display_list(struct NODE *llist)
{
while(llist->next != NULL)
{
printf("%d", llist->number);
llist=llist->next;
}
printf("%d",llist->number);
}

void append_node(struct NODE *llist, int num)
{
while(llist->next !=NULL)
 llist =llist->next;

 llist->next=(struct NODE *)malloc(sizeof(struct NODE));
 llist->next->number=num;
 llist->next->next= NULL;
 }
 void delete_node(struct NODE *llist, int num)
 {
struct NODE *temp;
temp= (struct NODE *)malloc(sizeof(struct NODE));

if(llist->number==num)
{
temp=llist->next;
free(llist);
llist=temp;
}
else
{
while(llist->next->number != num)
llist = llist->next;

temp=llist->next->next;
free(llist->next);
llist->next = temp;
}
}

int search_value(struct NODE *llist, int num)
{
int retval = -1;
int i = 1;

while(llist->next != NULL)
{
if(llist->next->number == num)
return 0;
else
 i++;
 llist = llist->next;
}
return retval;
}
