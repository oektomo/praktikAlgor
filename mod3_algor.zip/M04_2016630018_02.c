#include <stdio.h>

struct hai
{int tautan;
int isi;};

int main(void)
{struct hai berantai[50];
int node;
node=input(berantai);
node+=masukkan(berantai,node);
output(berantai,node);
return 0;}

int input(struct hai* berantai)
{int x, jumlah;
printf("INPUT = ");
scanf("%d", &jumlah);
for(x=0;x<jumlah;x++)
{berantai[x].tautan=x+1;
printf("INPUT %d: ", berantai[x].tautan);
scanf("%d", &berantai[x].isi);
}
return jumlah;
}

void output(struct hai* berantai, int banyak)
{
int x,y,besar=0;
printf("\DATA = ");
for(x=0;x<banyak;x++)
{
for(y=0;y<banyak;y++)
if(berantai[y].tautan==x+1)
{
printf("\ISI KE %d: %d", berantai[y].tautan,besar);
break;
}
if(berantai[y].tautan==-13);
continue;
}
for(x=0;x<banyak;x++)
if(besar<berantai[x].tautan)
besar=berantai[x].tautan;
printf("\nJUMLAH %d", besar);
}
int masukkan(struct hai* berantai,int banyak)
{
int angka,penunjuk,x,y;
printf("\nINPUT DATA: ");
scanf("%d", &angka);
printf("\nINPUT POSISI NODE: ");
scanf("%d", &penunjuk);

for(x=0;x<banyak;x++)
if(berantai[x].tautan>=penunjuk)
berantai[x].tautan++;
berantai[banyak].tautan=penunjuk;
berantai[banyak].isi=angka;
return 1;
}
