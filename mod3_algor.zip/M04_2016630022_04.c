#include <stdio.h>

struct struk
{
    int data;
    int link;
};

int main ()
{
    struct struk linklist[10];

    int i, node, a, b=0, head=0, cari;

    for(i=0;i<10;i++)
        linklist[i].data=-99;

    printf("Input Jumlah Node: ");
    scanf("%d", &node);

    for(i=0;i<node;i++){
    printf("Input Node %d\t: ", i+1);
    scanf("%d", &linklist[i].data);
    linklist[i].link=i+1;
    }

    printf("\nData setiap node adalah : \n");
    a=head;
    for(i=0;i<node;i++){
    printf("Data Node %d\t: %d\n", i+1,linklist[a].data);
    a=linklist[a].link;
    }

    printf("Jumlah node\t:%d\n\n", node);

    printf("Data yang ingin dicari: ");
    scanf("%d", &cari);

    for(i=0;i<node;i++)
        if(linklist[i].data==cari)
        {
            printf("Data dengan nilai %d didapat pada node ke-%d\n", cari, i+1);
            b+=1;
        }

    if (b==0)
        printf("\nMaaf data yang dicari tidak ada\n");

return 0;
}
