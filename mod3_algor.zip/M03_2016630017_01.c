#include<stdio.h>
#include<stdlib.h>

struct simpulseranai
{
    int data;
    struct simpulseranai*berikutPtr
};

typedef struct simpulseranai simpulseranai;
typedef simpulseranai *simpulseranaiPointer;

void sisip(simpulseranaiPointer *SPtr, int angka);
void tampilseranai(simpulseranaiPointer sekarangPointer);

int main()
{
    simpulseranaiPointer awalPointer = NULL;
    int jumlah,i,isi;

    printf("Jumlah Node : ");
    scanf("%d",&jumlah);

    for(i=1;i<=jumlah;i++)
    {
        printf("Input Node Ke %d : ",i);
        scanf("%d",&isi);
        sisip(&awalPointer,isi);
    }

printf("Data Setiap Node Adalah : \n");
tampilseranai(awalPointer);

return 0;
}

void sisip(simpulseranaiPointer *SPtr,int angka)
{
    simpulseranaiPointer baruPtr;
    simpulseranaiPointer sebelumPtr;
    simpulseranaiPointer sekarangPtr;

    baruPtr=malloc(sizeof(simpulseranai));
    if(baruPtr!=NULL)
    {
        baruPtr -> data=angka;
        baruPtr -> berikutPtr=NULL;

        sebelumPtr=NULL;
        sebelumPtr=*SPtr;

        while(sekarangPtr!=NULL&&angka>sekarangPtr->data)
        {
            sebelumPtr=sekarangPtr;
            sekarangPtr=sekarangPtr->berikutPtr;
        }

    if(sebelumPtr==NULL)
        {
            baruPtr->berikutPtr=*SPtr;
            *SPtr=baruPtr;
        }

    else
        {
        sebelumPtr->berikutPtr=*SPtr;
        baruPtr->berikutPtr=sekarangPtr;
        }
    }
}
void tampilseranai(simpulseranaiPointer sekarangPtr)
{
    int i;
    if(sekarangPtr==NULL)
    {
        printf("Seranai Kosong\n\n");
    }

    else
    {
    while(sekarangPtr!=NULL)
        {
            printf("%d -->",sekarangPtr->data);
            sekarangPtr=sekarangPtr->berikutPtr;
        }
    }
}
