/**
 *  M03_2016630026_01.c
 *
 *  Created on : Mei 12, 2017
 *  Author     : Avicenna Fahrunasa-2016630026
 *
 *  @file M03_2016630026_01.c
 *  @author Avicenna Fahrunasa-2016630026
 *  @brief Program print data dari linked list
 */

#include<stdio.h>

int main(){

int link[10], br=1, x=0, ul;

do{
x++;
printf("input data ke-%d: ", x);
scanf("%d", &link[x]);
}while(x!=4);
ul=x;
for(x=1;x<=ul;x++)
    {
        printf("\nData Node = %d", link[x]);
    }
printf("\njumlah data = %d", ul);
}
