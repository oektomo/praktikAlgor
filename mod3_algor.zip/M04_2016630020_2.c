#include <stdio.h>

struct jeha{
int bilangan,link;
};
int main()
{
struct jeha linklist[5];
int j,n,node,head=0,apa;

for(j=0;j<5;j++)
linklist[j].bilangan=1234567890;

printf("input jumlah node : ");
scanf("%d",&node);

for (j=0;j<node;j++){
printf("input node %d : \t",j+1);
scanf("%d",&linklist[j].bilangan);
linklist[j].link=j+1;
}
printf("data setiap node adalah : \n");
n=head;
for(j=0;j<node;j++)
{
printf("data node %d : %d \n",j+1,linklist[n].bilangan);
n=linklist[n].link;
}
printf("jumlah node : %d \n",node);

for(j=0;j<5;j++)
if(linklist[j].bilangan==1234567890){
apa=j;
break;
}
printf("masukan data yang akan dimasukan : ");
scanf("%d",&linklist[apa].bilangan);
printf("masukan posisi node yang akan dimasukkan : ");
scanf("%d",&linklist[apa].link);
if(linklist[apa].link==1)
head=apa;
linklist[apa].link-=1;
linklist[linklist[apa].link -1].link=apa;
node++;
printf("data setiap node adalah : \n");
n=head;
for(j=0;j<node;j++)
{
printf("data node %d\t : %d\n",j+1,linklist[n].bilangan);
n=linklist[n].link;
}
printf("jumlah node\t : %d\n",node);
return 0;
}
