#include <stdio.h>

struct struktur
{
    int data;
    int linked;
};

int main()
{
struct struktur linkedlist[10];
int i, node, value=0, empty, x;

for(i=0; i<10; i++)
linkedlist[i].data=-99;

printf("masukan jumlah node: ");
scanf("%d", &node);

for(i=0; i<node; i++)
{
    printf("masukan node ke %d : ", i+1);
    scanf("%d", &linkedlist[i].data);
    linkedlist[i].linked=i+1;
}

printf("\nData setiap node adalah : \n");

x=value;

for(i=0; i<node; i++)
{
    printf("data node ke %d : %d\n", i+1, linkedlist[x].data);
    x=linkedlist[x].linked;
}

printf("jumlah node : %d\n", node);

for(i=0; i<8; i++)
    if(linkedlist[i].data==-99)
    {
        empty=i;
        break;
    }

printf("masukkan data yang akan dimasukkan : ");
scanf("%d", &linkedlist[empty].data);

printf("masukkan posisi node yang akan dimasukkan : ");
scanf("%d", &linkedlist[empty].linked);

if (linkedlist[empty].linked==1)
    value=empty;

linkedlist[empty].linked-=1;
linkedlist[linkedlist[empty].linked-1].linked=empty;
node++;

printf("\nData setiap node : \n");
x=value;

for(i=0; i<node; i++)
{
    printf("data node ke %d : %d\n", i+1, linkedlist[x].data);
    x=linkedlist[x].linked;
}

printf("\njumlah node : %d\n", node);


return 0;
}
