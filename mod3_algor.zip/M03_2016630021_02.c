#include <stdio.h>

struct linglis{
    int a;
    int b;
};
int input (struct linglis* apa);
int insertion(struct linglis* apa, int jumlah);
void output (struct linglis* apa,int jumlah);

int main (){
    struct linglis apa[99];
    int node;

     node=input(apa);

     node += insertion (apa,node);
     output(apa,node);

     return 0;


}

int insertion(struct linglis* apa, int jumlah){
    int inpt,ptr,i,j;

    printf ("masukkan data yg di-insert: "); scanf ("%d",&inpt);
    printf ("data akan dimasukkan pada node :"); scanf ("%d",&ptr);

    for (i=0;i<jumlah;i++){
        if(apa[i].a>=ptr)
            apa[i].a++;
    }
    apa[jumlah].a =ptr;
    apa[jumlah].b=inpt;
    return 1;
}

void output( struct linglis* apa, int jumlah){
    int i,j,x=0;

    printf ("data pada tiap node: \n");
    for (i=0;i<jumlah;i++){
        for(j=0;j<jumlah;j++){
            if(apa[j].a==i+1){
                printf ("isi node ke-%d adalah: %d\n",apa[j].a,apa[j].b);
                break;
            }
        }
        if(apa[j].a==-13)
            continue;
    }
    for (i=0;i<jumlah;i++){
        if (x<apa[i].a)
            x=apa[i].a;

    }
    printf ("jumlah node adalah : %d",x);
}

int input(struct linglis* apa){
    int i,n;

    printf ("masukkan jumlah node: "); scanf ("%d",&n);

    for(i=0;i<n;i++){
        apa[i].a=i+1;
        printf("node ke %d : ",apa[i].a);
        scanf ("%d",&apa[i].b);
    }
    return n;
}
