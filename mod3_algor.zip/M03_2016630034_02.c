#include <stdio.h>
#include <stdlib.h>

struct GOLD
{
    int nomor;
    struct GOLD *next;
    int bintang,isi;
};

void last_dance(struct GOLD *bang, int nom);
int aug(struct GOLD *bang, int nom);
void happen_ending(struct GOLD *bang);

int main(void)
{

    int nom = 0;
    int barrel = 5;
    int water = 0;
    int clown,x,new,posisi;
    struct GOLD *bang;

    bang = (struct GOLD *)malloc(sizeof(struct GOLD));
    bang -> nomor= 0;
    bang -> next = NULL;

    printf("masukkan jumlah node yang anda inginkan : ");
    scanf("%d", &clown);
    for(x=0;x<clown;x++)
    {
        printf("input node %d : ", x+1);
        scanf("%d", &nom);
        last_dance(bang, nom);
    }
    aug(bang,nom);
        printf("\ndata setiap node :\n");
    happen_ending(bang);

    free(bang);
    return (0);
}

void last_dance(struct GOLD *bang, int nom)
{
    while(bang ->next != NULL)
    bang = bang->next;

    bang->next = (struct GOLD *)malloc(sizeof(struct GOLD));
    bang->next->nomor = nom;
    bang->next->next = NULL;
}

void happen_ending(struct GOLD *bang)
{
    int z=1;
    int d=0;

    while(bang->next != NULL)
    {
        bang = bang->next;
        printf("gold %d = %d\n", z, bang->nomor);
        z++;
        d++;
    }

    printf("jumlah node : %d", d);
}

int aug(struct GOLD *bang, int nom)
{
    int pangkat,gw,udah,bintang,isi;

    printf("\nmasukkan data yang akan dimasukkan : ");
    scanf("%d", &pangkat);
    printf("masukkan posisi node yang diinginkan : ");
    scanf("%d", &gw);

    for(udah=0;udah<nom;udah++)
    if(bang[udah].bintang>=gw)
    bang[udah].bintang++;

    bang[nom].bintang=gw;
    bang[nom].isi=pangkat;

    return 1;
}
