#include<stdio.h>

struct list
{
    int node;
    int data;
};

int input (struct list *link)
{
    int i, jml;

    printf (" Masukkan Jumlah Node : ");
    scanf ("%d", &jml);
    printf ("\n");

    for (i=0; i<jml; i++)
    {
        link[i].node = i+1;
        printf (" Node Ke-%d : ", link[i].node);
        scanf ("%d", &link[i].data);
    }

return jml;
}

int mencari (struct list *link, int jml, int dicari)
{
    int i=-1, list=1;

    while(1)
    {
        i++;

        if (list == 0)
        {
            if (link[i].data == dicari)
                printf (" Dan Ke-%d", link[i].node);
            if (i == jml)
                return;
        }

        if (link[i].data == dicari && list == 1)
        {
            printf ("\n Data Berada Di Node : %d\n", link[i].node);
        }

        if (i == jml)
            break;
    }

    printf (" Data Tidak Ditemukan");
}

void output (struct list *link, int n)
{
    int dicari, i;

    printf (" Data Yang Ingin Dicari : ");
    scanf ("%d", &dicari);
    printf ("\n");
    mencari (link, n, dicari);
}

int main()
{
    struct list link[20];
    int titik;

    titik = input(link);

    printf ("\n");

    output (link, titik);

return 0;
}
