#include<stdio.h>

struct struk
{
    int data;
    int kiri;
    int kanan;
};

int main()
{
    int data[15]={22, 52, 64, 11, 2, 5, 98, 102, 33, 65, 14, 77, 25, 19, 20}, i, x=0, y=0, target, parent;

    struct struk pohon[15];

    parent=data[0];
    pohon[0].data=data[0];

    for (i=0;i<15;i++)
    {
        pohon[i+1].data=data[i+1];
        if (data[i+1]<=parent)
        {
            pohon[x].kiri = i+1;
            x+=1;
        }
        else if (data[i+1]>parent)
        {
            pohon[y].kanan = i+1;
            y+=1;
        }
        parent=data[0];
    }

    for (i=0;i<15;i++)
        printf("%d ", pohon[i].data);

    printf("\nMasukkan data yang ingin dicari\n");
    printf("\nTarget = ");
    scanf("%d", &target);

    for(i=0;i<15;i++)
        if(data[i]==target)
            printf("\nPada array ke-%d\n", i+1);

return 0;
}
