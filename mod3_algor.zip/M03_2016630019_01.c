#include<stdio.h>
#include<stdlib.h>

struct simpulsenarai
{
int data;
struct simpulsenarai*berikutPtr
};

typedef struct simpulsenarai simpulsenarai;
typedef simpulsenarai *simpulsenaraiPointer;

void sisip(simpulsenaraiPointer *SPtr, int angka);
void tampilsenarai(simpulsenaraiPointer sekarangPointer);

int main()
{
simpulsenaraiPointer awalPointer = NULL;
int jumlah,i,isi;
 printf("Input Jumlah node  :");
 scanf("%d",&jumlah);

 for(i=1;i<=jumlah;i++)
    {
    printf("Input Node ke %d:",i);
    scanf("%d",&isi);
    sisip(&awalPointer,isi);
    }

printf("Data Setiap Node adalah :\n");
tampilsenarai(awalPointer);

    return 0;
}

void sisip(simpulsenaraiPointer *SPtr,int angka)
{
simpulsenaraiPointer baruPtr;
simpulsenaraiPointer sebelumPtr;
simpulsenaraiPointer sekarangPtr;

baruPtr=malloc(sizeof(simpulsenarai));
if(baruPtr!=NULL)
{
baruPtr -> data=angka;
baruPtr -> berikutPtr=NULL;

sebelumPtr=NULL;
sebelumPtr=*SPtr;

while(sekarangPtr!=NULL&&angka>sekarangPtr->data)
    {
    sebelumPtr=sekarangPtr;
    sekarangPtr=sekarangPtr->berikutPtr;
    }

if(sebelumPtr==NULL)
    {
    baruPtr->berikutPtr=*SPtr;
    *SPtr=baruPtr;
    }
}
else
    {
    sebelumPtr->berikutPtr=*SPtr;
    baruPtr->berikutPtr=sekarangPtr;
    }
}

void tampilsenarai(simpulsenaraiPointer sekarangPtr)
{
int i;
if(sekarangPtr ==NULL)
{
printf("Senarai Kosong\n\n");
}

else
{
while(sekarangPtr!=NULL)
    {
    printf("%d -->",sekarangPtr->data);
    sekarangPtr=sekarangPtr->berikutPtr;
    }
}
}
