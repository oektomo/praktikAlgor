/**
*   M05_2015630022_170512_01.c
*
*   Created on 05 12, 2017
*    Author:  Idham Hanif Ayega - 2015630022
*
*
*   @ M04_2015630022_170512_01.c
*   Idham Hanif Ayega - 2015630022
*/

#include <stdio.h>

int main()
{
    int a[100],b,c,d,umpan=0;
    printf ("========================\n");
    printf ("== program pencarian bilangan (dengan arrray 1 dimensi) ==\n");
    printf ("========================\n");
    printf("masukkan berapa bilangan yang ingin di input: ");
    scanf ("%d", &b);
    printf ("\n");

    for (c=0;c<b;c++)
    {

    printf ("masukkan bilangan ke %d: ",c+1);
    scanf ("%d", &a[c]);

    }
    printf ("\nmasukkan bilangan yang di cari : ");
    scanf("%d",&d);
    for (c=0;c<b;c++)
    {
        if (a[c]==d)
        {
            printf("\n data ada, berada di index array ke : %d atau berada di urutan ke %d\n",c,c+1);
            break;
        }
        else
        {
            umpan = umpan+1;
        }
    }
    if (umpan==b)
    {
        printf ("\n data tidak ada\n");
    }
    return 0;
}
