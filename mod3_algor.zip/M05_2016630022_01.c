#include<stdio.h>

int main()
{
    int data[15]={22, 52, 64, 11, 2, 5, 98, 102, 33, 65, 14, 77, 25, 19, 20}, i, target;

    for (i=0;i<15;i++)
        printf("%d ", data[i]);

    printf("\nMasukkan data yang ingin dicari\n");
    printf("\nTarget = ");
    scanf("%d", &target);

    for(i=0;i<15;i++)
        if(data[i]==target)
            printf("\nPada array ke-%d\n", i+1);

return 0;
}
