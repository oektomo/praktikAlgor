// Michael Evans
// 2015630024
// Soal 01

#include<stdio.h>

int main()

{
int a[100], b, c, d, umpan=0;

printf("Program Cari Bilangan\n");

printf("Masukkan bilangan : ");
scanf("%d\n", &b);

for(c=0;c<b;c++)
{
if(a[0]==d){
printf("\nData dietemukan berada di Index Array ke %d atau berada di urutan ke %d\n", c, c+1);
break;

}
else{
umpan=umpan+1;
}
if(umpan==b){

printf("\nData Tidak DItemukan");
}
}
return 0;
}
