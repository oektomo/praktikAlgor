/**
*   M03_2016630024_01.c
*
*   Created on  : Mei 12, 2017
*   Author      : Muhammad Annura Subhan-2016630024
*
*   @file M03_2016630024_01.c
*   @author Muhammad Annura Subhan-2016630024
*   @brief link list dan print data
*/

#include<stdio.h>
#include<stdlib.h>

struct Node
{
    int Angka;
    struct Node *Next;
};

void masuk_node(struct Node *list, int Ang);
void muncul_list(struct Node *list);

int main(void)
{
    int Ang = 0;
    int Input = 5;
    int retval = 0;
    int jumlah, i, baru, tempat;
    struct Node *list;

    list = (struct Node *)malloc(sizeof(struct Node));
    list -> Angka = 0;
    list -> Next = NULL;

    printf("Jumlah Node: ");
    scanf("%d", &jumlah);
    for(i=0;i<jumlah;i++)
    {
        printf("Masukkan Node Ke - %d: ",i+1);
        scanf("%d", &Ang);
        masuk_node(list, Ang);
    }
    printf("\n");
    muncul_list(list);

    free(list);
    return 0;
}

void masuk_node(struct Node *list, int Ang)
{
    while(list->Next != NULL)
    list = list->Next;

    list->Next = (struct Node *)malloc(sizeof(struct Node));
    list->Next->Angka = Ang;
    list->Next->Next = NULL;
}

void muncul_list(struct Node *list)
{
    int A=1;
    while(list->Next != NULL)
    {
        list = list->Next;
        printf("Node ke - %d: %d\n", A, list->Angka);
        A++;
    }
//    printf("Jumlah Data Node: %d", );
}
