#include <stdio.h>

struct jeha{
int bilangan,link;
};
int main()
{
struct jeha linklist[5];
int j,n,node,head=0;

printf("input jumlah node : ");
scanf("%d",&node);

for (j=0;j<node;j++){
printf("input node %d : \t",j+1);
scanf("%d",&linklist[j].bilangan);
linklist[j].link=j+1;
}
printf("data setiap node adalah : \n");
n=head;
for(j=0;j<node;j++)
{
printf("data node %d : %d \n",j+1,linklist[n].bilangan);
n=linklist[n].link;
}
printf("jumlah node : %d \n",node);
return 0;
}
