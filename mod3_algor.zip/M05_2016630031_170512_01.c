#include <stdio.h>
int main ()
    {
    int A[15] = {22,52,64,11,2,5,98,102,33,65,14,77,25,19,20};
    int cari,i=0;
    printf("diberikan array \n 22,52,64,11,2,5,98,102,33,65,14,77,25,19,20\n");
    printf("masukkan nilai yang dicari : ");
    scanf("%d",&cari);
    while(A[i]!=cari)
        {
        i++;

        }
    printf("TARGET = %d\n",cari);
    if(i>15)
        {
        printf("target tidak ada \n");
        }
    else
        {
        printf("%d ada pada array ke-%d ",cari,i);
        return 0;
        }
    }
