#include<stdio.h>


struct a
{
    int b;
    int c;
};

int main(void)
{
    struct a list[20];
    int node;

    node=input(list);

    output(list,node);

    return 0;
}

int input(struct a* list)
{
    int i,n;

    printf("Input jumlah node : ");
    scanf("%d",&n);

    for(i=0;i<n;i++)
    {
        list[i].b=i+1;
        printf("Input node %d\t: ",list[i].b);
        scanf("%d",&list[i].c);
    }

    return n;
}


void output(struct a* list,int n)
{
    int i,j,besar=0;

    printf("\nData setiap node adalah :");

    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
            if(list[j].b==i+1)
            {
                printf("\nData node %d\t: %d",list[j].b,list[i].c);
                break;
            }

            if(list[j].b==-13);
                continue;
    }

    for(i=1;i<=n;i++)
        if(besar<list[i].b)
            besar=list[i].b;


    printf("\n\nJumlah node\t: %d\n",besar);
}
