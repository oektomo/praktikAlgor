#include<stdio.h>




struct hai
{
    int tautan;
    int isi
};

int main(void)
{
    struct hai berantai[100];
    int node;

    node=input(berantai);

    output(berantai,node);

    return 0;
}

int input(struct hai* berantai)
{
    int x,jumlah;

    printf("Input node : ");
    scanf("%d",&jumlah);

    for(x=0;x<jumlah;x++)
    {
        berantai[x].tautan=x+1;
        printf("Input node ke %d ; ",berantai[x].tautan);
        scanf("%d",&berantai[x].isi);
    }
    return jumlah;
}
void output(struct hai* berantai,int banyak)
{
    int x,y,besar=0;

    printf("\ndata setiap node adalah:");
    for(x=0;x<banyak;x++)
    {
        for(y=0;y<banyak;y++)
            if(berantai[y].tautan==x+1)
            {
                printf("\nIsi node ke %d : %d",berantai[y].tautan,berantai);
                break ;
            }
        if(berantai[y].tautan==-13);
            continue;
    }
    for(x=0;x<banyak;x++)
        if(besar<berantai[x].tautan)
            besar=berantai[x].tautan;

    printf("\njumlah node adalah %d",besar);
}
