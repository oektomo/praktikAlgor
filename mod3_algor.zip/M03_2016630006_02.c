#include<stdio.h>

struct list
{
    int node;
    int data;
};

int input (struct list *link)
{
    int i, jml;

    printf (" Masukkan Jumlah Node : ");
    scanf ("%d", &jml);
    printf ("\n");

    for (i=0; i<jml; i++)
    {
        link[i].node = i+1;
        printf (" Node Ke-%d : ", link[i].node);
        scanf ("%d", &link[i].data);
    }

return jml;
}

void output (struct list *link, int n)
{
    int i, j, jml=0;

    for (i=0; i<n; i++)
    {
        for (j=0; j<n; j++)
        {
            if (link[j].node == i+1)
            {
                printf (" Isi Node Ke-%d : %d\n", link[j].node, link[j].data);
                break;
            }
        }
        if (link[j].node == -99);
            continue;
    }

    for (i=0; i<n; i++)
    {
        if (jml<link[i].node)
            jml = link[i].node;
    }

    printf ("\n\n Jumlah Node : %d", jml);
}

int insert (struct list *link, int jml)
{
    int baru, posisi, i;

    printf (" Data Baru Yang Ingin Ditambahkan : ");
    scanf ("%d", &baru);
    printf (" Posisi Data Baru : ");
    scanf ("%d", &posisi);

    for (i=0; i<jml; i++)
    {
        if (link[i].node >= posisi)
            link[i].node++;
    }

    link[jml].node = posisi;
    link[jml].data = baru;

return 1;
}

int main()
{
    struct list link[20];
    int titik;

    titik = input(link);

    printf ("\n");

    titik += insert (link, titik);

    printf ("\n");

    output (link, titik);

return 0;
}
