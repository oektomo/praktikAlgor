/**
* M03_2016630039_170512_01.c
*
* Created On : Mei 12, 2017
* Author : Mohammad Rinaldi-2016630039
*
* @file M03_2016630039_170512_01.c
* @author Mohammad Rinaldi - 2016630039
* @brief deskripsi program
*/

#include <stdio.h>
#include <stdlib.h>

struct NODE
{
int number;
struct NODE*next;
};

void append_node(struct NODE *llist, int num);
void display_list(struct NODE *llist);

int main(void)
{
int num = 0;
int input = 5;
int retval = 0;
int banyak,i,baru,posisi;
struct NODE *llist;

llist = (struct NODE *)malloc(sizeof(struct NODE));
llist->number = 0;
llist->next = NULL;

  printf("jumlah node :");
  scanf("%d", &banyak);

  for(i=1;i<=banyak;i++)
  {
  printf("Input node ke %d:", i);
  scanf("%d",&num);
  append_node(llist, num);
  }
  display_list(llist);

  free(llist);
  return (0);
}

void append_node(struct NODE *llist, int num){
  while(llist->next !=NULL)
   llist = llist->next;

   llist->next = (struct NODE *)malloc(sizeof(struct NODE));
   llist->next->number = num;
   llist->next->next = NULL;
}

void display_list(struct NODE *llist)
{
 int a=1;
 while(llist->next != NULL)
 {
 llist = llist->next;
 printf("node %d = %d\n",a,llist->number);
 a++;
 }
}

