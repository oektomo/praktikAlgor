/**
* M03_2016630023_01.c
*
* Created on : Mei 12,2017
* Author     : Muhammad IQbal Reza Pahlevi - 2016630023
*
* @file M03_2016630023_01.c
* @author Muhammad Iqbal Reza Pahlevi - 2016630023
* @brief deskripsi program
*/

#include<stdio.h>
#include<stdlib.h>

struct NODE{
    int number;
    struct NODE *next;
};

void append_node(struct NODE *llist, int num);
void display_list(struct NODE *llist);

 int main(void)
{
    int num = 0;
    int input = 5;
    int retival = 0;
    int banyak,i,baru,posisi;
    struct NODE *llist;

  llist = (struct NODE *)malloc(sizeof(struct NODE));
  llist ->number = 0;
  llist ->next = NULL;

  printf("Jumlah node :");
  scanf("%d",&banyak);
  for(i=0;i<banyak;i++)
  {
  printf("Masukan Nilai node %d: ",i+1);
  scanf("%d",&num);
  append_node(llist, num);
  }
  display_list(llist);

  free(llist);
  return (0);
  }

  void append_node(struct NODE *llist, int num){
        while(llist->next != NULL)
         llist = llist->next;

    llist->next = (struct NODE *)malloc(sizeof(struct NODE));
    llist->next->number = num;
    llist->next->next = NULL;
    }

    void display_list(struct NODE *llist)
    {
    int a=1;
    while(llist->next != NULL)
    {
    llist = llist->next;
    printf("node %d = %d\n",a,llist->number);
    a++;
    }
   }








