#include<stdio.h>

int main()
{
    int A[15]={22, 52, 64, 11, 2, 5, 98, 102, 33, 65, 14, 77, 25, 19, 20};
    int cari,i=0;
    printf("Masukkan nilai yang dicari:");
    scanf("%d",&cari);
    while(A[i]!=cari)
    {
        i++;
    }
    printf("Target = %d\n",cari);
    if(i>15)
    {
        printf("Target tidak ada\n");
    }
    else
    printf("Pada Array ke-%d",i);
    return 0;
}
