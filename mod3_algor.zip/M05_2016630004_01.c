#include <stdio.h>

int main()
{
int array[100], jumlah, i, s, x=0;


printf("==== program pencari bilangan array 1 dimensi ====\n\n\n");


printf("masukan jumlah bilangan yang ingin diinput: \n");
scanf("%d", &jumlah);

for(i=0; i<jumlah; i++)
{
    printf("masukan bilangan ke %d: ", i+1);
    scanf("%d", &array[i]);
}

printf("\n masukan bilangan yang ingin dicari: ");
scanf("%d", &s);

for(i=0; i<jumlah; i++)
{
    if(array[i]==s)
    {
        printf("data ada pada index array ke %d atau di urutan ke %d\n", i, i+1);
        break;
    }
    else{
    x=x+1;
    }
}
if(x==jumlah)
{
    printf("\n data tidak ada\n");
}


return 0;
}
