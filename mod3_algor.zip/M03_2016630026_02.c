/**
 *  M03_2016630026_02.c
 *
 *  Created on : Mei 12, 2017
 *  Author     : Avicenna Fahrunasa-2016630026
 *
 *  @file M03_2016630026_02.c
 *  @author Avicenna Fahrunasa-2016630026
 *  @brief Program input angka di bebas tempat
 */

#include<stdio.h>

struct database{
    int angka[15];
};
struct database nilai;

int main(){

int x, node, ulang=1;

for(x=1;x<4;x++)
{
    printf("Data node ke-%d =", x);
    scanf("%d", &nilai.angka[x]);
}

x++;
printf("masukkan data = ");
scanf("%d", &nilai.angka[x]);
printf("data input ke node =");
scanf("%d", &node);
while(node!=x)
{
    x=node;
    x++;
    node=x;
}

while(ulang!=x)
{
    printf("data node = %d\n", nilai.angka[ulang]);
    ulang++;
}
}
