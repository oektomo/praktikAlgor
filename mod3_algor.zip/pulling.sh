#!/bin/bash
        for i in `seq 1 9`;
        do
                git checkout 201563000$i
		git pull origin 201563000$i
        done 

        for i in `seq 10 45`;
        do
                git checkout 20156300$i
		git pull origin 20156300$i
        done 
	
	for i in `seq 1 9`;
        do
                git checkout 201663000$i
		git pull origin 201663000$i
        done 

        for i in `seq 10 45`;
        do
                git checkout 20166300$i
		git pull origin 20166300$i
        done 


	git checkout master

	./merging.sh

