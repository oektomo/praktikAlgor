/*
    M04_2016630030_03.c

    Nama: Raymond Christian
    NPM : 2016630030
*/
#include<stdio.h>


struct hai
{
    int tautan;
    int isi;
};

//prototype disatuin dengan fungsi karena jika fungsi di bawah maka program mendeteksi deklarasi fungsi 2x
int input(struct hai* larik)
{
    int x, masukkan;

    printf("Input jumlah node:");
    scanf("%d",&masukkan);

    for(x=0;x<masukkan;x++)
    {
        larik[x].tautan=x+1;    //input node
        printf("Input node ke-%d: ",larik[x].tautan);
        scanf("%d",&larik[x].isi);  //inpout isi node
    }
}

void output(struct hai* larik,int total)
{
    int x,y,maks=0;//maks=0 untuk mencari nilai dengan tautan terbesar (total node)

    printf("\nData Setiap node adalah:");

    for(x=0;x<total;x++)
    {
        for(y=0;y<total;y++)
        {
            if(larik[y].tautan==-4) // data kosong untuk soal ini
                continue;

            if(larik[y].tautan==x+1)
            {
                printf("\nIsi Node ke-%d: %d", larik[y].tautan,larik[y].isi);
                break;
            }

        }
    }

    for(x=0;x<total;x++)
        if(maks<larik[x].tautan)
            maks=larik[x].tautan; // mencari jumlah node

    printf("\nJumlah node adalah %d", maks);
}

void hapus(struct hai* larik,int total)
{
    int x,piceun;

    printf("\nMasukkan node yang akan dihapus:");
    scanf("%d", &piceun);

    for(x=0;x<total;x++)
        if(larik[x].tautan==piceun)
            larik[x].tautan=-4; //-4 untuk menandakan data kosong
        else if(larik[x].tautan>piceun)
            larik[x].tautan--;  //untuk mengurangi nilai node di atas node piceun agar node tetap urut
}

int main(void)
{
    struct hai larik[20];
    int penunjuk=input(larik);

    hapus(larik,penunjuk);

    output(larik,penunjuk);

    return 0;
}
