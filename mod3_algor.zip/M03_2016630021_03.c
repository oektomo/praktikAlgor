#include <stdio.h>

struct linglis{
    int a;
    int b;
};
int input (struct linglis* apa);
void hapus(struct linglis* apa, int jumlah);
void output (struct linglis* apa,int jumlah);

int main (){
    struct linglis apa[99];
    int node;

     node=input(apa);

     hapus(apa,node);
     output(apa,node);

     return 0;


}

void hapus(struct linglis* apa, int jumlah){
    int del,i;

    printf ("masukkan node yg dihapus: "); scanf ("%d",&del);

    apa[del-1].a=-13;

    for (i=0;i<jumlah;i++){
        if(apa[i].a>del)
            apa[i].a--;
    }
}

void output( struct linglis* apa, int jumlah){
    int i,j,x=0;

    printf ("data pada tiap node: \n");
    for (i=0;i<jumlah;i++){
        for(j=0;j<jumlah;j++){
            if(apa[j].a==i+1){
                printf ("isi node ke-%d adalah: %d\n",apa[j].a,apa[j].b);
                break;
            }
        }
        if(apa[j].a==-13)
            continue;
    }
    for (i=0;i<jumlah;i++){
        if (x<apa[i].a)
            x=apa[i].a;

    }
    printf ("jumlah node adalah : %d",x);
}

int input(struct linglis* apa){
    int i,n;

    printf ("masukkan jumlah node: "); scanf ("%d",&n);

    for(i=0;i<n;i++){
        apa[i].a=i+1;
        printf("node ke %d : ",apa[i].a);
        scanf ("%d",&apa[i].b);
    }
    return n;
}
