#include <stdio.h>

struct link_list
{
 int link;
 int isi;
};
void keluaran(struct link_list* lix, int total)
{
    int x,y,z=0;
    for(x=1;x<=total;x++)
    {
        for(y=1;y<=total;y++)
            if(lix[y].link==x)
            {
            if(lix[x].link==-99)
            continue;
            z++;
            printf("Isi Node ke %d : %d\n", lix[x].link, lix[y].isi);
            }


    }
    printf("Jumlah Node : %d\n", z);

}

void hapus(struct link_list* lix, int dat, int pos_dat, int total)
{

    int x;
    printf("Masukkan Node yang akan dihapus : ");
    scanf("%d", &pos_dat);

    for(x=1;x<=total;x++)
    {
        if(lix[x].link==pos_dat)
        {

            lix[x].link=-99;
        }

    }
    for(x=1;x<=total;x++)
        if(lix[x].link>pos_dat)
            lix[x].link--;
}
int main()
{
    int banyak,i,dat, pos_dat, ngurang, z;
    struct link_list lix[50];
    printf("Masukkan Banyak Data: ");
    scanf("%d", &banyak);


    for(i=1; i<=banyak; i++)
    {
        lix[i].link=i;
        printf("Masukkan Data %d: ", i);
        scanf("%d", &lix[i].isi);
    }

    keluaran(lix,banyak);


   hapus(lix,dat,pos_dat,banyak);

    keluaran(lix,banyak);

    return 0;
}
