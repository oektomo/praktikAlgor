/**
* M03_2016630038_170512_01.c
*
* Created On : Mei 12 , 2017
* Author : Sagara Biru Wilantara - 2016630038
*
* @file M03_2016630038_170512_01.c
* @author Sagara Biru Wilantara - 2016630038
* @brief dekripsi program
*/

#include <stdio.h>
#include <stdlib.h>

struct NODE
{
int number;
struct NODE *next;
};

void append_node(struct NODE *llist, int num);
void display_list(struct NODE *llist);


int main(void)
{
 int num = 0;
 int input = 5;
 int retval = 0;
 int banyak,i,baru,posisi;
 struct NODE *llist;

 llist = (struct NODE *)malloc(sizeof(struct NODE));
 llist->number = 0;
 llist->next = NULL;

 printf("jumlah node : ");
 scanf("%d", &banyak);
 for(i=0;i<banyak;i++)
 {
    printf("masukkan nilai node %d:  ",i+1);
    scanf("%d", &num);
    append_node(llist, num);
 }
 display_list(llist);

 free(llist);
 return(0);
 }

 void append_node(struct NODE *llist, int num) {
  while(llist->next != NULL)
   llist = llist->next;

  llist->next = (struct NODE *)malloc(sizeof(struct NODE));
  llist->next->number = num;
  llist->next->next = NULL;
 }

 void display_list(struct NODE *llist)
 {
  int a=1;
  while(llist->next != NULL)
  {
   llist = llist->next;
   printf("node %d = %d\n", a, llist->number);
   a++;
  }
 }

