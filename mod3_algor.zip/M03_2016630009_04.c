#include<stdio.h>

struct apa
{
    int tab;
    int isi;
};

int input (struct apa* chained)
{
    int x, jumlah;

    printf("masukan jumlah node: ");
    scanf("%d",&jumlah);

    for(x=0;x<jumlah;x++)
    {
        chained[x].tab=x+1;
        printf("node ke-%d: ",chained[x].tab);
        scanf("%d",&chained[x].isi);
    }

    return jumlah;
}

void temukan(struct apa* chained,int much,int cari)
{
    int i=-1,j=1;
    while(1)
    {
        i++;

        if(j==0)
        {
            if(chained[i].isi==cari)
                printf("dan ke%-d",chained[i].tab);
            if(i==much)
                return;
        }

        if(chained[i].isi==cari&&j==1)
        {
            printf("data dengan nilai %d ada di node: %d",cari,chained[i].tab);
            j=0;
        }

        if(i==much)
            break;
    }

    printf("\ntidak ada data dengan nilai: %d ",cari);
}

void output(struct apa* chained,int much)
{
    int cari,x;
    printf("masukan data yang ingin dicari: ");
    scanf("%d",&cari);
    temukan(chained,much,cari);
}



int main(void)
{
    struct apa chained[100];
    int node;

    node=input(chained);
    output(chained,node);

    return 0;
}
