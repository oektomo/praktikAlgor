/*
    M04_2016630030_01.c

    Nama: Raymond Christian
    NPM : 2016630030
*/
#include<stdio.h>


struct hai
{
    int tautan;
    int isi;
};

//prototype disatuin dengan fungsi karena jika fungsi di bawah maka program mendeteksi deklarasi fungsi 2x
int input(struct hai* larik)
{
    int x, masukkan;

    printf("Input jumlah node:");
    scanf("%d",&masukkan);

    for(x=0;x<masukkan;x++)
    {
        larik[x].tautan=x+1;    //input node
        printf("Input node ke-%d: ",larik[x].tautan);
        scanf("%d",&larik[x].isi);  //input isi node
    }
}

void output(struct hai* larik,int total)
{
    int x,y,maks=0;//maks=0 untuk mencari nilai dengan tautan terbesar (total node)

    printf("\nData Setiap node adalah:");

    for(x=0;x<total;x++)
    {
        for(y=0;y<total;y++)
        {
            if(larik[y].tautan==-4) //-4 adalah data kosong (untuk nomer 3)
                continue;

            if(larik[y].tautan==x+1)    //if ini digunakan untuk print bilagan dari node terkecil
            {
                printf("\nIsi Node ke-%d: %d", larik[y].tautan,larik[y].isi);
                break;
            }

        }
    }

    for(x=0;x<total;x++)    //mencari nilai node terbesar (jumlah data)
        if(maks<larik[x].tautan)
            maks=larik[x].tautan;

    printf("\nJumlah node adalah %d", maks);
}

int main(void)
{
    struct hai larik[20];
    int penunjuk=input(larik); // penunjuk adalah banyak data

    output(larik,penunjuk);

    return 0;
}
