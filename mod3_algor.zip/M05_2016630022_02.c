#include<stdio.h>

struct struk
{
    int data;
    int kiri;
    int kanan;
};

int main()
{
    int data[15]={22, 52, 64, 11, 2, 5, 98, 102, 33, 65, 14, 77, 25, 19, 20}, i, a, target, parent, temp;

    struct struk pohon[15];

    parent=data[0];
    pohon[0].data=data[0];

    for (i=0;i<15;i++)
    {
        pohon[i+1].data=data[i+1];
        if (data[i+1]<=parent)
            pohon[i].kiri = i+1;
        else if (data[i+1]>parent)
            pohon[i].kanan = i+1;
    }

    printf("Data sebelum diurutkan:\n");

    for(i=0;i<15;i++)
        printf("%d ", pohon[i].data);

    for(i=0;i<15;i++)
        for(a=0;a<15;a++)
            if(pohon[a].data>pohon[a+1].data)
            {
                temp=pohon[a].data;
                pohon[a].data=pohon[a+1].data;
                pohon[a+1].data=temp;
            }

    printf("\n\nData setelah diurutkan:\n");
    for(i=0;i<15;i++)
        printf("%d ", pohon[i].data);
    printf("\n");

return 0;
}
