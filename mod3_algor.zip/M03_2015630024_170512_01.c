// Michael Evans
// 2015630024
// Soal 01 linked list full menu

#include<stdio.h>
#include<stdlib.h>

struct node
{
int nomor;
struct node *next;
};

void masukan(struct node *llist, int no);
int cari(struct node *llist, int no);
void hapus(struct node *llist, int no);
void tampil(struct node *llist);

int main(void)
{
int no = 0;
int input = 1;
int retval = 0;
struct node *llist;

llist=(struct node *)malloc(sizeof(struct node));
llist->nomor = 0;
llist->next = NULL;


while(input !=0)
{
printf("Menu Pilihan\n");
printf("0) Keluar\n");
printf("1) Masukan\n");
printf("2) Hapus\n");
printf("3) Cari\n");
printf("4) Tampilkan\n");
scanf("%d", &input);

switch(input)
{
case 0:
default:
printf("Terima Kasih...\n");
input = 0;
break;

case 1:
printf("Masukan angka yang ingn dimasukan :\n");
scanf("%d", &no);
masukan(llist, no);
break;

case 2:
printf("Masukan angka yang ingin dihapus :\n");
scanf("%d", &no);
hapus(llist, no);
break;

case 3:
printf("Masukan angka yang ingin dicari :\n");
scanf("%d", &no);
if((retval=cari(llist, no))==-1)
printf("nilai %d tidak ditemukan\n", no);
else
printf("nilai %d terletak di %d \n", no, retval);

break;



case 4:
printf("Berikut adalah tampilan dari Linked list yang Anda Buat :\n");
tampil(llist);
break;
}

}


free(llist);
return 0;

}

void tampil(struct node *llist)
{
while(llist->next !=NULL)
{
printf("%d", llist->nomor);
llist=llist->next;
}
printf("%d", llist->nomor);
}



void masukan(struct node *llist, int no)
{
while(llist->next !=NULL)
llist=llist->next;

llist->next=(struct node *)malloc(sizeof(struct node));
llist->next->nomor=no;
llist->next->next=NULL;
}

void hapus(struct node *llist, int no)
{
struct node *temp;
temp = (struct node *)malloc(sizeof(struct node));

if(llist->nomor==no)
{
temp = llist->next;
free(llist);
llist=temp;
}
}

int cari(struct node *llist, int no)
{
int retval = -1;
int i = 1;

while(llist->next->nomor != no)
{

if(llist->next !=NULL)
return i;
else
i++;
llist=llist->next;

}

return retval;
}





