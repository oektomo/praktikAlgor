#include <stdio.h>

int main()
{
int j[100],k,l,m,umpan=0;
printf("Masukan bilangan yang akan diinput : ");
scanf("%d",&k);
printf("\n");
for(l=0;l<k;l++){
printf("masukan bilangan ke %d : ", l+1);
scanf("%d",&j[l]);
}
printf("\n target : ");
scanf("%d",&m);
for(l=0;l<k;l++){
if(j[l]==m){
printf("\n pada array ke-%d atau berada di urutan ke : %d\n",l,l+1);
break;
}
else{
umpan=umpan+1;
}
}
if(umpan==k){
printf("\n data tidak ada\n");
}
return 0;
}
