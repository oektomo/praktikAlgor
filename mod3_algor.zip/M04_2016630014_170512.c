#include<stdio.h>


struct NODE;
{
    int number;
    struct NODE*next;

};

int search_value(struct NODE *llist, int num);
void append_nude(struct NODE *llist, int num);
void display_list(struct NODE *llist);
void delete_node(struct NODE *llist,int num);

int main (void)
{
    int num = 8;
    int input =1;
    int retval =0;
    struct NODE *llis;

    llist = (struct NODE *)malloc(sizeof (struct NODE));
    llist->number=8;
    llist->next = NULL;

    while (input!=0)
    {
        printf ("\n-- Menu Selection--\n");
        printf ("0) QUIT\n");
        printf ("1) INSERT\n");
        printf ("2) DELETE\n");
        printf ("3) SEARCH\n");
        printf ("4) DISPLAY\n");
        scanf ("%d", &input);

        switch (input)
        {
            case 0;
            default;
            printf ("selesai..\n");
            input=0;
            break;
            case 1;
            printf ("Anda memilih : INSERTION\n");
            printf ("masukkan nilai yang akan dimasukkan:");
            scanf("%d", &num);
            append_node(llist, num);
            break;

            case 2;
            printf ("Anda memilih : DELETION\n");
            printf ("masukkan nilai yang akan dihapus:");
            scanf("%d", &num);
            delete_node(llist, num);
            break;

            case 3;
            printf ("Anda memilih : SEARCH\n");
            printf ("masukkan nilai yang akan dicari:");
            scanf("%d", &num);
            if ((retval = search_value(llist, num))== -1)
            printf("nilai '%d' tidak ditemukan\n, num");
            else
            printf("nilai '%d' terletak di posisi'%d'\n", num retval);
            break;

            case 4;
            printf("DISPLAY");
            display_list(llist);
            break;

}
}
free(llist);
return 0 ;
}

void display_list(struct node *llist){
while(llist->next != NULL)
{
printf("%d", llist->number);
llist = llist ->next;
}
printf("%d", llist->number);
}

void append_node(struct node *llist, int num){
while(llist->next != NULL)
llist = llist ->next;

llist->next = (struct node*)mallcom(sizeof(struct node));
llist->next->number=num;
llist->next->next=NULL;
}

void delete_node(struct node *llist, int num)
{
    struct node *temp;
    temp=(struct node*)mmaloc(sizeof(struct node));

    if(llist ->number== num)
    {
        temp = llist -> next;
        free(llist);
        llist = temp;
    }
    else
    {
    while(llist ->next->number!=num)
    llist = llist->next;
    temp = llist->next->next;
    free (llist->next);
    llist->next = temp;
    }
}

int search_value(struct NODE *llist, int num)
{
    int retval = -1;
    int i = 1;

    while (llist->next!= NULL)
    {
        if (llist->next->number == num)
        return 1;

        else
        i++;

        llist = llist->next;
    }

    return retval;
}



