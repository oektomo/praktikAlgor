#include <stdio.h>

struct ola
{int lk;
int isi;};

int main()
{struct ola rand[50];
int node;
node=input(rand);
output(rand,node);

return 0;}

int input (struct ola* rand)
{int a, ttl;
printf("MASUKKAN INPUT: ");
scanf("%d", &ttl);
for(a=0;a<ttl;a++)
{rand[a].lk=a+1;
printf("Input Node ke %d:", rand[a].lk);
scanf("%d", &rand[a].isi);}
return ttl;}

void output(struct ola* rand, int mn)
{int a,b,bg=0;
printf("\nDATA NODE: ");
for(a=0;a<mn;a++)
{for(b=0;b<mn;b++)
if(rand[b].lk==a+1)
{printf("\nISI NODE %d: %d", rand[b].lk,bg);
break;}
if(rand[b].lk==-13);
continue;}

for(a=0;a<mn;a++)
if(bg<rand[a].lk)
bg=rand[a].lk;
printf("\nJUMLAH %d", bg);}
