/*
    M04_2016630030_04.c

    Nama: Raymond Christian
    NPM : 2016630030
*/
#include<stdio.h>


struct hai
{
    int tautan;
    int isi;
};

//prototype disatuin dengan fungsi karena jika fungsi di bawah maka program mendeteksi deklarasi fungsi 2x
int input(struct hai* larik)
{
    int x, masukkan;

    printf("Input jumlah node:");
    scanf("%d",&masukkan);

    for(x=0;x<masukkan;x++)
    {
        larik[x].tautan=x+1;    //input node
        printf("Input node ke-%d: ",larik[x].tautan);
        scanf("%d",&larik[x].isi); //input isi node
    }
}

void cari(struct hai* larik,int total,int dicari)
{
    int x=-1,hai=1;

    while(1) // kode ini bisa menampilkan data yang sama lebih dari 1
    {
        x++;

        if(hai==0)
        {
            if(larik[x].isi==dicari) //bila tidak menemukan data yang sama di if baris 47 maka loop tidak akan pernah masuk ke sinih
                printf(" dan ke-%d",larik[x].tautan);
            if(x==total)    //fungsi akan selelasi di sini jika menemukan data yang dicari
                return;
        }
        if(larik[x].isi==dicari&&hai==1) // sebelum ada data yang ketemu sama dengan dicari maka proses akan lewat sini (karena variabel hai)
        {
            printf("\nData dengan nilai %d adai di node ke-%d", dicari, larik[x].tautan);
            hai=0; //bila fungsi menemukan data yang dicari maka vairabel hai akan berubah menjadi 0 sehingga loop tidak akan pernah masuk ke if ini lagi tapi masuk ke if di barids ke 42
        }

        if(x==total)   //loom akan break di sini jika tidak menemukan data yang dicari
            break;

    }
    printf("\nData dengan nilai %d tidak ada", dicari);
}

void output(struct hai* larik,int total)
{
    int dicari;

    printf("\nData yang dicari adalah:");
    scanf("%d",&dicari); // input data yang dicari

    cari(larik,total,dicari);
}

int main(void)
{
    struct hai larik[20];
    int penunjuk=input(larik);

    output(larik,penunjuk);

    return 0;
}
