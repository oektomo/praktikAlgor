#include <stdio.h>

struct struktur
{
    int data;
    int linked;
};

int main()
{
struct struktur linkedlist[10];
int i, node, x, value=0;

printf("masukan jumlah node: ");
scanf("%d", &node);

for(i=0; i<node; i++)
{
    printf("masukan node ke-%d: ", i+1);
    scanf("%d", &linkedlist[i].data);
    linkedlist[i].linked=i+1;
}

printf("\n data setiap node : \n");
x=value;
for(i=0; i<node; i++)
{
    printf("data node ke %d : %d\n", i+1, linkedlist[x].data);

    x=linkedlist[x].linked;
}

printf("Jumlah node : %d\n", node);

return 0;
}
