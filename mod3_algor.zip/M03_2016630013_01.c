/*
*  M03_2016630013_01.c
*
*  Created on   : Mei 12, 2017
*  Author       : Ain Al Qudhat Ilahi Rifai-2016630013
*
*  @file M03_2016630013_01.c
*  @author Ain Al Qudhat Ilahi Rifai-2016630013
*  @brief linked list dengan jumlah input yang user ingin inputkan
*/

#include <stdio.h>
#include <stdlib.h>

struct NODE {
    int number;
    struct NODE *next;
};

void append_node(struct NODE *llist, int num);
int  search_value(struct NODE *llist, int num);
void display_list(struct NODE *llist);

int main(void)
{
    int num = 0;
    int input = 5;
    int retval = 0;
    struct NODE *llist;

    llist = (struct NODE *)malloc(sizeof(struct NODE));
    llist->number = 0;
    llist->next = NULL;

    while(input !=0){
    printf("=== Pilih Menu ===\n");
    printf("0: Keluar\n");
    printf("1: Insert\n");
    printf("2: Searh\n");
    printf("3: Tampilkan\n");
    printf("\nPilihan:");
    scanf("%d", &input);

    if(input==0)
    {
    printf("...Terima kasih...\n");
    }
    else if(input==1)
    {
    printf("Pilihan: Insert\n");
    printf("Masukan Nilai yang akan di insert: ");
    scanf("%d", &num);
    append_node(llist, num);
    }
    else if(input==2)
    {
    printf("Pilihan: Search\n");
    printf("Masukan Nilai yang mau di cari: ");
    scanf("%d", &num);
    if((retval = search_value(llist, num)) == -1)
    printf("nilai '%d' tidak ketemu\n", num);
    else
    printf("nilai '%d' ditemui di posisi '%d'\n",num, retval);
    }
    else if(input==3)
    {
    printf("Pilihan: Tampilkan\n");
    display_list(llist);
    }
    }
    free(llist);
    return(0);
}

void append_node(struct NODE *llist, int num)
{
while(llist->next != NULL)
llist = llist-> next;

llist->next = (struct NODE*)malloc(sizeof(struct NODE));
llist->next->number = num;
llist->next->next = NULL;
}

int search_value(struct NODE *llist, int num)
{
int retval= -1;
int i= 1;

while(llist->next !=NULL)
{
if(llist->next->number == num)
return i;
else
i++;

llist = llist->next;
}
return retval;
}

void display_list(struct NODE *llist)
{
while(llist->next != NULL)
{
printf("%d   ", llist->number);
llist= llist->next;
}
printf("%d\n", llist->number);
}
