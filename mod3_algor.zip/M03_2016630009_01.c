#include<stdio.h>

struct apa
{
    int tab;
    int isi;
};

int input (struct apa* chained)
{
    int x, jumlah;

    printf("masukan jumlah node: ");
    scanf("%d",&jumlah);

    for(x=0;x<jumlah;x++)
    {
        chained[x].tab=x+1;
        printf("node ke-%d: ",chained[x].tab);
        scanf("%d",&chained[x].isi);
    }

    return jumlah;
}

void output(struct apa* chained,int much)
{
    int i,j,nilai=0;

    printf("data setiap node: ");

    for(i=0;i<much;i++)
    {
        for(j=0;j<much;j++)
            if(chained[j].tab==i+1)
        {
            printf("\nisi node nilai ke%d: %d",chained[j].tab,chained[j].isi);
            break;
        }
        if (chained[j].tab==-13);
            continue;
    }

    for(i=0;i<much;i++)
        if(nilai<chained[i].tab)
            nilai=chained[i].tab;

    printf("\n jumlah node: %d",nilai);
}

int main(void)
{
    struct apa chained[100];
    int node;

    node=input(chained);
    output(chained,node);

    return 0;
}
