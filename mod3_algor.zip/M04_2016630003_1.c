#include <stdio.h>
int main(){
    int a[15] = {22, 52, 64, 11, 2, 65, 98, 102, 33, 5, 4, 77, 25, 19, 20};
    int i, t, x=0, y;
    printf("Isi array: ");
    for(i=0;i<15;i++){
        printf("%d ",a[i]);
    }

    printf("\nTarget: ");
    scanf("%d", &t);

    for(i=0;i<15;i++){
     if(t==a[i]){
        x=i+1;
        printf("\nNilai %d ditemukan pada array ke-%d\n", t, x);
        printf("Note: Urutan array dihitung dari 1\n\n");
        y=1;
        break;
        }
            else{
                y=0;
            }
    }
    if(y==0){
        printf("\nNilai tidak ditemukan!!\n\n");
        }
return 0;
}
