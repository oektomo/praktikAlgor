#include<stdio.h>
#include<stdlib.h>

struct NODE
{
    int number;
    struct NODE *next;
};

void tambahnode(struct NODE *llist, int num);
void tampilkan(struct NODE *llist);

int main()
{
    int num = 0;
    int input = 5;
    int retval = 0;
    int banyak,i;
    struct NODE *llist;

    llist = (struct NODE *)malloc(sizeof(struct NODE));
    llist->number=0;
    llist->next=NULL;

    printf("Input Jumlah node :");
    scanf("%d",&banyak);
    for(i=0;i<banyak;i++)
    {
        printf("Masukkan nilai node %d :",i+1);
        scanf("%d",&num);
        tambahnode(llist, num);
    }
    printf("\n");
    tampilkan(llist);
    printf("Banyaknya node : %d\n",banyak);
    free(llist);
    return 0;
}

void tambahnode(struct NODE *llist, int num)
{
    while(llist->next != NULL)
    {
        llist = llist->next;
    }
    llist->next = (struct NODE *)malloc(sizeof(struct NODE));
    llist ->next->number = num;
    llist->next->next = NULL;
}

void tampilkan(struct NODE *llist)
{
    int a=1;
    while(llist->next != NULL)
    {
        llist = llist->next;
        printf("node %d = %d\n",a,llist->number);
        a++;
    }
}
