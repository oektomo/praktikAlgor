/**
*   M03_201663027_170512.c
*
*   Created On : Mei 12, 2017
*   Author     : Sin Euy Gun- 201663027
*
*   @file M03_201663027_170512.c
*   @author Sin Euy Gun - 2016630027
*   @brief Linked List
*/
#include <stdio.h>
#include <stdlib.h>
struct simpulsenarai
{
int data;
struct simpulsenarai *berikuPtr;
};

typedef struct simpulsenarai simpulsenarai;
typedef simpulsenarai*simpulsenaraiPointer;

void sisip(simpulsenaraiPointer*SPtr, int angka);
void tampilsenarai(simpulsenaraiPointer sekarangPtr);

int main()
{
    simpulsenaraiPtr awalPtr=NULL;
int pilihan;
int isi;

printf( "Masukan Pilihan Anda\n"
        "1. Untuk meyipsikan sebuah elemen kedalam senarai.\n
        "2. untuk mengakhiri program.\n);
        scanf("%d, &pilihan");

        while (pilihan!=3)
        {
        switch(pilihan)
        {
        case 1;
            printf("masukan sebuah data:");
            scanf("%d", &isi);
            sisip(&awalPtr, isi);
            tampilsenarai(awalPtr);
            break;
            default;
            printf("plihan tidak benar.\n\n");
            printf("Masukan Pilihan anda"
                 "1. Untuk meyipsikan sebuah elemen kedalam senarai.\n
                 "2. untuk mengakhiri program.\n);
                 break;
                 }
                 scanf("%d", &pilihan);
                 }
                 printf("terima kasih\n");
                 return 0;
                 }
void sisip (simpulsenaraiPointer*SPtr, int angka)
{
simpulsenaraiPointer baruPtr;
simpulsenaraiPointer sebelumPtr;
simpulsenaraiPointer sekarng Ptr;
baruPtr=malloc(sizeof(simpulsenarai));
if(baruPtr!=NULL)
    {
    baruPtr->data=angka;
    baruPtr->berikutPtr=NILL;
    sebelumPtr=NULL;
    sekarangPtr=SPtr;
    while(sekarangPtr!=NULL&&angka>sekarangPtr->data)
    {
    sebelumPtr= sekarangPtr;
    sekarangPtr=sekarangPtr->berikutPtr;
    }
    if(sebelumPtr==NULL)
        {
        baruPtr->berikutPtr=*SPtr;
        *Sptr=baruPtr;
        }
    else
    {
    sebelumPtr_>berikutPtr=*SPtr;
    baruPtr->berikutPtr=sekarangPtr;
    }
    }
else
{
printf("%d tidak disisipkan. tidak ada memori tersedia\n", angka);
}}

void tampilsenarai(simpulsenaraiPointer sekarangPtr)
{
printf("senarai adalah:\n");
while(sekarangPtr!=NULL)
    {
    printf("%d -->", sekarangPtr->data);
    sekarangPtr= sekarang Ptr->berikut Ptr;
    }
    printf("kosong\n\n");
    }

