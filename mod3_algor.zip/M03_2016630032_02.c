#include <stdio.h>

struct link_list
{
 int link;
 int isi;
};
void keluaran(struct link_list* lix, int total)
{
    int x,y,z=0;
    for(x=1;x<=total;x++)
    {
        for(y=1;y<=total;y++)
            if(lix[y].link==x)
            {
            printf("Isi Node ke %d : %d\n", lix[x].link, lix[y].isi);
            }
    z++;
    }
    printf("Jumlah Node : %d\n", z);

}

int input_baru(struct link_list* lix, int dat, int pos_dat, int total)
{
int bilangan, jalan,x;
int z,temp;

    printf("Masukkan Data yang Akan Dimasukkan : ");
    scanf("%d", &dat);
    printf("Masukkan Posisi Node : ");
    scanf("%d", &pos_dat);
    z=total;
    for(x=1;x<=total;x++)
    {
        if(lix[x].link>=pos_dat)
        {
            lix[x].link++;
            temp=lix[x].isi;
        }
    }
        lix[x].link=pos_dat;
        lix[x].isi=dat;
}

int main()
{
    int banyak,i,dat, pos_dat, nambah, z;
    struct link_list lix[50];
    printf("Masukkan Banyak Data: ");
    scanf("%d", &banyak);


    for(i=1; i<=banyak; i++)
    {
        lix[i].link=i;
        printf("Masukkan Data %d: ", i);
        scanf("%d", &lix[i].isi);
    }

    keluaran(lix,banyak);

    nambah=input_baru(lix,dat,pos_dat,banyak);
    z=banyak+1;
    keluaran(lix,z);

}
