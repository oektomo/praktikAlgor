#include<stdio.h>

struct o
{
int lk;
int isi;
};

int main()
{
struct o rand[50];
int node;
node=input(rand);
output(rand,node);
return 0;
}

int input(struct o* rand)
{
int a, ttl;
printf("INPUT JUMLAH NODE =  ");
scanf("%d", &ttl);

for(a=0;a<ttl;a++)
{
rand[a].lk=a+1;
printf("INPUT NODE KE %d =  ", rand[a].lk);
scanf("%d", &rand[a].isi);
}
return 0;
}
