#include <stdio.h>

struct struk
{
    int data;
    int link;
};

int main ()
{
    struct struk linklist[10];

    int i, node, a, head=0, kosong;

    for(i=0;i<10;i++)
        linklist[i].data=-99;

    printf("Input Jumlah Node: ");
    scanf("%d", &node);

    for(i=0;i<node;i++){
    printf("Input Node %d\t: ", i+1);
    scanf("%d", &linklist[i].data);
    linklist[i].link=i+1;
    }

    printf("\nData setiap node adalah : \n");
    a=head;
    for(i=0;i<node;i++){
    printf("Data Node %d\t: %d\n", i+1,linklist[a].data);
    a=linklist[a].link;
    }

    printf("Jumlah node\t:%d\n\n", node);

    for(i=0;i<10;i++)
        if(linklist[i].data==-99){
        kosong=i;
        break;
        }

    printf("Masukkan data yang akan dimasukkan : ");
    scanf("%d", &linklist[kosong].data);
    printf("Masukkan posisi node yang akan dimasukkan : ");
    scanf("%d", &linklist[kosong].link);

    if(linklist[kosong].link==1)
        head=kosong;

    linklist[kosong].link-=1;
    linklist[linklist[kosong].link -1].link=kosong;
    node++;

    printf("\nData setiap node adalah : \n");
    a=head;
    for(i=0;i<node;i++){
        printf("Data Node %d\t: %d\n", i+1, linklist[a].data);
        a=linklist[a].link;
    }

    printf("Jumlah node\t: %d\n\n", node);

return 0;
}
