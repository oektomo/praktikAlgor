#include <stdio.h>


int *array[100],banyak_data,counter_0, cek;
void tes();

void main()
{

    printf("Masukkan Jumlah Input : ");
    scanf("%d", &banyak_data);

    for(counter_0=0; counter_0<banyak_data; counter_0++)
    {
    printf("Input : ");
    scanf("%d", &array[counter_0]);
    }
    tes(0,banyak_data-1);

    for(counter_0=0; counter_0<banyak_data; counter_0++)
    printf("Output array[%d]: %d\n", counter_0, *array[counter_0]);

}

void tes(int awal, int akhir)
{
    int *locker,*lc,counter_0,counter_n;
    if(awal<akhir)
    {
        lc=array[awal];
        counter_0=awal;
        counter_n=akhir;

        while(awal<akhir)
        {
            while(array[counter_0]<=lc && counter_0<akhir)
            counter_0++;

            while(array[counter_n]>=lc && counter_n>awal)
            counter_n--;

            if(counter_0<counter_n)
            {
                locker=array[counter_0];
                array[counter_0]=array[counter_n];
                array[counter_n]=locker;
            }

        }

    locker=array[awal];
    array[awal]=array[counter_n];
    array[counter_n]=locker;

    tes(awal,counter_n-1);
    tes(counter_n+1, akhir);
    }
}


