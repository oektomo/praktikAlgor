/*  M02_2015630022_200417_04.c
*
*   IDHAM HANIF AYEGA - 2015630022
*   APRIL 20, 2017
*
*
*   PRAKTIKUM 02 ALGORITMA DAN STRUKTUR DATA
*/

#include <stdio.h>
#include <time.h>

int main ()
{
int n, random, i, array [41];
printf ("masukkan banyaknya angka random :");
scanf ("%d", &n);

srand (time(NULL));
for (i=i;i<=n; i++)
    {
        random = rand()%(27)+1;
        array[i]= random;
    }
printf ("angka sebelum di sort :\n");
for (i=1;i<=n;i++)
    {
        printf("%d", array[i]);
    }
printf ("/n");
printf ("angka setelah di sort: \n");
bubble_sort(array[41,n]);
for (i=0;i<n-1;i++)
        {
            printf("%d",array[i]);
        }

return 0;
}

void bubble_sort(int a[], int n)
{
    int i;
    int j;
    int temp;
    for (i=0;i<n-1;i++)
        {
            for (j=0;j<n-1;j++)

                {
                    if (a[j]> a[j+1])
                    {
                        temp = a[j];
                        a[j]= a[j+1];
                        a[j+1]= temp;
                    }
                }
        }
}

