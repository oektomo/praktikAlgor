#include <stdio.h>

void partition(int list[],int low,int high);
void mergesort(int list[],int low,int mid,int high);

int main (){


    int list [50];
    int i,ukuran;


    printf("masukan jumlah data: \n");
    scanf("%d",&ukuran);
    printf("Masukan data: \n");
        for(i=0;i<ukuran;i++){

        scanf("%d",&list[i]);

        }
    partition(list,0,ukuran-1);
    printf("setelah di sorting : \n");
        for(i=0;i<ukuran;i++)
        {
            printf("(%d)\n",list[i]);

        }
    return 0;

}

    void partition(int list[],int low,int high){
        int mid;

        if(low<high)
            {
                mid = (low + high)/2;
                partition(list,low,mid);
                partition(list,mid+1,high);
                mergesort(list,low,mid,high);
            }

    }

void mergesort(int list[],int low,int mid,int high){

int i,m,k,l, temp[50];

    l=low;
    i =low;
    m = mid + 1;
    while((l<=mid) && (m<=high))
    {

    if(list[l]<=list[m])
    {
        temp [i]=list[l];
        l++;
    }
    else
    {
        temp[i]=list[m];
        m++;
    }
    i++;
   }
   if (l>mid)
{

    for(k=m;k<=high;k++)
    {
        temp[i]=list [k];
        i++;
    }

}

    else
    {
        for(k=l;k<=mid;k++)
        {
            temp[i] = list[k];
            i++;
        }
    }

    for (k=low;k<=high;k++)
    {
        list[k] = temp[k];
    }

    }
