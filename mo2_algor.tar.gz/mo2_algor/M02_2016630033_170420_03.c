/*
*       M02_2016630033_170420_03.c
*
*       Created on      :   Mar 20, 2017
*       Author          :   Reyvaldo Barthez-2016630033
*
*       @file       M02_2016630033_170420_03.c
*       @author     Reyvaldo Barthez-2016630033
*       @brief      Deskripsi program
*/

#include <stdio.h>

void mergesort(int[], int,int,int);
void partition(int[],int,int);

int main()
{
    int list[50];
    int x, data;

    printf("masukkan jumlah data    :");
    scanf("%d", &data);
    printf("masukkan data:\n");
    for(x=0; x < data; x++)
    {
        scanf("%d", &list[x]);
    }
    partition(list, 0, data -1);
    printf("Setelah merge sort:\n");
    for(x=0; x < data; x++)
    {
        printf("%d", list[x]);
    }
return 0;
}

void partition(int list[], int low, int high)
{
    int mid;

    if(low < high)
    {
        mid = (low + high)/2;
        partition(list, low, mid);
        partition(list, mid+1, high);
        mergesort(list, low, mid, high);
    }
}

void mergesort(int list[], int low, int mid, int high)
{
    int i, mi, k, io, temp[50];

    io = low;
    i  = low;
    mi = mid + 1;
    while ((io <= mid) && (mi <= high))
    {
    if(list[io] <= list[mi])
    {
        temp[i] = list[io];
        io++;
    }
    else
    {
        temp[i] = list[mi];
        mi++;
    }
    i++;
}
if (io > mid)
{
    for (k = mi; k <= high; k++)
    {
    temp[i] = list[k];
        k++;
    }
}
else
{
    for (k = io; k <= mid; k++)
    {
    temp[i] = list[k];
        i++;
    }
}

    for (k = low; k <= high; k++)
    {
    list[k] = temp[k];
    }
}
