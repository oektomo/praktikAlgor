#include<stdio.h>
#include<time.h>

int quick_a(int a[],int kiri,int kanan)
{

int x = kiri;
int y = kanan;

int temp;
int pivot=a[(kiri+kanan)/2];

while(x<=y)
{
while(a[x]<pivot)x++;
while(a[y]>pivot)y--;

if(x<=y)
{
temp=a[x];
a[x]=a[y];
a[y]=temp;
x++;
y--;

}
}

if(kiri<y)quick_a(a,kiri,y);
if(x<kanan)quick_a(a,x,kanan);

}

int main()

{
int n,i,random,array[100],angka;

printf("masukkan angka random:");
scanf("%d",&n);

srand(time(NULL));

for(i=0;i<n;i++)
{
random = rand()%30+1;
array[i]=random;
printf("angka ke-%d: %d\n",i+1,array[i]);

}

printf("angka sebelum di sort:\n");

for(i=0;i<n;i++){
printf("%d",array[i]);
}
printf("\n");
quick_a(array,0,n-1);
printf("setelah di sortir:\n");
for(i=0;i<n;i++){
printf("%d",array[i]);
}
}
