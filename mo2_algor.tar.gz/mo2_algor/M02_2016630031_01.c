#include <stdio.h>
#include <time.h>
int quick_a(int a[],int left , int right)
    {
    int x = left;
    int y = right;
    int temp;
        int pivot=a[(left+right)/2];
        while (x<=y)
        {
        while (a[x]<pivot)x++;
        while (a[y]>pivot)y--;
            if(x<=y){
        temp=a[x];
        a[x]=a[y];
        a[y]=temp;
        x++;
        y--;
        }
    }
    if(left<y)quick_a(a,left,y);
    if(x<right)quick_a(a,x,right);
    }
int main()
    {
int n,i,random,array[100],angka;
    printf("masukkan banyaknya angka random : ");
    scanf("%d",&n);
        srand(time(NULL));
        for(i=0;i<n;i++)
            {
            random=rand()%30+1;
            array[i] = random ;
            printf("angka ke - %d = %d\n",i+1,array[i]);
            }
        printf("angka sebelum proses quicksort = \n");
            for(i=0;i<n;i++)
                {
                printf("%d\t",array[i]);
                }
            printf("\n");
            quick_a(array,0,n-1);
            printf("setelah di sort  : \n");
            for (i = 0;i<n;i++)
                {
                printf("%d\t",array[i]);
                }

    }
