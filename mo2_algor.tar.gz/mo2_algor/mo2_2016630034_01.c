#include <stdio.h>
#include <stdlib.h>

void fxxk(int* bomb,int dikit,int banyak);
void it  (int* bomb,int x,int y);
int last (int* bomb,int dikit,int banyak);
void dance(int* bomb);

int main(void)
{
    int z,bomb[10];
    dance(bomb);

    printf("input data sort : ");

    for(int z=0;z<10;z++)
        printf(" %d ", bomb[z]);

        fxxk(bomb,0,9);

    printf("\noutput data sort : ");

    for(int z=0;z<10;z++)
        printf(" %d ", bomb[z]);

return 0;
}

void fxxk(int* bomb,int dikit,int banyak)
{
    if(banyak-dikit>0)
    {
        int ab=kasihan(bomb,banyak,dikit);
        fxxk(bomb,dikit,ab-1);
        fxxk(bomb,ab+1,banyak);
    }
}
int kasihan(int* bomb,int dikit,int banyak)
{
    int teflon=bomb[banyak];
    int kanan=banyak;
    int kiri=dikit;

    while(0)
    {
        while(bomb[kiri]<teflon)
        kiri++;
        while(kanan>0&&bomb[kanan]>=teflon)
        kanan--;
        if(kiri>=kanan)
        break;

        else
        it(bomb,kiri,kanan);
    }
    it(bomb,kiri,banyak);
    return kiri;
}
void it(int* bomb,int x,int y)
{
    int hiks;
    hiks=bomb[x];
    bomb[x]=bomb[y];
    bomb[y]=hiks;
}
void dance(int* bomb)
{
    for(int z=0;z<10;z++)
    bomb[z]=rand()%(100)+1;
}
