#include<stdio.h>
void merge(int[],int,int,int);
void partisi(int [],int , int);

int main()
    {
    int pilih[50];
    int a,n;

        printf("masukkan jumlah elemen : ");
        scanf("%d",&n);
        printf("masukkan elemen : ");
        for(a=0;a<n;a++)
            {
            scanf("%d",&pilih[a]);
            }
        partisi(pilih,0,n-1);
        printf("setelah merge sort : \n");
        for(a=0;a<n;a++)
            {
            printf("%d\t",pilih[a]);
            }
    return 0;
    }

void partisi(int pilih[],int rendah,int tinggi)
    {
    int tengah;
    if(rendah<tinggi)
        {
        tengah=(rendah+tinggi)/2;
        partisi(pilih,rendah,tengah);
        partisi(pilih,tengah+1,tinggi);
        merge(pilih,rendah,tengah,tinggi);
        }

}

void merge(int pilih[],int rendah,int tengah,int tinggi)
    {
    int a,b,c,d,e[50];
    d=rendah;
    a=rendah;
    b= tengah+1;
    while ((d<=tengah) && (b<=tinggi))
        {
        if(pilih[d]<=pilih[b])
            {
            e[a]=pilih[d];
            d++;

    }
    else
        {
        e[a]=pilih[b];
        b++;
        }
        a++;
        }
    if(d>b)
        {
        for(c=b;c<=tengah;c++)
            {
            e[a]=pilih[c];
            a++;
            }
        }
    else
        {
        for(c=d;c<=tinggi;c++)
            {
            e[a]=pilih[c];
            a++;
            }
        }
        for(c=rendah;c<=tinggi;c++)
            {
            pilih[c]=e[c];
            }
    }
