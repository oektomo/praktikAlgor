/**
*   M02_2016630024_170420_04.c
*
*   Created On  : 04 20, 2017
*   Author      : Muhammad Annura Subhan-2016630024
*
*   @file M02_2016630024_170420_04.c
*   @author Muhammad Annura Subhan-2016630024
*   @brief Sorting
**/

#include <stdio.h>
#include <stdlib.h>

void Acak(int* larik);
void Ganti(int* larik, int A, int B);
void Buble(int* larik);

int main()
{
    int A, larik[10];

    Acak(larik);

    printf("Sebelum Sort : ");
    for(int A=0; A<10; A++)
    {
        printf("%d ", larik[A]);
    }

    Buble(larik);

    printf("\nSesudah Sort : ");
    for(int A=0; A<10; A++)
    {
        printf("%d ", larik[A]);
    }

return 0;
}

void Acak(int* larik)
{
    for(int A=0; A<10; A++)
    {
        larik[A]=rand()%(27)+1;
    }
}

void Ganti(int* larik, int a, int b)
{
    int Tukar;

    Tukar=larik[a];
    larik[a]=larik[b];
    larik[b]=Tukar;
}

void Buble(int* larik)
{
    for(int A=0; A<10; A++)
    {
        for(int B=0; B<9-A; B++)
        {
            if(larik[B]>larik[B+1])
            {
                Ganti(larik, B, B+1);
            }
        }
    }

return 0;
}
