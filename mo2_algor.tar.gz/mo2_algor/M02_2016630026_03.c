#include<stdio.h>
#include<stdlib.h>

int main(){

    int x, batas, tems, array[100];

    printf("masukkan batas :"); scanf("%d", &batas);

    for(x=1;x<=batas;x++)
        {
        tems=rand() %(50);
        array[x]=tems;
        printf(" %d", array[x]);
        }
}
