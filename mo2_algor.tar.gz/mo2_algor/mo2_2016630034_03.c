#include <stdio.h>
#include <stdlib.h>

void fpx(int * hiks,int zero,int full,int middle);
void lapak(int * hiks,int zero, int full);
void merona(int * hiks);

int main(void)
{
    int a, hiks[10];
    merona(hiks);

     printf("input data sort : ");

    for(int a=0;a<10;a++)
        printf("%d ", hiks[a]);

        lapak(hiks,0,9);

    printf("\noutput data sort : ");

    for(int a=0;a<10;a++)
        printf("%d ", hiks[a]);

return 0;
}
void fpx(int * hiks,int zero,int full,int middle)
{
    int b,c,d,e[10];
    for(b=zero,c=middle+1,d=zero;b<=middle&&c<=full;d++)
        if(hiks[b]<hiks[c])
            e[d]=hiks[b++];
            else
            e[d]=hiks[c++];

    while(b<=middle)
    e[d++]=hiks[b++];
    while(c<=full)
    e[d++]=hiks[c++];

        for(d=zero;d<=full;d++)
        hiks[d]=e[d];
}
void lapak(int * hiks,int zero, int full)
{
    if(full-zero>0)
    {
        int mid=(full+zero)/2;
        lapak(hiks,zero,mid);
        lapak(hiks,mid+1,full);

        fpx(hiks,zero,full,mid);
    }
}
void merona(int* hiks)
{
    for(int a=0;a<10;a++)
    hiks[a]=rand()%(100)+1;
}
