/**
*   M02_2016630036_01.c
*
*   Created On: 04 20, 2017
*   Author    : Muhammad Zaki Gandara-2016630036
*
*   @file M02_2016630036_01.c
*   @author Muhammad Zaki Gandara-2016630036
*   @brief Sorting
**/

#include<stdio.h>
#include<time.h>


int quicksort(int a[], int kiri, int kanan){
    int x = kiri;
    int y = kanan;
    int temp;
    int pivot = a[kanan];

    while (x<=y){
        while (a[x] < pivot)
        x++;
        while (a[y] > pivot)
        y++;
        if (x<=y){
            temp = a[x];
            a[x] = a[y];
            a[y] = temp;
            x++;
            y--;

        }
    }
        if (kiri<y)
        quicksort(a,kiri,y);
        if (x<kanan)
        quicksort(a,x,kanan);


}
int main (){
    int n,i,random,array[100], angka;

    printf("Masukkan banyaknya angka random: ");
    scanf("%d", &n);

    srand(time(NULL));
    for (i = 0;i<n;i++){
        random = rand()%(100)+1;
        array[i] = random;
        printf("Angka ke-%d: %d \n", i+1,array[i]);
    }

    printf("Angka sebelum di sort: \n");
    for (i = 0;i<n;i++){
        printf("%d ", array[i]);
    }
    printf("\n");
    quicksort(array,0,n-1);
    printf("Setelah di sortir: \n");
    for (i = 0;i<n;i++){
        printf("%d ", array[i]);
    }
return 0;
}
