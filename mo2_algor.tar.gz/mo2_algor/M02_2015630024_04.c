#include<stdio.h>
#include<time.h>

int main(){
int n, random, i, array[100];

printf("masukkan banyak angka random : ");
scanf("%d", &n);

srand(time(NULL));
for(i=1;i<=n;i++){
random=rand()%30+1;
array[i]=random;
}


printf("ankga sebelum disort : \n");
for(i=1;i<=n;i++){
printf("%d", array[i]);
}
printf("\n");

printf("angka setelah disort : \n");
bubble_sort(array[100], n);
for(i=0;i<n-1;i++){
printf("%d", array[i]);
}
return 0;
}


void bubble_sort(int a[], int n){
int i;
int j;
int temp;
for (i=0;i<n-1;i++){
for(j=0;j<n-1-1;j++){
if(a[j]>a[j+1]){
temp = a[j];
a[j]=a[j+1];
a[j+1]=temp;
}
}
}
}
