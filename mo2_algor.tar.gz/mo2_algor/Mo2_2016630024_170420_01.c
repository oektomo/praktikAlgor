/**
*   M02_2016630024_170420_01.c
*
*   Created On  : 04 20, 2017
*   Author      : Muhammad Annura Subhan-2016630024
*
*   @file M02_2016630024_170420_01.c
*   @author Muhammad Annura Subhan-2016630024
*   @brief Sorting
**/

#include <stdio.h>

int quick_a(int a[], int kiri, int kanan)
{
    int x = kiri;
    int y = kanan;
    int temp;
    int pivot = a[(kiri+ kanan)/2];

    while (x<=y)
    {
        while (a[x]<pivot)x++;
        while (a[y]>pivot)y--;

        if(x<=y)
        {
            temp=a[x];
            a[x]=a[y];
            a[y]=temp;
            x++;
            y--;
        }
    }

    if(kiri<y)quick_a(a,kiri,y);
    if(x<kanan)quick_a(a,x,kanan);
}

int main()
    {
        int N, A, array[100], Angka, random;

        printf("Masukkan Angka Random : ");
        scanf("%d", &N);

        srand(time(NULL));

        for(A=0;A<=N;A++)
        {
            random=rand()%30+1;
            array[A]=random;
            printf("Angka ke%d : %d\n", A+1, array[A]);
        }

        printf("Angka Sebelum Di sortir : \n");
        for(A=0;A<N;A++)
        {
            printf("%d\n", array[A]);
        }

        printf("\n");
        quick_a(array,0,N-1);

        printf("Angka Setelah Di Sortir : \n");
        for(A=0;A<N;A++)
        {
            printf("%d\n", array[A]);
        }

return 0;
    }
