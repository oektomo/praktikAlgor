/*
*   M02_2016630030_03.c
*
*   Created on  : Mar 20, 2017
*   Author      : Raymond Christian - 2016630030
*
*   @file M02_2016630030_03.c
*   @author Raymond Christian - 2016630030
*   @brief deskripsi program
*/
#include<stdio.h>
#include<stdlib.h>

//prototype
void randomm(int* larik);
void merge(int* larik, int min,int maks);
void urut(int* larik, int min, int mid, int maks);

int main(void)
{
    int larik[10],x;

    randomm(larik);

    printf("\t\t===Merge Sort===\n");

    printf("Sebelum sort: ");   //menampilkan data sebelum sort
    for(x=0;x<10;x++)
        printf("%d ",larik[x]);

    merge(larik,0,9);

    printf("\nSesudah sort: "); //menampilkan data sesudah sort
    for(x=0;x<10;x++)
        printf("%d ",larik[x]);

    return 0;
}

void randomm(int* larik)
{
    for(int x=0;x<10;x++)       //memasukan data acak ke dalam larik dengan rentang 1-100
        larik[x]=rand()%(100)+1;
}

void merge(int* larik, int min,int maks)
{
    if(maks-min>0)
    {
        int tengah=(maks+min)/2;
        merge(larik,min,tengah);    //memisahkan data menjadi dua bagian (bagian kiri)
        merge(larik,tengah+1,maks); //memisahkan data menjadi dua bagian (bagian kanan)

        urut(larik,min,tengah,maks);//mengurutkan data
    }
}

void urut(int* larik, int min, int mid, int maks)
{
    int hai1,hai2,hai,haijuga[10];
    for(hai1=min,hai2=mid+1,hai=min;hai1<=mid&&hai2<=maks;hai++)   //memasukan data yang lebih kecil ke larik haijuga.
        if(larik[hai1]<larik[hai2])
            haijuga[hai]=larik[hai1++];
        else
            haijuga[hai]=larik[hai2++];

    //memasukan sisa data dari larik ke haijuga;
    while(hai1<=mid)
        haijuga[hai++]=larik[hai1++];
    while(hai2<=maks)
        haijuga[hai++]=larik[hai2++];

    //menyalin data dari haijuga ke larik;
    for(hai=min;hai<=maks;hai++)
        larik[hai]=haijuga[hai];
}
