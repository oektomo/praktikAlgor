#include <stdio.h>

void mergeSort(int [],int, int, int);
void partition(int [], int, int);

int main(){

    int list[50];
    int i, size;

    printf(" Masukan total angka dari elemen: ");
    scanf("%d", &size);
    printf("Masukan elemen: ");
    for(i=0;i<size;i++){

        scanf("%d", &list[1]);
    }
    partition(list, 0, size - 1);
    printf("Sesudah merge sort:\n");
    for(i=0;i<size;i++){

        printf("%d" ,list[i]);
    }
    return 0;
    }
    void partition(int list[], int low, int high)
    {
        int mid;
        if(low<high)
    {
        mid = (low + high)/2;
        partition(list, low, mid);
        partition(list, mid+1, high);
        mergeSort(list, low, mid, high);
    }
}

void mergeSort(int list[], int low, int mid, int high)
{
    int i, mi,k ,lo, temp[50];
    lo = low;
    i = low;
    mi = mid + 1;
    while ((lo <= mid) && (mi <= high))
    {
        if(list[lo] <= list[mi])
        {
            temp[1]=list[lo];
            lo++;
        }
        else
        {
            temp[1] = list [mi];
            mi++;
        }
        i++;
    }
    if (lo>mid)
    {
        for (k=mi; k<=high; k++)
        {
            temp[i] = list[k];
        }
    }
    else
    {
        for (k=lo;k<=mid;k++)
        {
            temp[1] = list [k];
            i++;
        }
    }
    for (k=low;k<=high;k++)
    {
    list [k] = temp[k];
    }
    }
