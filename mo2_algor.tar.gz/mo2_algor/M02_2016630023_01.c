#include <stdio.h>
#include <time.h>


int quick_a(int a[],int kiri,int kanan){

    int o = kiri;
    int p = kanan;
    int temp ;
    int pivot = a[(kiri +kanan)/2];

    while (o<=p){


    while(a[o]<pivot)o++;
    while(a[p]>pivot)p--;
    if(o<=p){
        temp=a[o];
        a[o]=a[p];
        a[p]=temp;
        o++;
        p--;
    }

   }

        if(kiri<p)quick_a(a,kiri,p);
        if(o<kanan)quick_a(a,o,kanan);

        }

     int main (){
        int n,x,random,array[30],angka;

        printf("Masukan jumlah data acak :");
        scanf("%d",&n);

        srand(time(NULL));
        for(x=0;x<n;x++){
        random = rand()%100+1;
        array[x]=random;
        printf("angka ke-%d adalah %d \n",x+1,array[x]);
        }

            printf("angka sebelum sorting:\n");
            for(x=0;x<n;x++){
                printf("%d ",array[x]);

            }
        printf("\n");
        quick_a(array,0,n-1);
        printf("setelah sorting : \n");
        for(x=0;x<n;x++){
            printf("%d ",array[x]);
        }

     }













