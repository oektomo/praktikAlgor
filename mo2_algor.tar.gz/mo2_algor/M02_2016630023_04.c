#include <stdio.h>

int main (){

    int n,random,x,array[41];


    printf("Masukan jumlah data random");
    scanf("%d",&n);


    srand(time(NULL));
        for(x=1;x<=n;x++){
            random = rand()%30+1;
            array[x] = rand;
            }

        printf("Angka sebelum sorting : \n");
            for(x=1;x<=n;x++){
            printf("%d",array[x]);
            }
            printf("\n");

         printf("Angka setelah di sorting : \n");
         bubble(array[41],n);
                for(x=0;x<n-1;x++){

                printf("%d",array[x]);}

    return 0;

}

    void bubble(int a[],int n){
        int x;
        int j;
        int temp;

    for(x=0;x<n-1;x++){
        for (j=0;j<n-x-1;j++){
            if(a[j] > a[j+1]){
            temp = a[j];
            a[j]=a[j+1];
            a[j+1]=temp;

            }

        }

    }


    }
