#include<stdio.h>
#include<stdlib.h>

void urutan(int*array,int min,int maks,int mid);
void merge(int*array,int min,int maks);
void rando (int*array);

int main(void)
{
int loop,array[10];

    rando(array);

    printf("sebelum sort= ");
    for (loop=0;loop<10;loop++)
        printf("\n%d",array[loop]);

    merge(array,0,9);

    printf("\nSesudah sort= ");
    for (loop=0;loop<10;loop++)
        printf("\n%d",array[loop]);

return 0;
}

void urutan(int*array,int min, int maks, int mid)
{
int a,b,c,array2[10];

for (a=min,b=mid+1,c=min;a<=mid&&b<=maks;c++)
    if(array[a]<array[b])
    array2[c]=array[a++];
    else array2[c]=array[b++];

    while(a<=mid)
    array2[c++]=array[a++];
    while(b<=maks)
    array2[c++]=array[b++];

    for(c=min;c<=maks;c++)
    array[c]=array2[c];

}

void merge(int*array,int min,int maks)
{
if(maks-min>0)
{
int mid=(maks+min)/2;
merge(array,min,mid);
merge(array,mid+1,maks);

urutan(array,min,maks,mid);

}
}

void rando (int*array)
{
for(int loop=0;loop<10;loop++)
    array[loop]=rand()%(100)+1;
}
