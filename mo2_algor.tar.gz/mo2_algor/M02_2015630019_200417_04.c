/*
* M02_2015630019_200417_04.c
* PASCALIS APRIYATNA 2015630019
* 20 April 2017
*/

#include <stdio.h>

int main()
{
    int n, random,i,array[50];

    printf("Masukan BAnyak Angka Acak :");
    scanf("%d", &n);

    srand(time(NULL));
    for(i=0 ; i<=n ; i++)
    {
        random=rand()%(27)+1;
        array[i]=random;
        }

    printf("Angka Sebelum disort :\n");
    for(i=1 ;i<=n ; i++)
    {
        printf("%d",array[i]);

        }
        printf("\n");

        printf("Angka Setelah disort :");
        bubble_sort(array[50],n);
        for(i=0 ; i<n-1 ; i++)
        {
            printf("%d",array[i]);
            }

        return 0;

    }


    void bubble_sort(int a[],int n)
    {
        int i,j,temp;
        for(i=0 ; i<n-1 ; i++)
        {
             for(j=0 ; j<n-1 ; j++)
             {
                if(a[j]>a[j+1])
                {
                    temp=a[j];
                    a[j]=a[j+1];
                    a[j+1]=temp;
                    }
                 }
            }


            return 0;
        }
