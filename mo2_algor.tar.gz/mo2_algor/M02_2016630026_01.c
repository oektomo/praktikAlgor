#include<stdio.h>
#include<stdlib.h>
int acak(int place[100], int stop);

int main(){

int x,temr, batas, array[100], left, right, tuker;

printf("masukkan batas :");
scanf("%d", &batas);

acak(array, batas);

if(batas!=1){

for(x=1;x<=batas;x++)
{
for(left=1;left<=batas;left++)
    {
    for(right=batas;right>=1;right--)
    {
    if(array[right]<array[right-1])
        {
        tuker=array[right];
        array[right]=array[right-1];
        array[right-1]=tuker;
        }
    if(array[left]>array[left+1])
        {
        tuker=array[left];
        array[left]=array[left+1];
        array[left+1]=tuker;
        }
    }
    }
}
printf("\n\n");
for(x=1;x<=batas;x++)
    {
    printf(" %d", array[x]);
    }
}
}



int acak(int place[100], int stop)
{
int tems, x;
for(x=1;x<=stop;x++)
{
tems=rand()%(50);
place[x]=tems;
printf(" %d", place[x]);
}
}
