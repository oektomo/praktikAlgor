#include <stdio.h>

int main (){
 int n,i,random,array[41];

 printf("masukkan banyaknya angka :");
 scanf("%d", &n);

   rand(time(NULL));
   for(i=0;i<=n;i++){
   random = rand()%27+1;
   array[i] = random;
   }

  printf("angka sebelum di sort:\n");
  for(i=0;i<=n;i++){
  printf("%d\n",array[i]);
  }
  printf("\n");

  printf("setelah di sort:");
  bubble_sort(array[41],n);
  for(i=0;i<n-1;i++){
  printf("\n%d",array[i]);
  }
return 0;
}

void bubble_sort(int a[],int n){
 int i;
 int j;
 int temp;
 for(i=0;i<n-1;i++){
 for(j=0;j<n-i-1;j++){
  if(a[j]>a[j+1]){
  temp=a[j];
  a[j]=a[j+1];
  a[j+1]=temp;
  }
 }
}

}
