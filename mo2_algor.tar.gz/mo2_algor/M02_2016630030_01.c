/*
*   M02_2016630030_01.c
*
*   Created on  : Mar 20, 2017
*   Author      : Raymond Christian - 2016630030
*
*   @file M02_2016630030_01.c
*   @author Raymond Christian - 2016630030
*   @brief deskripsi program
*/
#include<stdio.h>
#include<stdlib.h>

//prototype
void tuker(int* larik,int x,int y);
void quicksort(int* larik,int min,int maks);
int penunjuk(int* larik, int maks,int min);
void randomm(int* larik);

int main(void)
{
    int larik[10],x;

    randomm(larik);

    printf("\t\t===Quick Sort===\n");

    printf("Sebelum sort: ");   //menampilkan data sebelum sort
    for(x=0;x<10;x++)
        printf("%d ",larik[x]);

    quicksort(larik,0,9);

    printf("\nSesudah sort: "); //menampilkan data setelah sort
    for(x=0;x<10;x++)
        printf("%d ",larik[x]);

    return 0;
}

void randomm(int* larik)
{
    for(int x=0;x<10;x++)       //mengisi larik dengan data acak dengan rentang 1-100
        larik[x]=rand()%(100)+1;
}

void tuker(int* larik,int x,int y)
{
    int hai=larik[x];   //menukar isi larik x dengan isi larik y
    larik[x]=larik[y];
    larik[y]=hai;
}

void quicksort(int* larik,int min,int maks)
{
    if(maks-min>0)
    {
        int pp=penunjuk(larik,maks,min);
        quicksort(larik,min,pp-1);  //memisahkan data jadi 2 bagian(bagian kiri)
        quicksort(larik,pp+1,maks); //memisahkan data jadi 2 bagian(bagian kanan)
    }
}

int penunjuk(int* larik, int maks,int min)
{
    int pivot=larik[maks];
    int kanan=maks;
    int kiri=min;

    while(1)
    {       //data dibandingkan dengan pivot, yang memenuhi kondisi disimpan dan ditukar
        while(larik[kiri]<pivot)
            kiri++;
        while(kanan>0&&larik[kanan]>=pivot)
            kanan--;
        if(kiri>=kanan)
            break;
        else
            tuker(larik,kiri,kanan);
    }
    tuker(larik,kiri,maks);

    return kiri;
}
