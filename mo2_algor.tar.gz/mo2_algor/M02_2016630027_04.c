#include <stdio.h>
#include <stdlib.h>

void f(int * a);
void b(int * a, int x,int y);
void c(int * a);

int main (void){

    int z, a[10];
    f(a);

    printf("\nInput Data Sort: ");

    for(int z=0;z<10;z++)
    printf("%d", a[z]);

    c(a);

    printf("\noutput data sort: ");

    for(int z=0;z<10;z++)
        printf("%d", a[z]);

    return 0;
    }

    void f(int* a){
        for(int z=0;z<10;z++)
        a[z]=rand()%(27)+1;
        }

        void b(int* a, int x, int y){
            int ag;
            ag=a[x];
            a[x]=a[y];
            a[y]=ag;
        }
        void c(int* a){
            for (int z=0;z<10;z++)
            for(int i=0;i<9-z;i++)
            if(a[i]>a[i+1])
            b(a,i,i+1);
            }
