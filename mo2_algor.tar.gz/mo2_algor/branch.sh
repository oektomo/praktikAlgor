for num in {1..9}
do 
echo "git branch 20166300$num"
git branch 201663000$num
done


for num in {10..46}
do 
echo "git branch 20166300$num"
git branch 20166300$num
done


