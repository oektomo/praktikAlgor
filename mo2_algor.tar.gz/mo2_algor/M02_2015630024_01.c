/*
Algoritma
*/

#include<stdio.h>
#include<time.h>


int L(int a[], int kiri, int kanan)
{
int x = kiri;
int y = kanan;
int temp;
int p = a[(kiri + kanan)/2];

while (x<=y){
while (a[x]<p)x++;
while (a[y]>p)y--;

if(x<=y){
temp=a[x];
a[x]=a[y];
a[y]=temp;
x++;
y--;

}
}

if (kiri<y) L(a, kiri, y);
if(x<kanan) L(a, x, kanan);
}

int main()
{
int n, i, random, array[100], angka;
printf("masukkan banyak nilai random : ");
scanf("%d", &n);

srand(time(NULL));
for(i=0;i<n;i++){
random=rand()%30+1;
array[i]=random;
printf("Angka ke-%d : %d \n", i+1, array[i]);

}

printf("Angka sebelum di sort : \n");
for(i=0;i<n;i++){
printf("%d", array[i]);
}

printf("\n");
L(array, 0, n-1);
printf("Setelah disortir : \n");
for(i=0;i<n;i++){
printf("%d", array[i]);
}

return 0;
}

