/*
* M02_2015630019_200417_03.c
* PASCALIS APRIYATNA 2015630019
* 20 April 2017
*/

#include <stdio.h>

void mergeSort(int [],int,int,int);
void partition(int[],int,int);

int main()
{
    int list[80];
    int i, size ;

    printf("Masukan Jumlah Angka  :");
    scanf("%d",&size);
    printf("Masukan Angka yang Diinginkan :\n");
    for(i=0 ; i < size ; i++)
    {
        scanf("%d", &list[i]);

        }

    partition(list,0,size-1);
    printf("Setelah marge sort :\n");
    for(i=0 ; i < size ; i++)
    {
        printf("%d", list[i]);

        }
    return 0;
}

void partition(int list[],int low,int high)
{
    int mid;
    if(low<high)
    {
      mid = (low+high)/2;
      partition(list,low,mid);
      partition(list,mid+1,high);
      mergeSort(list,low,mid,high);

        }
    }

    void mergeSort(int list[], int low, int mid, int high)
    {
        int i,mi,k,lo,temp[80];

        lo=low;
        i=low;
        mi= mid+1;

        while((lo<=mid)&&(mi <= high))
        {
            if (list[lo] <= list[mi])
            {
                temp[i]= list[lo];
                lo++;
                }
                else
                {
                    temp[i]=list[mi];
                    mi++;
                    }
                    i++;
            }
            if(lo>mid)
            {
                for(k=mi ;k<=high;k++)
                {
                    temp[i]=list[k];
                    i++;
                    }
                }
                else
                {
                    for(k=lo ;k<=mid;k++)
                    {
                        temp[i]=list[k];
                    i++;
                        }
                    }
              for(k=low ;k<=high;k++)
              {
                list[k]=temp[k];

                  }

            return 0;
        }
