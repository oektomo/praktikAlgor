#include <stdio.h>
#include <stdlib.h>

void fpx(int * lung);
void lapak(int * lung,int x, int y);
void merona(int * lung);

int main(void)
{
    int z,lung[10];
    fpx(lung);

    printf("input data sort : ");

    for(int z=0;z<10;z++)
        printf("%d ", lung[z]);

        merona(lung);

    printf("\noutput data sort : ");

    for(int z=0;z<10;z++)
        printf("%d ", lung[z]);

return 0;
}

void fpx(int* lung){
    for(int z=0;z<10;z++)
    lung[z]=rand()%(27)+1;
}

        void lapak(int* lung,int x,int y){
            int aug;
            aug=lung[x];
            lung[x]=lung[y];
            lung[y]=aug;
        }
            void merona(int* lung){
                for(int z=0;z<10;z++)
                for(int i=0;i<9-z;i++)
                if(lung[i]>lung[i+1])
                lapak(lung,i,i+1);
            }
