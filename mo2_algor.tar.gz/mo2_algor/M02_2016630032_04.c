#include <stdio.h>
void bubble(int *pointer, int panjang);
int main()
{
    int jum, dat[100], counter, cek=0, angka;

    printf("Masukkan Jumlah Input : ");
    scanf("%d", &jum);
    for(counter=0;counter<jum;counter++)
    {
    angka=rand() %(27)+1;
    dat[counter]=angka;
    printf("Nilai Random [%d]: %d\n", counter, dat[counter]);
    }
    bubble(dat,jum-1);
    for(counter=0; counter<jum; counter++)
    printf("Nilai Sorted : %d\n", dat[counter]);


}

void bubble(int *pointer, int panjang)
{
int counter1, counter2, counter;
int locker;
    for(counter1=0;counter1<panjang;counter1++)
    {
        for(counter2=0;counter2<panjang-counter1;counter2++)
        {
            if(*(pointer+counter2)>*(pointer+counter2+1))
            {
            locker=*(pointer+counter2);
            *(pointer+counter2)=*(pointer+counter2+1);
            *(pointer+counter2+1)=locker;
            }
        }
    }

}
