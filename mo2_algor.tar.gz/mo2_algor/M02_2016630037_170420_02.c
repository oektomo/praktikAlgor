#include<stdio.h>

void mergesort(int[],int,int,int);
void partition(int[],int,int);

int main()

{

int pilih[50];
int x,y;

printf("masukkan jumlah angka: ");
scanf("%d",&y);

printf("masukkan angka:");
for(x=0;x<y;x++)

{
scanf("%d",&pilih[x]);
}

partisi(pilih,0,y-1);
printf("steleah merge sort: ");

for(x=0;x<y;x++)
{
printf("%d",pilih[x]);
}
return 0;
}


void partisi(int pilih[],int kecil,int besar)
{
int tengah;
if(kecil<besar)
{
tengah=(kecil+besar)/2;
partisi(pilih,kecil,tengah);
partisi(pilih,tengah+1,besar);
merge(pilih,kecil,tengah,besar);

}
}

void merge(int pilih[],int kecil,int besar,int tengah)
{
int re,be,te,i,temp[50];

re = kecil;
i = kecil;
te = tengah + 1;
while((re<=tengah) && (te <= besar))
{

if(pilih[re]<= pilih[te])
{
temp[i] = pilih[re];
re++;
}
else
{
temp[i] = pilih[te];
te++;
}
i++;
}

if(re>tengah)
{
for(be=te;be<=besar;be++)
{
temp[i] = pilih[be];
i++;
}
}
else
{
for(be=re;be<=tengah;be++)
{
 temp[i]=pilih[be];
 i++;

}
}
for(be = kecil;be<=besar;be++)
{
 pilih[be]= temp[be];

}
}
