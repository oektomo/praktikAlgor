/**
*   M02_2016630036_04.c
*
*   Created On: 04 20, 2017
*   Author    : Muhammad Zaki Gandara-2016630036
*
*   @file M02_2016630036_04.c
*   @author Muhammad Zaki Gandara-2016630036
*   @brief Sorting
**/
#include<stdio.h>
#include<stdlib.h>
void rando (int *array);
void swap (int *array, int a, int b);
void bubble (int *array);

int main (){
    int array[100], z;
    rando(array);

    printf("Sebelum di Sorting: \n");
    for (z=0;z<15;z++){
        printf("%d ", array[z]);
    }

    bubble(array);

    printf("Setelah di sorting: \n");
    for (z=0;z<15;z++){
    printf("%d ", array[z]);

    }




return 0;
}


void rando (int *array){
    int z;
    for (z=0;z<15;z++)
        array[z] = rand()%(30)+1;
}

void swap (int *array, int a, int b){
    int temp;
    temp = array[a];
    array[a] = array[b];
    array[b] = temp;

}


void bubble (int *array){
    int c,d;
    for (c = 0;c<15;c++)
        for (d = 0;d<14;d++)
            if (array[d] > array[d+1])
                swap(array,d,d+1);
}
