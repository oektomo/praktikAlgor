#include <stdio.h>

int maion(){

   int n, random, i array[41];

   printf("masukkan banyaknya angka random : ");
   scanf("%d", &n);

   srand(time(NULL));
   for (i=1;i<=n;i++){
     random = rand() %(27)+1;
     array[i] = random;

   }

   printf("angka sebelum di sort :\n ");
   for (i=1;i<=n;i++){
      printf("%d", array[i]);

   }
   printf("\n");
}
