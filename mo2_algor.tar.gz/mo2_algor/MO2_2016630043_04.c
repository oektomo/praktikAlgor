#include <stdio.h>
#include <stdlib.h>

void rando(int* larik);
void tuker(int* larik,int a , int b);
void gelembung(int* larik);

int main(){
int x , larik[10];
rando(larik);
printf("Sebelum sort :");
for(int x=0;x<10;x++)
printf("%d " , larik[x]);
gelembung(larik);

printf("\n Sesudah sort:");
for(int x=0;x<10;x++)
printf("%d " , larik[x]);
return 0;
}

void rando(int* larik){
for(int x=0;x<10;x++)
larik[x]=rand()%(27)+1;
}

void tuker(int* larik,int a ,int b){
int hai;
hai=larik[a];
larik[a]=larik[b];
larik[b]=hai;
}
void gelembung(int* larik){
for(int x=0;x<10;x++)
for(int y=0;y<9-x;y++)
if(larik[y]>larik[y+1])
tuker(larik,y,y+1);
}
