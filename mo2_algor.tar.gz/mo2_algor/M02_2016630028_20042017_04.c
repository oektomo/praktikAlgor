/*
*       M02_2016630028_04.c
*
*       Created on : mar 20, 2017
*       Author     : Yoshua Ibrahim -2016630028
*
*       @file M02_2016630028_04.c
*       @author  Yoshua Ibrahim -2016630028
*       @brief deskripsi program
*/

#include <stdio.h>

 int main()
 {
      int m, random,i,array[60];

      printf("input total random :");
      scanf("%d" ,&m);

         srand(time(NULL));
         for(i=1;  i<m; i++);
         {
         random= rand()%(20)+1;
         array [i]=random;
         }

         printf("Angka sebelum sort:\n");
         for (i=1;  i<m; i++){
         printf("%d ", array[i]);
         }
         printf("\n");
         printf("angka sesudah sort:\n");
         bubble_sort(array[60],m);
         for (i=1;  i<m; i++){
         printf("%d",array[i]);
         }

         return 0;

 }
void bubble_sort(int a[],int n){
int i;
int j;
int temp;
for(i=1;  i<n; i++){
for (j=0;j<n-i-1;j++){
   if (a[j]>a[j+1]){
   temp =a[j];
   a[j]= a[j+1];
   a[j+1]= temp;

   }

}
}


}
