perbedaan antara merge sort dan quick sort :
merge sort
algoritma yang dijalankan sebagai akibat dari terlalu banyaknya daftar yang diurutkan, dengan menghasilkan lebih banyak daftar yang diurutkan sebagai output. sedangkan
quick sort
merupakan sorting pembanding dan pada implementasi efisien tidak merupakan algoritma sorting yang stabil.
