/*
*       M02_2016630033_170420_01.c
*
*       Created on      :   Mar 20, 2017
*       Author          :   Reyvaldo Barthez-2016630033
*
*       @file       M02_2016630033_170420_01.c
*       @author     Reyvaldo Barthez-2016630033
*       @brief      Deskripsi program
*/

#include <stdio.h>
#include <time.h>

int quick_j(int j[], int kiri, int kanan)
{
    int a = kiri;
    int b = kanan;
    int temp;
    int pivot = j[(kiri+kanan)/2];

    while (a <= b)
    {
        while (j[a] < pivot)a++;
        while (j[b] > pivot)b--;
        if (a<=b)
        {
        temp = j[a];
        j[a] = j[b];
        j[b] = temp;
        a++;
        b--;
        }
    }

    if(kiri < b)    quick_j(j,kiri,b);
    if(a < kanan)    quick_j(j,a, kanan);

}
int main()
{
    int data, i, random, array[100], angka;

    printf("masukkan jumlah data :");
        scanf("%d", &data);

        rand(time(NULL));
        for(i=0; i < data; i++)
        {
        random = rand()%30+1;
        array[i] = random;
        printf("angka ke-%d: %d \n", i+1,array[i]);
        }

        printf("angka sebelum di sort:\n");
        for(i=0; i < data; i++)
        {
        printf("%d\n", array[i]);
        }

        printf("\n");
        quick_j(array,0,data-1);
        printf("setelah di sort:\n");
        for(i=0; i < data; i++)
        {
        printf("%d\n", array[i]);
        }
}

