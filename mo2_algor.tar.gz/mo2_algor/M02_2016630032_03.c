#include <stdio.h>

int main()
{
    int array[100], jum, counter;
    printf("Masukkan Jumlah Input : ");
    scanf("%d", &jum);

    for(counter=0;counter<jum;counter++)
    {
    printf("Masukkan Input %d : ", counter);
    scanf("%d", &array[counter]);
    }

    for(counter=0;counter<jum;counter++)
    {
    printf("Masukkan Input %d : %d\n", counter, array[counter]);
    }

}

void merge(int *A, int *L, int Ki, int *R, int Ka)
{
    int i,j,k;
    i=j=k=0;

    while(i<Ki && j<Ka)
    {
        if(L[i]<R[j]) A[k++] = L[i++];
        else A[k++] = R[j++];
    }
    while(i<Ki) A[k++] = L[i++];
    while(j<Ka) A[k++] = R[j++];
}
