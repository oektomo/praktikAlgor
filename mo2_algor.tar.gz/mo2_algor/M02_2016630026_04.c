#include<stdio.h>
#include<stdlib.h>
int batas;

int bub(int place[100]);

int main(){

    int x, tems, array[100], y, tuker, b;

    printf("masukkan batas :");
    scanf("%d", &batas);

    for(x=1;x<=batas;x++)
        {
        tems=rand() %(27);
        array[x]=tems;
        printf(" %d", array[x]);
        }
bub(array);

printf("\n");
for(x=1;x<=batas;x++)
    {
    printf(" %d", array[x]);
    }

}



int bub(int arrays[100])
{int b, y, tuker;
for(b=1;b<=batas;b++)
    {
    for(y=1;y<=batas-1;y++)
    {
    if(arrays[y]>arrays[y+1])
    {
    tuker=arrays[y];
    arrays[y]=arrays[y+1];
    arrays[y+1]=tuker;
    }
    }
}
}
