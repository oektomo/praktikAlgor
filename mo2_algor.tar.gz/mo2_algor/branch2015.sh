for num in {1..9}
do 
echo "git branch 20156300$num"
git branch 201563000$num
done


for num in {10..46}
do 
echo "git branch 20156300$num"
git branch 20156300$num
done
