for num in {1..9}
do 
echo "git push lab 20166300$num"
git push lab 201663000$num
done


for num in {10..46}
do 
echo "git push lab 20166300$num"
git push lab 20166300$num
done
