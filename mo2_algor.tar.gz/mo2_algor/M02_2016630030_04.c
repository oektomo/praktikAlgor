/*
*   M02_2016630030_04.c
*
*   Created on  : Mar 20, 2017
*   Author      : Raymond Christian - 2016630030
*
*   @file M02_2016630030_04.c
*   @author Raymond Christian - 2016630030
*   @brief deskripsi program
*/
#include<stdio.h>
#include<stdlib.h>

//prototype
void randomm(int* larik);
void gelembung(int* larik);
void tuker(int* larik,int x,int y);

int main(void)
{
    int larik[10],x;

    randomm(larik);

    printf("\t\t===Bubble Sort===\n");

    printf("Sebelum sort: ");   //menampilkan data sebelum sort
    for(x=0;x<10;x++)
        printf("%d ",larik[x]);

    gelembung(larik);

    printf("\nSesudah sort: "); //menampilkan data sesudah sort
    for(x=0;x<10;x++)
        printf("%d ",larik[x]);

    return 0;
}

void randomm(int* larik)
{
    for(int x=0;x<10;x++)           //fungsi untuk memasukan nilai acak ke larik x dengan rentang 1-27
        larik[x]=rand()%(27)+1;
}

void gelembung(int* larik)
{
    for(int x=0;x<10;x++)       //fungsi untuk algoritma bubble sort
        for(int y=0;y<9-x;y++)
            if(larik[y]>larik[y+1])
                tuker(larik,y+1,y);
}
void tuker(int* larik,int x,int y)
{
    int hai=larik[x]; //untuk menukar data di larik x dan larik y
    larik[x]=larik[y];
    larik[y]=hai;
}
