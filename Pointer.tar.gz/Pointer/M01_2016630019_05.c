#include<stdio.h>

int main()
{
int pel, i,matkul, rata,array[50];

printf("Masukan Jumlah Mata Kuliah  :   ");
scanf("%d",&matkul);

for (i = 0;i<=matkul;i++)
{
printf("masukkan matkul ke-%d : ", i);
scanf("%d", array[i]);
}
rata=(rata + array[i])/matkul;




}
