#include <stdio.h>

int main()
{
	printf("Hello World\n");
	printf("coba git\n");
	return 0;
}
