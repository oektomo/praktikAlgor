#include <stdio.h> // header input output
#include <math.h> // header untuk operasi matematika
#define phi 3.14 // deklarasi global phi=3.14

int main () // main execution
{
    int sudut; // int state declaration
    float luas,sudutt,jari2; // float state declaration

    printf ("masukan jari-jari = \t "); // output to screen
    scanf ("%d", &jari2); // input from keyboard

    printf ("masukan sudut = \t "); // output to screen
    scanf ("%d", &sudut); // input from keyboard

    printf ("\n"); // \n untuk new line

    printf ("luas lingkaran = %f \n", &luas); // output luas
    printf("luas juring lingkaran = %f", &sudutt); // output luas juring

    return 0; // return value
}

float luas(*jari2)
{
return luas=3.14*jari2*jari;
}
float sudutt(*sudutt)
{
return sudut=sudutt/360*phi*pow(2,jari2);
}
