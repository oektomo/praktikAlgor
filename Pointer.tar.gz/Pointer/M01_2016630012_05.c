#include<stdio.h>

int main()
{
    int a,b,c;
    char d;

    printf("Nama Mahasiswa\t\t: ");
    scanf("%s",&d);
    printf("Banyak mata kuliaht\t: n\n");
    printf("Nilai ke-n mahasiswa\t: ");
    scanf("%d",&a);


}
