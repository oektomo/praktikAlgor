#include <stdio.h>


int main()
{
    int* a;
    int* b;
    int c,d;

    printf("Input 1 (Angka/Huruf)\t: ");
    scanf("%d",&a);
    printf("Input 2 (Angka/Huruf)\t: ");
    scanf("%d",&b);

    printf("\nIsi dari input 1 adalah %d dan input 2 adalah %d (Sebelum swap)\n",a,b);

}

