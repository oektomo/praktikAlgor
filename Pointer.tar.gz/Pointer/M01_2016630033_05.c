#include <stdio.h>

int main()

{
    int NM[100], MK, NR, P;

    printf("Masukkan nama mahasiswa     :");
    scanf("%c", &NM[100]);
    printf("Masukkan banyaknya mata kuliah     :");
    scanf("%d", &MK);

    for(P=0; P<MK; P++)
    {
        printf("Masukkan nilai mata kuliah ke-%d    :", P);
        scanf("%d", array)
    }

}
