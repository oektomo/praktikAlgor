#include<stdio.h>




int main()
{ char a,s,d,f;

printf("input 1(angka/huruf) : ");
scanf("%s",&a);

printf("\ninput 2(angka/huruf) : ");
scanf("%s",&s);

printf("isi input 1 adalah %c dan input 2 adalah %c",a,s);
printf("\nisi dari input 1 adalah %c dan input 2 adalah %c",);
printf("\nisi dari input 1 adalah %c dan input 2 adalah %c",);

return 0;
}
