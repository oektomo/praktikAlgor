#!/bin/bash
        for i in `seq 1 9`;
        do
                git checkout 201663000$i
		git pull --all
        done 

        for i in `seq 10 45`;
        do
                git checkout 20166300$i
		git pull --all
        done 

	git checkout master

	./merging.sh
