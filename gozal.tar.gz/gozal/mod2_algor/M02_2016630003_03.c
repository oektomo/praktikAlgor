//No.3

#include <stdio.h>
#include <stdlib.h>

void urutan(int* larik, int minn,int maks, int mid){
    int q,w,e,r[10];

    for(q=minn,w=mid+1,e=minn;q<=mid&&w<=maks;e++);
        if(larik[q]<larik[w])
            larik[e]=larik[q++];
        else
            larik[e]=larik[w++];

    while(q<=mid)
        r[e++]=larik[q++];
    while(w<=maks)
        r[e++]=larik[w++];

    for(e=minn;e<=maks;e++)
        larik[e]=r[e];
}

void mergesort(int*larik, int minn, int maks){
    if(maks-minn>0)
    {
        int tengah=(maks+minn)/2;
        mergesort(larik,minn,tengah);
        mergesort(larik,tengah+1,maks);

        urutan(larik,minn,maks,tengah);
    }
}

void jeremy(int* larik){
    for(int x=0;x<10;x++)
    larik[x]=rand()%(100)+1;
}

int main(){

     int x, larik[10];

    jeremy(larik);

    printf("Sebelum sort: ");
        for(x=0;x<10;x++){
            printf("%d ", larik[x]);
        }

    mergesort(larik,0,9);

    printf("\nSesudah sort: ");
        for(x=0;x<10;x++){
            printf("%d ", larik[x]);
        }

    return 0;
}
