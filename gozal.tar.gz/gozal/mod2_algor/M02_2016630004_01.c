// no 1
#include <stdio.h>
#include <stdlib.h>

void fungsiqs(int *array, int min, int max);
void fungsitukar(int *array, int a, int b);
void fungsi(int* array);
int partion(int* array, int maks, int min);


int main(void)
{

int array[10], i;

fungsi(array);


printf("sebelum quicksort : ");
for(i=0; i<10; i++)
    printf("\n%d", array[i]);


fungsiqs(array, 0, 9);


printf("\n\nsesudah quicksort : ");
for(i=0; i<10; i++)
printf("\n%d", array[i]);

",
return 0;
}

void fungsiqs(int* array, int min, int max)
{
    if(max-min>0)
    {
    int pp=partion(array, max, min);
    fungsiqs(array, min, pp-1);
    fungsiqs(array,max,pp+1);
    }
}

void fungsi(int* array)
{
    int i;
    for(i=0; i<10; i++)
    array[i]=rand()%(100)+1;
}

void tukar(int* array, int a, int b)
{
    int swap;
    swap=array[a];
    array[a]=array[b];
    array[b]=swap;
}


int partion(int* array, int max, int min)
{
    int pivot=array[max];
    int kanan=max;
    int kiri=min;

    while(1)
    {
    while(array[kiri]<pivot)
        kiri++;

    while(kanan>0 && array[kanan]>=pivot)
        kanan--;

    if (kiri>=kanan)
        break;

    else
    tukar(array, kiri, kanan);
    }
    tukar (array, kiri, max);
    return kiri;
}
