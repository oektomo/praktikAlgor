#!/bin/bash
        for i in `seq 1 9`;
        do
                git branch 201663000$i
        done 

        for i in `seq 10 45`;
        do
                git branch 20166300$i
        done 

	git push --all
	
