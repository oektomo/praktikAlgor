#include<stdio.h>
#include<stdlib.h>

int array[10];

//fungsi bubble sort
int bubble (int n)
{
    int i, j, array[10], tukar;
    printf (" Angka Random : \n");
    for (i=0; i<n; i++)
    {
        array[i] = rand()%(100)+1;
        printf (" %d", array[i]);
    }

    printf ("\n\n");

    for (i=0; i<n; i++)
    {
        for (j=0; j<n-1; j++)
        {
            if (array[j]>array[j+1])
            {
                tukar = array[j];
                array[j] = array[j+1];
                array[j+1] = tukar;
            }
        }
    }

    //print setelah bubble sort
    printf (" Setelah Bubble Sort : \n");
    for (i=0; i<n; i++)
        printf (" %d", array[i]);
    printf ("\n\n");
}

int main()
{
    int n;

    printf (" BUBBLE SORT\n\n");

    //input jumlah data
    printf (" Masukkan Jumlah Data (Max 10) : ");
    scanf ("%d", &n);
    printf ("\n");

    bubble (n);

return 0;
}



