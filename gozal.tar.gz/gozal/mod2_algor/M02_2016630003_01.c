//No.1

#include <stdio.h>
#include <stdlib.h>

void quicksort(int *larik, int min, int maks);
void tuker(int *larik, int a, int b);
int partion(int *larik, int maks, int min);
void jeremy(int* larik){
for(int x=0;x<10;x++)
    larik[x]=rand()%(100)+1;
}

int main (void)
{
    int x, larik[10];

    jeremy(larik);

    printf("Sebelum sort: ");
        for(x=0;x<10;x++){
            printf("%d ", larik[x]);
        }

    quicksort(larik,0,9);

    printf("\nSesudah sort: ");
        for(x=0;x<10;x++){
            printf("%d ", larik[x]);
        }

    return 0;
}

void quicksort(int *larik, int min, int maks){
    if(maks-min>0){
        int pp=partion(larik,maks,min);
        quicksort(larik,min,pp-1);
        quicksort(larik,pp+1,maks);
    }
}

int partion(int* larik, int maks, int min){
    int pivot=larik[maks];
    int kanan=maks;
    int kiri=min;

    while(1){
        while (larik[kiri]<pivot)
            kiri++;
        while (kanan>0&&larik[kanan]>=pivot)
            kanan--;
        if(kiri>=kanan)
            break;
        else
            tuker(larik,kiri,kanan);
    }
    tuker(larik,kiri,maks);
    return kiri;
}

void tuker(int* larik,int a, int b){
    int q;

    q=larik[a];
    larik[a]=larik[b];
    larik[b]=q;
}

