#include <stdio.h>
#include <stdlib.h>
void quicksort(int a[], int rendah, int tinggi){
int i=rendah,j=tinggi,h;
int z=a[rendah];
do{
while (a[i]<z)i++;
while (a[j]>z)j--;
if(i<=j)
{
h=a[i];a[i]=a[j];a[j]=h;//tukar
i++,j--;
}
}while(i<=j);
//pengurutan
if(rendah<j)quicksort(a,rendah,j);
if(i<tinggi)quicksort(a,i,tinggi);
}

main(){
int data[10]={1,4,6,8,2,9,3,6,7,3};
int i,n=10;
for(i=0;i<n;i++){
printf("%d",data[i]);
}
printf("\n");
quicksort(data,0,n-1);
for(i=0;i<n;i++){
printf("%d",data[i]);
}
}
