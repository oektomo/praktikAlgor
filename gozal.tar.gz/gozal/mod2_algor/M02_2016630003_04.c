//No.4

#include <stdio.h>
#include <stdlib.h>

void jeremy(int* array){
for(int x=0;x<15;x++)
    array[x]=rand()%(27)-1;
}

void bubble(int* array){
    for(int v=0;v<15;v++){
        for(int s=0;s<14-v;s++){
            if(array[s]>array[s+1]){
                int q;
                q=array[s];
                array[s]=array[s+1];
                array[s+1]=q;
            }
        }
    }
}

int main (void)
{
    int x, array[15];

    jeremy(array);

    printf("Sebelum sort: ");
        for(x=0;x<15;x++){
            printf("%d ", array[x]);
        }

    bubble(array);

    printf("\nSesudah sort: ");
        for(x=0;x<15;x++){
            printf("%d ", array[x]);
        }

    return 0;
}
