#include<stdio.h>
#define max 10

int a[11], b[10];


//fungsi merge
void merge (int rendah, int tengah, int tinggi)
{
    int l1, l2, i;

    for (l1=rendah, l2=tengah+1, i=rendah; l1<=tengah && l2<=tinggi; i++)
    {
        if (a[l1]<=a[l2])
            b[i] = a[l1++];
        else
            b[i] = a[l2++];
    }

    while (l1<=tengah)
        b[i++] = a[l1++];

    while (l2<=tinggi)
        b[i++] = a[l2++];

    for (i=rendah; i<=tinggi; i++)
        a[i] = b[i];

}

//fungsi sort
void *sort (int rendah, int tinggi)
{
    int tengah;

    if (rendah<tinggi)
    {
        tengah = (rendah + tinggi) / 2;
        sort (rendah, tengah);
        sort (tengah+1, tinggi);
        merge (rendah, tengah, tinggi);
    }

    else
        return;
}

int main()
{
    int n, i;

    printf (" MERGE SORT\n\n");

    //input jumlah data
    printf (" Masukkan Jumlah Data (Max 10) : ");
    scanf ("%d", &n);
    printf ("\n");

    //loop input data
    for (i=0; i<n; i++)
    {
        printf (" Data Ke-%d : ", i+1);
        scanf ("%d", &a[i]);
    }

    printf ("\n\n");

    //loop print array sebelum merge sort
    printf (" Sebelum Merge Sort : \n");
    for (i=0; i<n; i++)
        printf (" %d", a[i]);

    //menggunakan fungsi sort
    *sort (0, n);

    printf ("\n\n");

    //loop print array setelah merge sort
    printf (" Setelah Merge Sort : \n");
    for (i=0; i<n; i++)
        printf (" %d", a[i+1]);

    printf ("\n\n");

return 0;
}



