//no 3
#include <stdio.h>
#include <stdlib.h>

void urut(int* array, int min, int max, int tengah);
void mergesort(int* array, int min, int max);
void fungsirandom (int* array);




int main()
{
int i, array[10];

fungsirandom(array);

printf("sebelum mergesort : \n");
for(i=0; i<10; i++)
printf("%d\n", array[i]);

mergesort(array, 0, 9);

printf("\n\nsesudah mergesort: \n");
for(i=0; i<10; i++)
printf("%d\n", array[i]);

return 0;
}



void urut(int* array, int min, int max, int tengah)
{
    int a, b, c, d[10];

    for(a=min, b=tengah+1, c=min; a<=tengah && b<=max; c++)
        if(array[a]<array[b])
        d[c]=array[a++];

        else
        d[c]=array[b++];

    while(a<=tengah)
        d[c++]=array[a++];
    while(b<=max)
        d[c++]=array[b++];

    for(c=min; c<=max; c++)
        array[c]=d[c];
}


void mergesort(int* array, int min, int max)
{
    if(max-min>0)
    {
    int mid=(max+min)/2;
    mergesort(array, min, mid);
    mergesort(array, mid+1, max);

    urut(array, min, max, mid);
    }
}

void fungsirandom(int* array)
{
    for(int i=0; i<10; i++)
    array[i]=rand()%(100)+1;
}
