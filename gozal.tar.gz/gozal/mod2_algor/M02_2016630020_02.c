#include<stdio.h>
#define max 10
int data[max];
int temp[max];

void merge(int data[],int temp[],int kiri,int tengah,int kanan)
{
int i,l,bilangan,k;
l=tengah-1;
k=kiri;
bilangan=kanan-kiri+1;
while((kiri<=l)&&(tengah<=kanan)){
if(data[kiri]<=data[tengah])
{
temp[k]=data[kiri];
k=k +1;
kiri=kiri+1;

}
else
{
temp[k]=data[tengah];
k=k+1;
tengah=tengah+1;
}
}
while(kiri<=l){
temp[k]=data[kiri];
kiri=kiri+1;
k=k+1;
}
while (tengah<=kanan)
{
temp[k]=data[tengah];
tengah=tengah+1;
k=k+1;
}
for(i=0;i<bilangan;i++)
{
data[kanan]=temp[kanan];
kanan=kanan-1;
}
}
void m_sort(int data[],int temp[], int kiri, int kanan)
{
int tengah;
if(kanan>kiri)
{
tengah=(kanan+kiri)/2;
m_sort(data,temp,kiri,tengah);
m_sort(data,temp,tengah+1,kanan);
merge(data,temp,kiri,tengah+1,kanan);
}
}
void mergesort(int data[],int temp[],int array_s)
{
m_sort(data,temp,0,array_s-1);
}
int main()
{
int i;
printf("masukan data sebelum terurut :\n");
for(i=0;i<max;i++)
{
printf("data ke-%i : ",i+1);
scanf("%d",&data[i]);

}
mergesort(data,temp,max);
printf("\n data setelah terurut : ");
for(i=0;i<max;i++)
printf("%d ",data[i]);
printf("\n");
//scanf("%d");
return(0);
}






