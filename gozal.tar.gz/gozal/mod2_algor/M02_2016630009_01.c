#include<stdio.h>
#include<stdlib.h>

//fungsi utk sort tipe ascending
void quick_ascending(int acak[],int left,int right){
    int angka1=left;
    int angka2=right;
    int temp;
    int pivot = acak[(left+right)/2];

    while(angka1<=angka2){
        while(acak[angka1]<pivot) angka1++;
        while(acak[angka2]>pivot) angka2++;
        if(angka1<=angka2){
            temp=acak[angka1];
            acak[angka1]=acak[angka2];
            acak[angka2]=temp;
            angka1++;
            angka2++;
        }
    }
    if(left<angka2) quick_ascending(acak,left,angka2);
    if(angka1<right) quick_ascending(acak,angka1,right);
}

//fungsi untuk sort tipe descending
void quick_descending(int asal[],int left,int right){
    int angka1=left;
    int angka2=right;
    int temp;
    int pivot = asal[(left+right)/2];

    while (angka1<=angka2){
        while(asal[angka1]>pivot) angka1++;
        while(asal[angka2]<pivot) angka2++;
        if(angka1<=angka2){
            temp=asal[angka1];
            asal[angka1]=asal[angka2];
            asal[angka2]=temp;
            angka1++;
            angka2++;
        }
    }
    if(left<angka2) quick_descending(asal,left,angka2);
    if(angka1<right) quick_descending(asal,angka1,right);
}


int main()
{
    int ulang,jumlah,angka[100],pilih,cekR;
    time_t t;

    //input utk jumlah ngk random yg diinginkan
    printf("masukan jumlah angka random yang diinginkan: ");
    scanf("%d",&jumlah);

    srand((unsigned) time(&t));

    //hasil angka random
    for(ulang=0;ulang<jumlah;ulang++)
    {
        cekR=rand() %100;
        angka[ulang]=cekR;
        printf("angka random ke-%d = %d\n",ulang+1,angka[ulang]);
    }

    //pilihan jenis sorting
    printf("\n1.Ascending\t2.Descending\n");
    printf("pilih metode sorting: ");
    scanf("%d",&pilih);

    if(pilih==1)
    {
    //output sebelum di sort
    printf("sebelum sorting: \n");
    for(ulang=0;ulang<jumlah;ulang++)
    {
        printf(" %d ",angka[ulang]);
        }
    //output setelah di sort
    quick_ascending(angka,0,jumlah-1);
    printf("\n\nsetelah sorting: \n");
    for(ulang=0;ulang<jumlah;ulang++)
    {
        printf(" %d ",angka[ulang]);
        }
    }

    else if(pilih==2)
    {
    //output sebelum di sort
    printf("sebelum sorting: \n");
    for(ulang=0;ulang<jumlah;ulang++)
    {
        printf(" %d ",angka[ulang]);
        }
    //output sesudah di sort
    quick_descending(angka,0,jumlah-1);
    printf("\n\nsetelah sorting: \n");
    for(ulang=0;ulang<jumlah;ulang++)
    {
        printf(" %d ",angka[ulang]);
        }
    }

    else printf("ERROR");

    return 0;
}
