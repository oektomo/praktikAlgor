#include<stdio.h>
void bubble_sort(long[],long);
int main()
{
long array[100],n,j,d,tukar;
printf("masukan jumlah data\n");
scanf("%d",&n);
printf("masukan %ld data\n",n);
for(j=0;j<n;j++)
scanf("%ld",&array[j]);
bubble_sort(array,n);
printf("mengurutkan dari kecil ke besar:\n");
for(j=0;j<n;j++)
printf("%ld\n",array[j]);
return 0;
}
void bubble_sort(long list[], long n)
{

long j,d,t;
for(j=0;j<(n-1);j++)
{
for(d=0;d<n-j-1;d++)
{
if (list[d]>list[d+1])
{
/*tukar*/
t = list[d];
list[d]=list[d+1];
list[d+1]=t;
}
}
}
}
