#include <stdio.h>

void mergesort (int* a, int i, int j);
void merge (int* a, int i1, int j1, int i2, int j2);

int main ()
{
    int n;
    printf("Masukkan banyak bilangan: ");
    scanf("%d", &n);

    printf("\n");

    int x[n], i;
    for(i=0;i<n;i++)
    {
    printf("Masukkan bilangan ke-%d: ", i+1);
    scanf("%d", &x[i]);
    }

    mergesort(x, 0, n-1);

    printf("\nBilangan setelah diurutkan dari kecil ke besar:\n");

    for(i=0;i<n;i++)
    {
        printf("%d ", x[i]);
    }
    printf("\n");

return 0;
}

void mergesort(int* a, int i, int j)
{
    int tengah;

    if(i<j)
    {
        tengah=(i+j)/2;
        mergesort(a,i,tengah);          //putaran kiri
        mergesort(a,tengah+1,j);        //putaran kanan
        merge(a,i,tengah,tengah+1,j);   //gabung kiri-kanan

    }
}

void merge (int* a, int i1, int j1, int i2, int j2)
{
    int temp[100]; //buat tempat nyimpen sementara

    int i,j,k;

    i=i1;   //awal dari list pertama
    j=i2;   //awal dari list kedua
    k=0;

    while (i<=j1&&j<=j2)
    {
        if (a[i]<a[j])
            temp[k++]=a[i++];
        else
            temp[k++]=a[j++];
    }

    while (i<=j1)   //sisa bilangan dari list pertama
        temp[k++]=a[i++];

    while (j<=j2)   //sisa bilangan dari list kedua
        temp[k++]=a[j++];

    //kirim balik bilangan dari temp[] ke a[]
    for(i=i1,j=0 ; i<=j2 ; i++,j++)
        a[i]=temp[j];
}
