#include <stdio.h>
#include <stdlib.h>

void quicksort(int* x, int min, int maks);
void acak (int* x);

int main ()
{
    int x[10], i;

    acak(x);

    printf("Sebelum sort: ");
    for (i=0; i<10; i++)
    {
        printf("%d ", x[i]);
    }

    quicksort(x, 0, 9);

    printf("\nSesudah sort: ");
    for (i=0;i<10;i++)
    {
        printf("%d ", x[i]);
    }


return 0;
}

void quicksort(int* x, int min, int maks)
{
    int pivot, j, temp, i;

    if (min<maks)
    {
        pivot = min;
        i=min;
        j=maks;

    while(i<j)
    {
        while (x[i]<=x[pivot]&&i<maks)
        {
            i++;
        }
        while (x[j]>x[pivot])
        {
            j--;
        }
        if(i<j)
        {
            temp=x[i];
            x[i]=x[j];
            x[j]=temp;
        }
    }

    temp=x[pivot];
    x[pivot]=x[j];
    x[j]=temp;
    quicksort(x, min, j-1);
    quicksort(x,j+1, maks);
    }
}

void acak(int* x)
{
    int a;
    for (a=0;a<10;a++)
    {
        x[a]=rand()%(100)-1;
    }

}
