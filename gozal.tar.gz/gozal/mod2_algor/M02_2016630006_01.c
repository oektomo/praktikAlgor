#include<stdio.h>
#include<stdlib.h>

int array[20];

void quicksort (int array[20], int awal, int akhir)
{
    int i, j, temp, pivot;

    if (awal<akhir)
    {
        pivot = awal;
        i = awal;
        j = akhir;

        while (i<j)
        {
            while (array[i]<=array[pivot] && i<akhir)
                i++;

            while (array[j]>array[pivot])
                j--;

            if (i<j)
            {
                temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            } //akhir if


        } //akhir dari while

        temp = array[pivot];
        array[pivot] = array[j];
        array[j] = temp;
        quicksort (array, awal, j-1);
        quicksort (array, j+1, akhir);

    } //akhir dari if
} //akhir fungsi quicksort


//fungsi acak
int acak (int n)
{
    int i;

    //loop print array angka random
    for (i=0; i<n; i++)
    {
        array[i] = rand()%(100)+1;
        printf (" %d", array[i]);
    }

    printf ("\n\n");
}

int main()
{
    int n, i;

    printf (" QUICK SORT\n\n"); //judul

    //input jumlah angka
    printf (" Masukkan Jumlah Angka (Max 20) : ");
    scanf ("%d", &n);
    printf ("\n");

    printf (" Angka Random : \n");
    acak (n); //menggunakan fungsi acak

    quicksort (array, 0, n-1); //menggunakan fungsi quicksort

    printf (" Setelah Quick Sort : \n");
    //loop memprint array setelah quicksort
    for (i=0; i<n; i++)
        printf (" %d", array[i]);

    printf ("\n\n");

return 0;
}
