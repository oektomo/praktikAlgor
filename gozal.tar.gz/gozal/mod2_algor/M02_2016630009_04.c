#include<stdio.h>
#include<stdlib.h>

int asal[20];

//fungsi buble sort
int *bubble_sort(int angka1)
{
    int ulang1,ulang2,asal[20],swap;

    printf("angka random:\n");

    for (ulang1=0;ulang1<angka1;ulang1++)
    {
        asal[ulang1]=rand() %(200)+1;
        printf(" %d ",asal[ulang1]);
    }
    printf("\t");

    for (ulang1=0;ulang1<angka1;ulang1++)
    {
        for (ulang2=0;ulang2<angka1;ulang2++)
        {
            if (asal[ulang2]>asal[ulang2+1])
            {
                swap=asal[ulang2];
                asal[ulang2]=asal[ulang2+1];
                asal[ulang2+1]=swap;
            }
        }
    }
    //outut bubble sort
    printf ("\n\nsetelah bubble sort: \n");
    for (ulang1=0;ulang1<angka1;ulang1++)
        printf(" %d ",asal[ulang1]);
    printf("\t");
}

int main()
{
    int angka;

    printf ("bubble sort\n\n");
    //input jumlah data random
    printf("masukan jumlah data (max.20): ");
    scanf("%d",&angka);

    printf("\n");

    bubble_sort (angka);

    return 0;

}
