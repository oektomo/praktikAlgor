// no 4
#include <stdio.h>
#include <stdlib.h>

void bubblesort(int* array);
void tukar(int* array, int a, int b);
void fungsirandom(int* array);



int main()
{
int  array[10], i;

fungsirandom (array);

printf("sebelum bubblesort:\n");
for(int i=0; i<10; i++)
printf("%d\n", array[i]);

bubblesort(array);

printf("\nsesudah bubblesort: \n");
for(int i=0; i<10; i++)
printf("%d\n", array[i]);

return 0;
}



void tukar(int* array, int a, int b)
{
    int c;
    c=array[a];
    array[a]=array[b];
    array[b]=c;
}


void bubblesort(int* array)
{
    for(int i=0; i<10; i++)
        for(int j=0; j<9-i; j++)
            if(array[j]>array[j+1])
            tukar(array, j, j+1);
}


void fungsirandom(int* array)
{
    for(int i=0; i<10; i++)
    array[i]=rand()%(100)+1;
}
