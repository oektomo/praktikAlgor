#include<stdio.h>
#define max 50

int satu[25];
int dua[24];

void merge (int low,int middle,int high)
{
    int one,two,three;

    for(one=low, two=middle+1, three=low;one<=middle && two<=high; three++)
    {
    if(satu[one]<=satu[two])
        dua[three] = satu[one++];
    else
        dua[three]=one[two++]
    }

    while (one<=middle)
        dua[three++]=satu[one++];

    while (two<=high)
        dua[three++]=satu[two++];

    for(three=low;three<=high;three++)
        satu[three]=dua[three];
}

void *sort (int low, int high)
{
    int middle;

    if (middle<high)
    {
        middle = (low+high)/2;
        sort (low, middle);
        sort(middle+1, high);
        merge(low, middle, high);
    }
    else
        return;
}

int main()
{
    int angka,ulang;

    printf("program merge sort\n\n");

    printf("masukan jumlah data (max 25): ");
    scanf("%d",&angka);

    for(ulang=0;ulang<jumlah;ulang++)
    {
        printf("data ke-%d: ",ulang+1);
        scanf("%d",satu[ulang]);
    }
    printf ("\n\n");

    printf("sebelum di merge sort: ");
    for(ulang=0;ulang<jumlah;ulang++)
    {
        printf("%d",satu[ulang]);
    }

    *sort (0,angka);

    printf("setelah di merge sort: ");
    for(ulang=0;ulang<jumlah;ulang++)
    {
        printf("%d",a[a+1]);
    }

    printf("\n");
}
