#include <stdio.h>
#include <stdlib.h>

void bubblesort(int* x, int n);
void acak (int* x, int n);

int main ()
{
    int n;
    printf("Masukkan Jumlah Bilangan: ");
    scanf("%d", &n);

    int x[n], i;

    acak(x, n);

    printf("\nBilangan Sebelum sort:\n");
    for (i=0; i<n; i++)
    {
        printf("%d ", x[i]);
    }

    bubblesort(x, n);

    printf("\n\nSesudah Bubble Sort:\n");
    for (i=0;i<n;i++)
    {
        printf("%d ", x[i]);
    }
    printf("\n");

return 0;
}

void bubblesort(int* x, int n)
{
    int a, b, temp;
    for(a=0;a<n;a++)
    {
        for(b=0;b<n;b++)
        {
            if(x[b]>x[b+1])
            {
                temp=x[b];
                x[b]=x[b+1];
                x[b+1]=temp;
            }
        }
    }
}

void acak(int* x, int n)
{
    int a;
    for (a=0;a<n;a++)
    {
        x[a]=rand()%(27)+1;
    }

}
