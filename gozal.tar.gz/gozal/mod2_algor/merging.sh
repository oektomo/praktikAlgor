#!/bin/bash
	git checkout master
        for i in `seq 1 9`;
        do
                git merge 201663000$i 
        done 

        for i in `seq 10 45`;
        do
                git merge 20166300$i 
        done 

	
